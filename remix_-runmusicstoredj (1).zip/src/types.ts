export interface Track {
  id: string;
  title: string;
  artist: string;
  genre: string;
  bpm: number;
  key: string;
  price: number;
  audioUrl: string;
  coverUrl: string;
  createdAt: string;
  contentType?: "track" | "pack";
  label?: string;       // Soundeo Record Label
  votes?: number;       // Soundeo Voting Queue votes count
  voters?: string[];    // User emails/IDs who voted
  releaseDate?: string; // Release date label
}

export type Tab = "home" | "browse" | "votes" | "membership" | "storage" | "admin";

export interface UserAccount {
  credits: number;
  subTier: "free" | "silver" | "gold" | "platinum";
  subStartDate?: string;
  unlockedTracks: string[];
  email?: string;
  name?: string;
  avatarUrl?: string;
  isLoggedIn?: boolean;
  provider?: "google" | "facebook";
  dailyVotesLeft?: number; // Daily left votes count
}

export const GENRES = [
  "Afro House",
  "Bass House",
  "Bounce",
  "Club House",
  "Deep House",
  "Dubstep",
  "Dutch House",
  "Electro House",
  "Exclusive",
  "Free Download",
  "Future House",
  "Hip Hop",
  "House",
  "Latin House",
  "Melodic Techno",
  "Nostalgia",
  "Pop",
  "Progressive House",
  "Promo",
  "Tech House",
  "Techno",
  "Top 40",
  "Trance"
];
