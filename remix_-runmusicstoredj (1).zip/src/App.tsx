import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import HomeView from "./views/HomeView";
import BrowseView from "./views/BrowseView";
import AdminView from "./views/AdminView";
import MembershipView from "./views/MembershipView";
import StorageView from "./views/StorageView";
import VotesView from "./views/VotesView";
import AudioPlayer from "./components/AudioPlayer";
import AuthModal from "./components/AuthModal";
import { Track, Tab, UserAccount } from "./types";
import { Disc, Download, X, Check, ShoppingBag, ShieldCheck, Coins, AlertCircle } from "lucide-react";
import djBackground from "./assets/images/dj_background_1780800399069.png";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [activeTrack, setActiveTrack] = useState<Track | null>(null);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);

  // Local persistent User membership and credit accounts
  const [userAccount, setUserAccount] = useState<UserAccount>(() => {
    const cached = localStorage.getItem("deck_user_account_v2");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        // Fallback
      }
    }
    return {
      credits: 15, // Starter credits
      subTier: "free",
      unlockedTracks: []
    };
  });

  // Save on state update
  useEffect(() => {
    localStorage.setItem("deck_user_account_v2", JSON.stringify(userAccount));
  }, [userAccount]);
  
  // Authentication persists slightly inside sessionStorage
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem("admin_auth") === "granted";
  });

  // Light/Dark Theme Control. Defaults to TRUE to instantly satisfy request 2 out-of-the-box
  const [lightMode, setLightMode] = useState<boolean>(() => {
    const cached = localStorage.getItem("sounddeck_light_mode_v1");
    return cached ? cached === "true" : true;
  });

  useEffect(() => {
    localStorage.setItem("sounddeck_light_mode_v1", lightMode.toString());
  }, [lightMode]);

  // Purchase/Download modal overlays state
  const [checkoutTrack, setCheckoutTrack] = useState<Track | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<"mp3" | "wav" | "stems">("mp3");
  const [checkoutCompleted, setCheckoutCompleted] = useState(false);

  // Initial Fetch of DJ tracks from backend Express state
  const fetchTracks = async () => {
    try {
      const res = await fetch("/api/tracks");
      if (res.ok) {
        const data = await res.json();
        setTracks(data);
      } else {
        console.error("Failed to query store database tracks.");
      }
    } catch (e) {
      console.error("Networking error querying backplane database tracks:", e);
    }
  };

  useEffect(() => {
    fetchTracks();
  }, []);

  // Set play action
  const handlePlayTrack = (track: Track) => {
    if (activeTrack?.id === track.id) {
      setIsAudioPlaying(!isAudioPlaying);
    } else {
      setActiveTrack(track);
      setIsAudioPlaying(true);
    }
  };

  // Safe file downloader action
  const triggerFileDownload = (track: Track) => {
    // If it's a relative uploads path, resolve to our absolute origin, otherwise use standard source
    const downloadUrl = track.audioUrl.startsWith("/uploads/") 
      ? window.location.origin + track.audioUrl 
      : track.audioUrl;
      
    const anchor = document.createElement("a");
    anchor.href = downloadUrl;
    anchor.download = `${track.title.toLowerCase().replace(/[^a-z0-9]/g, "_")}${selectedFormat === "wav" ? ".wav" : ".mp3"}`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
  };

  // Delete Track handler
  const handleDeleteTrack = async (id: string) => {
    if (!confirm("Are you sure you want to delete this track pack from the live marketplace catalog?")) return;

    try {
      const res = await fetch(`/api/tracks/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        // Remove from list
        setTracks(prev => prev.filter(t => t.id !== id));
        // Reset player if active
        if (activeTrack?.id === id) {
          setIsAudioPlaying(false);
          setActiveTrack(null);
        }
      } else {
        const errData = await res.json();
        alert(`Error deleting track: ${errData.error || "Request failed"}`);
      }
    } catch (e) {
      console.error(e);
      alert("Failed to reach server. Please try again.");
    }
  };

  // Force Admin Authorization
  const handleAdminAuthenticate = (code: string): boolean => {
    if (code === "1234" || code.toLowerCase() === "admin") {
      setIsAdminAuthenticated(true);
      sessionStorage.setItem("admin_auth", "granted");
      return true;
    }
    return false;
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem("admin_auth");
    setActiveTab("home");
  };

  // Submit track upload via FormData
  const handleUploadTrack = async (formData: FormData) => {
    const res = await fetch("/api/tracks", {
      method: "POST",
      body: formData
    });

    if (res.ok) {
      const newTrack = await res.json();
      setTracks(prev => [newTrack, ...prev]);
    } else {
      const errorMsg = await res.json();
      throw new Error(errorMsg.error || "Server rejected files upload.");
    }
  };

  // Edit Track metadata handler
  const handleEditTrack = async (id: string, updatedData: Partial<Track>) => {
    const res = await fetch(`/api/tracks/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(updatedData)
    });

    if (res.ok) {
      const updatedTrack = await res.json();
      setTracks(prev => prev.map(t => t.id === id ? updatedTrack : t));
      if (activeTrack?.id === id) {
        setActiveTrack(updatedTrack);
      }
    } else {
      const errorMsg = await res.json();
      throw new Error(errorMsg.error || "Server rejected track edit.");
    }
  };

  // Open the download card modal
  const handleInitiateDownload = (track: Track) => {
    setCheckoutTrack(track);
    setCheckoutCompleted(false);
    setSelectedFormat("mp3");
  };

  return (
    <div 
      className={`min-h-screen flex flex-col pb-32 relative transition-colors duration-300 ${
        lightMode 
          ? "bg-slate-50 text-slate-800 light-container" 
          : "bg-[#080a10] text-slate-305"
      }`}
    >
      
      {/* Universal navigation deck */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isAdminAuthenticated={isAdminAuthenticated}
        onLogoutAdmin={handleAdminLogout}
        user={userAccount}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        lightMode={lightMode}
        onToggleLightMode={() => setLightMode(!lightMode)}
      />

      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Render Active View Dynamic Slots */}
        {activeTab === "home" && (
          <HomeView
            onBrowseClick={() => setActiveTab("browse")}
            onAdminClick={() => setActiveTab("admin")}
            featuredTracks={tracks}
            onPlayTrack={handlePlayTrack}
            playingTrackId={activeTrack?.id || null}
            isPlaying={isAudioPlaying}
            onDownloadTrack={handleInitiateDownload}
            isAdmin={isAdminAuthenticated}
            onDeleteTrack={handleDeleteTrack}
            lightMode={lightMode}
          />
        )}

        {activeTab === "browse" && (
          <BrowseView
            tracks={tracks}
            onPlayTrack={handlePlayTrack}
            onDownloadTrack={handleInitiateDownload}
            playingTrackId={activeTrack?.id || null}
            isPlaying={isAudioPlaying}
            isAdmin={isAdminAuthenticated}
            onDeleteTrack={handleDeleteTrack}
            lightMode={lightMode}
          />
        )}

        {activeTab === "votes" && (
          <VotesView
            user={userAccount}
            onUpdateUser={setUserAccount}
            onOpenAuth={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === "membership" && (
          <MembershipView
            user={userAccount}
            onUpdateUser={setUserAccount}
            tracks={tracks}
            onPlayTrack={handlePlayTrack}
            playingTrackId={activeTrack?.id || null}
            isPlaying={isAudioPlaying}
            onOpenAuth={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === "admin" && (
          <AdminView
            tracks={tracks}
            onUploadTrack={handleUploadTrack}
            onEditTrack={handleEditTrack}
            onDeleteTrack={handleDeleteTrack}
            isAuthenticated={isAdminAuthenticated}
            onAuthenticate={handleAdminAuthenticate}
          />
        )}

        {activeTab === "storage" && (
          <StorageView
            tracks={tracks}
            onMigrateAllToGCS={(updatedTracks) => setTracks(updatedTracks)}
          />
        )}
      </main>

      {/* Floating Global DJ Music Deck Player - Only active on home or other tabs to avoid collision with browse view's inline cards players */}
      {activeTab !== "browse" && (
        <AudioPlayer
          currentTrack={activeTrack}
          isPlaying={isAudioPlaying}
          onPlayPauseToggle={() => setIsAudioPlaying(!isAudioPlaying)}
        />
      )}

      {/* 5. SECURE MARKTPLACE CHECKOUT & DOWNLOAD MODAL */}
      {checkoutTrack && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
          id="checkout-modal-overlay"
        >
          <div className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-6">
            {/* Close trigger button */}
            <button
              id="checkout-close-btn"
              onClick={() => setCheckoutTrack(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white transition rounded p-1 hover:bg-slate-800"
            >
              <X className="h-5 w-5" />
            </button>

            {(() => {
              const isUnlocked = userAccount.unlockedTracks.includes(checkoutTrack.id);
              const creditCost = checkoutTrack.contentType === "pack" ? 3 : 1;
              const isPlatinum = userAccount.subTier === "platinum";
              const cost = isPlatinum || isUnlocked ? 0 : creditCost;
              const canAfford = isPlatinum || isUnlocked || userAccount.credits >= creditCost;
              const isLockedFormat = (selectedFormat === "wav" || selectedFormat === "stems") && userAccount.subTier === "free";

              return !checkoutCompleted ? (
                /* State 5A: Pack checkout builder interface */
                <div className="space-y-4" id="checkout-view-form">
                  <div className="flex items-center gap-2 text-blue-400 font-mono text-xs uppercase">
                    <ShoppingBag className="h-4 w-4" /> Secure Pack Retrieval
                  </div>
                  
                  <div className="flex gap-4 p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <img src={checkoutTrack.coverUrl} className="h-16 w-16 rounded object-cover flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-display font-bold text-white truncate text-base">{checkoutTrack.title}</h3>
                      <p className="text-xs text-slate-400 truncate">by {checkoutTrack.artist}</p>
                      <div className="flex items-center gap-1.5 mt-2">
                        <span className="inline-block px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[9px] text-blue-400 uppercase">
                          {checkoutTrack.genre}
                        </span>
                        <span className={`inline-block px-1.5 py-0.5 rounded font-mono text-[9px] uppercase font-bold ${
                          checkoutTrack.contentType === "pack" ? "bg-amber-500/10 text-amber-300" : "bg-blue-500/10 text-blue-305"
                        }`}>
                          {checkoutTrack.contentType === "pack" ? "DJ Pack" : "Single"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Form format choice */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold text-slate-300">Choose DJ Audio Quality / Format</label>
                      {userAccount.subTier === "free" && (
                        <span className="text-[9px] font-mono font-bold text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded">
                          Guest Account Limits
                        </span>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "mp3", label: "MP3 320kbps", note: "Standard Club" },
                        { id: "wav", label: "WAV 24-bit", note: "Lossless Master", premium: true },
                        { id: "stems", label: "Stems Kit", note: "Vocal/Drum splits", premium: true },
                      ].map((fmt) => {
                        const isFormatLocked = fmt.premium && userAccount.subTier === "free";
                        return (
                          <button
                            key={fmt.id}
                            onClick={() => setSelectedFormat(fmt.id as any)}
                            className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition ${
                              selectedFormat === fmt.id
                                ? "border-blue-500 bg-blue-500/10 text-white"
                                : "border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700 hover:text-white"
                            } ${isFormatLocked ? "opacity-50" : ""}`}
                          >
                            <span className="text-xs font-bold font-mono">
                              {isFormatLocked ? "🔒" : ""} {fmt.id.toUpperCase()}
                            </span>
                            <span className="text-[9px] text-slate-500 mt-0.5">{fmt.note}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Simulated Pricing Info */}
                  <div className="border-t border-slate-800/80 pt-4 space-y-2 font-mono text-xs">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>File Type:</span>
                      <span className="font-bold text-white uppercase">{checkoutTrack.contentType === "pack" ? "DJ PACK (Deduct 3 CR)" : "SINGLE (Deduct 1 CR)"}</span>
                    </div>

                    {isUnlocked ? (
                      <div className="flex items-center justify-between text-emerald-400 font-bold bg-emerald-500/5 border border-emerald-500/10 p-2 rounded-lg">
                        <span>Ownership Status:</span>
                        <span>Unlocked (Free to Redownload)</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Download Cost:</span>
                        <span className="font-bold text-white text-sm">
                          {cost} Credits
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between border-t border-slate-800/50 pt-2 text-sm text-slate-300">
                      <span>Your DJ Wallet Balance:</span>
                      <span className="font-bold text-emerald-400 text-base">
                        {isPlatinum ? "Unlimited (Platinum)" : `${userAccount.credits} Credits`}
                      </span>
                    </div>
                  </div>

                  {/* Format blocker or credit budget warnings */}
                  {isLockedFormat ? (
                    <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded-lg text-xs flex items-start gap-2 leading-relaxed">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-amber-500" />
                      <div>
                        <strong>Pro Quality Locked!</strong> You need an active subscription to download golden lossless WAVs or multitrack STEMS.
                        <button 
                          onClick={() => {
                            setCheckoutTrack(null);
                            setActiveTab("membership");
                          }}
                          className="text-blue-400 hover:underline font-bold ml-1 block mt-1"
                        >
                          Unlock Membership Plan &rarr;
                        </button>
                      </div>
                    </div>
                  ) : !canAfford ? (
                    <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-lg text-xs flex items-start gap-2 leading-relaxed">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-red-500" />
                      <div>
                        <strong>Insufficient Wallet Balance!</strong> Downloading this item requires {cost} Credits, but you only have {userAccount.credits} Credits.
                        <button 
                          onClick={() => {
                            setCheckoutTrack(null);
                            setActiveTab("membership");
                          }}
                          className="text-blue-400 hover:underline font-bold ml-1 mt-1 block"
                        >
                          Get Credits or Upgrade Plan &rarr;
                        </button>
                      </div>
                    </div>
                  ) : null}

                  <button
                    id="checkout-action-btn"
                    disabled={isLockedFormat || !canAfford}
                    onClick={() => {
                      if (!isUnlocked && !isPlatinum) {
                        setUserAccount(prev => ({
                          ...prev,
                          credits: prev.credits - cost,
                          unlockedTracks: [...prev.unlockedTracks, checkoutTrack.id]
                        }));
                      } else if (isPlatinum && !isUnlocked) {
                        setUserAccount(prev => ({
                          ...prev,
                          unlockedTracks: [...prev.unlockedTracks, checkoutTrack.id]
                        }));
                      }
                      setCheckoutCompleted(true);
                      triggerFileDownload(checkoutTrack);
                    }}
                    className={`w-full font-bold p-3 text-xs rounded-xl shadow-lg transition uppercase flex items-center justify-center gap-1.5 ${
                      isLockedFormat || !canAfford
                        ? "bg-slate-800 text-slate-500 border border-slate-700/50 cursor-not-allowed shadow-none"
                        : "bg-blue-600 hover:bg-blue-500 text-white hover:scale-[1.01]"
                    }`}
                  >
                    <Coins className="h-4 w-4 shrink-0" />
                    {isUnlocked ? "Free Redownload (Unlocked)" : `Pay ${cost} Credits & Download Now`}
                  </button>
                  <p className="text-[10px] text-center text-slate-500">
                    Secure checkouts matching RunMusicStoreDj. Latency is less than 50ms.
                  </p>
                </div>
              ) : (
                /* State 5B: Success Checkout view card */
                <div className="text-center py-6 space-y-4" id="checkout-view-success">
                  <div className="h-12 w-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400 animate-bounce">
                    <Check className="h-6 w-6" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-display font-bold text-lg text-white font-sans">Download Successful!</h3>
                    <p className="text-xs text-slate-400 max-w-xs mx-auto">
                      High fidelity <span className="text-blue-400 uppercase font-black">{selectedFormat}</span> files are now saving automatically to your device.
                    </p>
                  </div>
                  
                  <div className="bg-slate-950 border border-slate-800/80 p-3 rounded-lg text-xs font-mono max-w-xs mx-auto text-slate-500 truncate">
                    File: {checkoutTrack.title.toLowerCase().replace(/[^a-z0-9]/g, "_")}_{selectedFormat}.zip
                  </div>

                  <div className="flex gap-2 font-sans pt-2">
                    <button
                      onClick={() => triggerFileDownload(checkoutTrack)}
                      className="flex-1 bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl hover:bg-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" /> Redownload File
                    </button>
                    <button
                      onClick={() => setCheckoutTrack(null)}
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2.5 rounded-xl transition cursor-pointer"
                    >
                      Done, Return to Catalog
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Auth social registration modal overlay */}
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        user={userAccount} 
        onUpdateUser={(updated) => setUserAccount(prev => ({ ...prev, ...updated }))} 
      />
    </div>
  );
}
