import React, { useState, useEffect } from "react";
import { 
  Search, RotateCcw, Sliders, Layout, List, 
  Coins, Download, Trash2, Play, Pause, Activity, 
  Sparkles, Music, Disc, AlertCircle, HelpCircle, 
  Check, Flame, Radio, Cpu, Database, ChevronDown, ChevronUp
} from "lucide-react";
import { Track, UserAccount } from "../types";

interface HomeViewProps {
  onBrowseClick: () => void;
  onAdminClick: () => void;
  featuredTracks: Track[];
  onPlayTrack: (track: Track) => void;
  playingTrackId: string | null;
  isPlaying: boolean;
  onDownloadTrack: (track: Track) => void;
  isAdmin: boolean;
  onDeleteTrack?: (id: string) => void;
  lightMode?: boolean;
}

export default function HomeView({
  onBrowseClick,
  onAdminClick,
  featuredTracks,
  onPlayTrack,
  playingTrackId,
  isPlaying,
  onDownloadTrack,
  isAdmin,
  onDeleteTrack,
  lightMode = true,
}: HomeViewProps) {
  // --- Search & Filters State ---
  const [search, setSearch] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("");
  const [selectedKey, setSelectedKey] = useState("");
  const [minBpm, setMinBpm] = useState(60);
  const [maxBpm, setMaxBpm] = useState(185);
  const [weaponEditType, setWeaponEditType] = useState<string>(""); // ACAPELLA, INTRO, BOOTLEG, REMIX, MASHUP
  const [contentType, setContentType] = useState<string>(""); // singles, packs
  const [displayLayout, setDisplayLayout] = useState<"list" | "grid">("list");
  const [sortBy, setSortBy] = useState<"latest" | "bpm" | "key" | "title">("latest");
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Dynamic user credits balance tracker
  const [localUser, setLocalUser] = useState<UserAccount | null>(null);

  useEffect(() => {
    const handleSyncUser = () => {
      const cached = localStorage.getItem("deck_user_account_v2");
      if (cached) {
        try {
          setLocalUser(JSON.parse(cached));
        } catch (e) {
          // Ignore
        }
      }
    };
    handleSyncUser();
    window.addEventListener("focus", handleSyncUser);
    return () => window.removeEventListener("focus", handleSyncUser);
  }, [playingTrackId]);

  // Handle Preset BPM choices
  const applyBpmPreset = (min: number, max: number) => {
    setMinBpm(min);
    setMaxBpm(max);
  };

  const handleResetFilters = () => {
    setSearch("");
    setSelectedGenre("");
    setSelectedKey("");
    setMinBpm(60);
    setMaxBpm(185);
    setWeaponEditType("");
    setContentType("");
  };

  // Detect track version modifiers automatically from original title
  const getDynamicTag = (title: string, trackGenre: string) => {
    const upper = title.toUpperCase();
    if (upper.includes("INTRO") || upper.includes("HYPE")) return { text: "INTRO EDIT", color: "bg-red-500/10 text-red-400 border-red-500/20" };
    if (upper.includes("BOOTLEG")) return { text: "BOOTLEG", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" };
    if (upper.includes("STEMS") || upper.includes("STEM")) return { text: "STEMS KIT", color: "bg-purple-500/10 text-purple-400 border-purple-500/20" };
    if (upper.includes("REMIX") || upper.includes("RMX")) return { text: "REMIX", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" };
    if (upper.includes("MASHUP")) return { text: "MASHUP", color: "bg-pink-500/10 text-pink-400 border-pink-500/20" };
    if (upper.includes("QUICK") || upper.includes("SHORT")) return { text: "QUICK HITTER", color: "bg-amber-500/10 text-amber-400 border-amber-500/20" };
    if (upper.includes("ACAPELLA") || upper.includes("ACAPELLAS")) return { text: "ACAPELLA", color: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" };
    
    if (trackGenre.toLowerCase() === "exclusive") return { text: "EXCLUSIVE DECK", color: "bg-yellow-500/12 text-yellow-405 border-yellow-500/20" };
    return { text: "EXTENDED MIX", color: "bg-slate-800 text-slate-400 border-slate-700/60" };
  };

  // Filter application matching Bangerz Army Arsenal engine logic
  const filteredTracks = featuredTracks.filter((track) => {
    const titleUpper = track.title.toUpperCase();
    const artistUpper = track.artist.toUpperCase();
    const searchUpper = search.toUpperCase();

    const matchesSearch =
      searchUpper === "" ||
      titleUpper.includes(searchUpper) ||
      artistUpper.includes(searchUpper) ||
      track.genre.toUpperCase().includes(searchUpper);

    const matchesGenre = selectedGenre === "" || track.genre.toLowerCase() === selectedGenre.toLowerCase();
    
    // Camelot key match
    const matchesKey = selectedKey === "" || track.key.toUpperCase() === selectedKey.toUpperCase();
    
    // BPM range match
    const matchesBpm = track.bpm >= minBpm && track.bpm <= maxBpm;
    
    // Singles vs Packs
    const matchesContentType =
      contentType === "" ||
      track.contentType === contentType ||
      (contentType === "track" && (!track.contentType || track.contentType === "track"));

    // Specific Weapon edits (Acapellas, Bootlegs, Remixes, Mashups, Intros)
    let matchesEditType = true;
    if (weaponEditType !== "") {
      if (weaponEditType === "ACAPELLA") {
        matchesEditType = titleUpper.includes("ACAPELLA") || track.genre.toUpperCase().includes("ACAPELLA");
      } else if (weaponEditType === "BOOTLEG") {
        matchesEditType = titleUpper.includes("BOOTLEG");
      } else if (weaponEditType === "REMIX") {
        matchesEditType = titleUpper.includes("REMIX") || titleUpper.includes("RMX");
      } else if (weaponEditType === "MASHUP") {
        matchesEditType = titleUpper.includes("MASHUP");
      } else if (weaponEditType === "INTRO") {
        matchesEditType = titleUpper.includes("INTRO") || titleUpper.includes("HYPE");
      } else if (weaponEditType === "STEMS") {
        matchesEditType = titleUpper.includes("STEMS") || titleUpper.includes("STEM");
      }
    }

    return matchesSearch && matchesGenre && matchesKey && matchesBpm && matchesContentType && matchesEditType;
  });

  // Sorting
  const sortedTracks = [...filteredTracks].sort((a, b) => {
    if (sortBy === "bpm") return b.bpm - a.bpm;
    if (sortBy === "key") return a.key.localeCompare(b.key);
    if (sortBy === "title") return a.title.localeCompare(b.title);
    return new Date(b.createdAt || "").getTime() - new Date(a.createdAt || "").getTime();
  });

  // Collect unique genres mapped
  const uniqueGenres = Array.from(new Set(featuredTracks.map((t) => t.genre))).filter(Boolean).sort();

  // Highlight active filtering criteria count
  const activeFiltersCount = 
    (search !== "" ? 1 : 0) + 
    (selectedGenre !== "" ? 1 : 0) + 
    (selectedKey !== "" ? 1 : 0) + 
    ((minBpm > 60 || maxBpm < 185) ? 1 : 0) + 
    (weaponEditType !== "" ? 1 : 0) +
    (contentType !== "" ? 1 : 0);

  // Traditional Camelot Scale Keys list for speedy grid selection
  const camelotKeys = [
    "1A", "1B", "2A", "2B", "3A", "3B", "4A", "4B", 
    "5A", "5B", "6A", "6B", "7A", "7B", "8A", "8B", 
    "9A", "9B", "10A", "10B", "11A", "11B", "12A", "12B"
  ];

  return (
    <div className="space-y-6 py-4 font-sans select-none" id="home-view-container">
      
      {/* 1. Sleek Premium Header Banner */}
      <div 
        className={`relative overflow-hidden rounded-2xl border transition-all duration-300 p-6 md:p-8 shadow ${
          lightMode 
            ? "border-slate-200 bg-gradient-to-br from-blue-50 via-[#f0f4ff] to-slate-50" 
            : "border-slate-800 bg-gradient-to-br from-slate-900 via-[#0a0d14] to-[#121824]"
        }`}
        id="arsenal-cockpit-header"
      >
        <div className="absolute top-0 right-0 h-64 w-64 bg-blue-500/[0.03] rounded-full blur-[80px] pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 h-48 w-48 bg-indigo-500/[0.03] rounded-full blur-[80px] pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 z-10 relative">
          
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="flex h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse" />
              <span className={`px-2 py-0.5 border rounded text-[10px] font-mono font-bold tracking-wider uppercase ${
                lightMode 
                  ? "bg-blue-50/80 border-blue-200 text-blue-700" 
                  : "bg-blue-950/40 border-blue-900 text-blue-400"
              }`}>
                Premium DJ Portal
              </span>
            </div>

            <h2 className={`text-2xl md:text-3xl font-bold tracking-tight leading-tight ${
              lightMode ? "text-blue-900" : "text-white"
            }`}>
              Professional DJ Tracks & Stems
            </h2>
            <p className={`text-xs md:text-sm max-w-lg leading-relaxed font-medium ${
              lightMode ? "text-slate-650" : "text-slate-400"
            }`}>
              Find and download lossless WAV DJ tools, premium acapellas, and master stems with calibrated BPM and Harmonic keys.
            </p>
          </div>

          {/* Account Balance Display */}
          {localUser ? (
            <div className={`p-3.5 rounded-xl border flex items-center gap-3.5 font-mono select-none self-start lg:self-center shadow-md transition-all duration-300 animate-fadeIn ${
              lightMode 
                ? "bg-white border-slate-200 text-slate-800 hover:border-blue-500/30" 
                : "bg-slate-950/60 border-slate-800 text-slate-100 hover:border-amber-500/30"
            }`}>
              <div className={`h-9 w-9 rounded-lg flex items-center justify-center border shrink-0 ${
                lightMode 
                  ? "bg-blue-50/10 border-blue-500/20 text-blue-600" 
                  : "bg-blue-950/40 border-blue-800 text-blue-400"
              }`}>
                <Coins className="h-4.5 w-4.5" />
              </div>
              <div>
                <p className={`text-[9px] font-bold uppercase tracking-wider ${
                  lightMode ? "text-slate-500" : "text-slate-400"
                }`}>Account Balance</p>
                <p className={`text-lg font-bold mt-0.5 ${
                  lightMode ? "text-slate-900" : "text-amber-400"
                }`}>
                  {localUser.subTier === "platinum" ? "UNLIMITED VIP" : `${localUser.credits} CREDITS`}
                </p>
                <div className="flex items-center gap-1 mt-0.5">
                  <span className="h-1 w-1 rounded-full bg-emerald-500 animate-pulse" />
                  <span className={`text-[9px] font-bold uppercase ${
                    lightMode ? "text-blue-600" : "text-blue-400"
                  }`}>Tier: {localUser.subTier}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className={`p-3.5 rounded-xl border flex items-center gap-3.5 font-mono self-start lg:self-center shadow-sm ${
              lightMode 
                ? "bg-white border-slate-200 text-slate-800" 
                : "bg-[#111622] border-slate-800 text-slate-300"
            }`}>
              <div className="h-9 w-9 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-500">
                <Cpu className="h-4.5 w-4.5" />
              </div>
              <div>
                <p className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">Guest Mode</p>
                <p className="text-xs font-semibold text-blue-600 mt-0.5">
                  Lossless WAV Enabled
                </p>
                <p className="text-[9px] text-slate-450">Sign in to unlock download credits.</p>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* 2. Organized & Eye-Comfort Filter Dashboard */}
      <div 
        className="p-4 rounded-xl bg-white border border-slate-200 space-y-3 shadow-md" 
        id="tactical-filters-cockpit"
      >
        {/* Main Search & Base Filter Action Rows */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2.5">
          
          {/* Main Intelligent Search Bar */}
          <div className="flex-1 relative">
            <Search className="absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              id="tactical-search"
              type="text"
              placeholder="Search title, artist, genre, tempo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-lg bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 text-xs focus:outline-none focus:border-blue-500/30 hover:border-slate-300 transition"
            />
          </div>

          {/* Quick Base Filters & Expanded Controls Switch */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Genre Selection Dropdown */}
            <select
              value={selectedGenre}
              onChange={(e) => setSelectedGenre(e.target.value)}
              className="bg-white border border-slate-200 text-slate-700 text-xs py-2 px-3 rounded-lg focus:outline-none focus:border-blue-500/20 cursor-pointer hover:bg-slate-50 transition"
            >
              <option value="">All Genres</option>
              {uniqueGenres.map((g) => (
                <option key={g} value={g}>
                  {g.toUpperCase()}
                </option>
              ))}
            </select>

            {/* Collapsible DJ Advanced Filter Toggle */}
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold cursor-pointer border transition-all ${
                showAdvanced || selectedKey !== "" || minBpm > 60 || maxBpm < 185 || weaponEditType !== ""
                  ? "bg-blue-105 text-blue-650 border-blue-500/20 font-bold"
                  : "bg-slate-50 border-slate-250 text-slate-650 hover:border-slate-350 hover:text-blue-600"
              }`}
            >
              <Sliders className="h-3.5 w-3.5" />
              <span>Keys & Tempo</span>
              {showAdvanced ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
            </button>

            {/* Simple Reset Trigger */}
            <button
              onClick={handleResetFilters}
              className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 hover:text-blue-600 border border-slate-250 text-slate-550 transition cursor-pointer"
              title="Reset Filters"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>

          </div>

        </div>

        {/* Collapsible Panel for Advanced Harmonic & BPM controls */}
        {showAdvanced && (
          <div className="pt-3 border-t border-slate-200 grid grid-cols-1 md:grid-cols-12 gap-4 animate-fadeIn">
            
            {/* Left Box: Speed Calibration & Quick BPM presets */}
            <div className="md:col-span-5 space-y-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              
              {/* Range Selector */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-bold uppercase tracking-wider text-[10px]">Tempo Range</span>
                  <span className="text-blue-600 font-bold font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-[11px]">{minBpm} - {maxBpm} BPM</span>
                </div>
                
                <div className="flex items-center gap-2.5 py-1 px-1">
                  <span className="text-[10px] text-slate-400 font-mono">60</span>
                  <div className="flex-1 flex gap-2">
                    <input
                      type="range"
                      min={60}
                      max={185}
                      value={minBpm}
                      onChange={(e) => setMinBpm(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                    />
                    <input
                      type="range"
                      min={60}
                      max={185}
                      value={maxBpm}
                      onChange={(e) => setMaxBpm(parseInt(e.target.value))}
                      className="w-full h-1 bg-slate-200 rounded appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">185</span>
                </div>
              </div>

              {/* Grid Speed dials for quick selection */}
              <div className="space-y-1">
                <span className="block text-[9px] uppercase tracking-wider font-bold text-slate-500">
                  Quick Tempo Presets
                </span>
                <div className="grid grid-cols-2 gap-1 font-mono text-[10px]">
                  <button
                    onClick={() => applyBpmPreset(120, 128)}
                    className="px-2 py-1.5 rounded-md bg-white hover:bg-slate-50 hover:text-blue-650 text-left text-slate-600 border border-slate-200 shadow-sm transition flex items-center justify-between cursor-pointer"
                  >
                    <span>House / Tech</span>
                    <span className="text-blue-600 font-bold">120-128</span>
                  </button>
                  <button
                    onClick={() => applyBpmPreset(140, 150)}
                    className="px-2 py-1.5 rounded-md bg-white hover:bg-slate-50 hover:text-blue-650 text-left text-slate-600 border border-slate-200 shadow-sm transition flex items-center justify-between cursor-pointer"
                  >
                    <span>Trap / Bass</span>
                    <span className="text-blue-600 font-bold">140-150</span>
                  </button>
                  <button
                    onClick={() => applyBpmPreset(170, 178)}
                    className="px-2 py-1.5 rounded-md bg-white hover:bg-slate-50 hover:text-blue-650 text-left text-slate-600 border border-slate-200 shadow-sm transition flex items-center justify-between cursor-pointer"
                  >
                    <span>Drum & Bass</span>
                    <span className="text-blue-600 font-bold">170-178</span>
                  </button>
                  <button
                    onClick={() => applyBpmPreset(90, 105)}
                    className="px-2 py-1.5 rounded-md bg-white hover:bg-slate-50 hover:text-blue-650 text-left text-slate-600 border border-slate-200 shadow-sm transition flex items-center justify-between cursor-pointer"
                  >
                    <span>Hip-Hop</span>
                    <span className="text-blue-600 font-bold">90-105</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Right Box: Camelot Harmonic Grid */}
            <div className="md:col-span-7 space-y-1.5 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-bold uppercase tracking-wider text-[10px]">Camelot Harmonic Key</span>
                {selectedKey && (
                  <button 
                    onClick={() => setSelectedKey("")}
                    className="text-blue-650 hover:underline text-[10px] uppercase font-bold"
                  >
                    Clear Filter
                  </button>
                )}
              </div>

              {/* 24-key map compact design */}
              <div className="grid grid-cols-8 gap-1 p-1 bg-white rounded-xl border border-slate-200 max-h-[120px] overflow-y-auto pr-1">
                {camelotKeys.map((k) => {
                  const isActive = selectedKey.toUpperCase() === k.toUpperCase();
                  return (
                    <button
                      key={k}
                      onClick={() => setSelectedKey(isActive ? "" : k)}
                      className={`py-1 text-[9px] font-mono font-bold rounded text-center transition tracking-widest cursor-pointer ${
                        isActive 
                          ? "bg-blue-600 text-white font-bold shadow-sm"
                          : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"
                      }`}
                    >
                      {k}
                    </button>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* Sub-Filters / Weapon Modifiers & Sort Bar for clean visibility */}
        <div className="pt-2.5 border-t border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono text-xs text-slate-500">
          
          {/* Weapon Edit modifiers pills inside the toolbar to keep it clean */}
          <div className="flex flex-wrap items-center gap-1">
            <span className="text-slate-450 font-bold text-[9px] mr-1 uppercase">Mix Formats:</span>
            {[
              { id: "", label: "All Mixes" },
              { id: "INTRO", label: "Intro" },
              { id: "BOOTLEG", label: "Bootleg" },
              { id: "ACAPELLA", label: "Acapella" },
              { id: "REMIX", label: "Remix" },
              { id: "MASHUP", label: "Mashup" },
              { id: "STEMS", label: "Stems" }
            ].map((type) => (
              <button
                key={type.id}
                onClick={() => setWeaponEditType(type.id)}
                className={`px-2.5 py-0.5 rounded text-[10px] font-bold transition duration-150 uppercase cursor-pointer ${
                  weaponEditType === type.id
                    ? "bg-blue-50 text-blue-600 border border-blue-200"
                    : "bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-550 hover:text-blue-600"
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-450 text-[9px] font-bold uppercase">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border border-slate-200 text-[10px] text-slate-600 py-1 px-2 rounded focus:outline-none focus:border-blue-500/25 cursor-pointer font-bold font-mono hover:bg-slate-5s"
              >
                <option value="latest">Latest</option>
                <option value="bpm">BPM (Tempo)</option>
                <option value="key">Harmonic Key</option>
                <option value="title">Title (A-Z)</option>
              </select>
            </div>

            {/* Layout switches */}
            <div className="flex items-center bg-slate-50 border border-slate-200 p-0.5 rounded-md space-x-0.5">
              <button
                onClick={() => setDisplayLayout("list")}
                className={`p-1 rounded transition cursor-pointer ${
                  displayLayout === "list" 
                    ? "bg-white text-blue-600 shadow-sm border border-slate-200/50" 
                    : "text-slate-400 hover:text-slate-600"
                }`}
                title="List View"
              >
                <List className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => setDisplayLayout("grid")}
                className={`p-1 rounded transition cursor-pointer ${
                  displayLayout === "grid" 
                    ? "bg-white text-blue-600 shadow-sm border border-slate-200/50" 
                    : "text-slate-400 hover:text-slate-600"
                }`}
                title="Grid View"
              >
                <Layout className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* 3. Main Catalog Space */}
      <section className="space-y-3" id="arsenal-catalog-dashboard">
        
        {/* Simple & Clean Header Row */}
        <div className="flex items-center justify-between border-b border-slate-205 pb-2">
          <div className="space-y-0.5">
            <h3 className="font-sans text-sm font-semibold text-blue-700 flex items-center gap-1.5 uppercase tracking-wide">
              <Disc className="h-4 w-4 text-blue-600 animate-[spin_10s_linear_infinite]" /> 
              Tracks & Stems Catalog ({sortedTracks.length})
            </h3>
            <p className="text-[10px] text-slate-500">
              Download studio-grade lossless WAV files and complete stem packages for mixing.
            </p>
          </div>
        </div>

        {sortedTracks.length > 0 ? (
          displayLayout === "list" ? (
            /* High-performance compact table layout */
            <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm" id="arsenal-weapons-table">
              
              {/* Header column legends */}
              <div className="hidden lg:grid grid-cols-12 gap-3 px-5 py-2.5 bg-slate-50 text-[10px] font-semibold text-slate-500 border-b border-slate-200/80 font-sans tracking-wide">
                <div className="col-span-1 text-center">Listen</div>
                <div className="col-span-4 pl-3">Track & Producer</div>
                <div className="col-span-1 text-center">BPM</div>
                <div className="col-span-1 text-center">Key</div>
                <div className="col-span-2">Genre</div>
                <div className="col-span-2 text-center">Waveform</div>
                <div className="col-span-1 text-center">Price</div>
                <div className="col-span-1 text-right pr-2">Actions</div>
              </div>

              {/* Table items ledger */}
              <div className="divide-y divide-slate-100 font-mono bg-white">
                {sortedTracks.map((track) => {
                  const isLocalPlaying = playingTrackId === track.id && isPlaying;
                  const versionDetails = getDynamicTag(track.title, track.genre);
                  
                  return (
                    <div 
                      key={track.id}
                      className={`grid grid-cols-1 lg:grid-cols-12 gap-2 lg:gap-3 items-center px-4 py-2.5 transition-all duration-150 ${
                        isLocalPlaying 
                          ? "bg-blue-50/40 border-l-2 border-blue-600" 
                          : "hover:bg-slate-50"
                      }`}
                    >
                      {/* Play Action */}
                      <div className="col-span-1 flex items-center justify-start lg:justify-center">
                        <button
                          onClick={() => onPlayTrack(track)}
                          className={`h-7 w-7 rounded-md flex items-center justify-center transition cursor-pointer border ${
                            isLocalPlaying
                              ? "bg-blue-600 text-white border-blue-600 shadow"
                              : "bg-slate-50 border-slate-200 text-slate-700 hover:border-blue-550 hover:text-blue-650"
                          }`}
                        >
                          {isLocalPlaying ? (
                            <Pause className="h-3 w-3 fill-current stroke-[2.5]" />
                          ) : (
                            <Play className="h-3 w-3 fill-current ml-[1px]" />
                          )}
                        </button>
                      </div>

                      {/* Cover Artwork + Title Column */}
                      <div className="col-span-4 flex items-center gap-3 min-w-0 pl-0 lg:pl-3">
                        <div className="h-8.5 w-8.5 rounded overflow-hidden border border-slate-200 shrink-0 bg-slate-50">
                          <img 
                            src={track.coverUrl} 
                            className="h-full w-full object-cover" 
                            alt={track.title} 
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded border leading-none tracking-wide ${versionDetails.color}`}>
                              {versionDetails.text}
                            </span>
                            <span className="text-[8px] font-extrabold px-1.5 py-0.5 bg-slate-100 border border-slate-200 text-slate-600 rounded leading-none uppercase">
                              {track.contentType === "pack" ? "STEMS PACK" : "SINGLE"}
                            </span>
                          </div>
                          
                          <h4 
                            className="font-bold text-slate-800 text-[12px] truncate mt-1 hover:text-blue-650 transition cursor-pointer leading-normal tracking-wide"
                            onClick={() => onPlayTrack(track)}
                          >
                            {track.title}
                          </h4>
                          
                          <p className="text-[10px] text-slate-500 truncate mt-0.5">
                            by {track.artist}
                          </p>
                        </div>
                      </div>

                      {/* Tempo */}
                      <div className="col-span-1 flex lg:justify-center items-center gap-1 font-mono">
                        <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">BPM:</span>
                        <span className="font-bold text-blue-650 text-xs bg-blue-50/60 px-2 py-0.5 rounded border border-blue-100">
                          {track.bpm} <span className="text-[8px] font-normal text-slate-600">BPM</span>
                        </span>
                      </div>

                      {/* Key Code Scale */}
                      <div className="col-span-1 flex lg:justify-center items-center gap-1 font-mono">
                        <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">KEY:</span>
                        <span className="font-bold text-purple-600 text-xs bg-purple-50 px-2 py-0.5 rounded border border-purple-105 tracking-widest">
                          {track.key}
                        </span>
                      </div>

                      {/* Genre Type */}
                      <div className="col-span-2 flex items-center gap-1 font-mono">
                        <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">GENRE:</span>
                        <span className="px-2 py-0.5 bg-slate-50 rounded border border-slate-200 text-slate-600 text-[10px] uppercase truncate max-w-full">
                          {track.genre}
                        </span>
                      </div>

                      {/* Visual Synthesizer Waveform */}
                      <div className="col-span-2 hidden lg:flex items-center h-6 px-3">
                        {isLocalPlaying ? (
                          <div className="flex items-center gap-[3px] h-3.5 w-full bg-slate-50 px-2 rounded-lg border border-slate-200" id="tactical-wave">
                            <span className="h-1 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.1s_alternate]" />
                            <span className="h-3 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.3s_alternate]" />
                            <span className="h-2 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.5s_alternate]" />
                            <span className="h-3 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.2s_alternate]" />
                            <span className="h-1.5 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.4s_alternate]" />
                            <span className="h-2.5 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.6s_alternate]" />
                            <span className="h-1 w-0.5 bg-blue-600 rounded-full animate-[bounce_0.8s_infinite_0.1s_alternate]" />
                          </div>
                        ) : (
                          <div className="flex items-center gap-[2.5px] h-3.5 w-full opacity-35 px-2">
                             <span className="h-1 w-0.5 bg-slate-400 rounded-full" />
                             <span className="h-2 w-0.5 bg-slate-400 rounded-full" />
                             <span className="h-1.5 w-0.5 bg-slate-400 rounded-full" />
                             <span className="h-1 w-0.5 bg-slate-400 rounded-full" />
                             <span className="h-2 w-0.5 bg-slate-400 rounded-full" />
                             <span className="h-1.5 w-0.5 bg-slate-400 rounded-full" />
                             <span className="h-1 w-0.5 bg-slate-400 rounded-full" />
                          </div>
                        )}
                      </div>

                      {/* Cost */}
                      <div className="col-span-1 flex lg:justify-center items-center gap-1 font-mono">
                        <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">COST:</span>
                        <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold">
                          <Coins className="h-3.5 w-3.5 text-emerald-500" />
                          <span>{track.contentType === "pack" ? "3 CR" : "1 CR"}</span>
                        </div>
                      </div>

                      {/* Download */}
                      <div className="col-span-1 flex items-center justify-between lg:justify-end gap-1.5 mt-2 lg:mt-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-150">
                        {isAdmin && onDeleteTrack && (
                          <button
                            onClick={() => onDeleteTrack(track.id)}
                            className="p-1 border border-red-200 bg-red-50 text-red-650 rounded hover:bg-red-500 hover:text-white transition cursor-pointer"
                            title="Delete track"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        )}

                        <button
                          onClick={() => onDownloadTrack(track)}
                          className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white font-bold text-[9px] transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Download className="h-3 w-3" /> Download
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Elegant grid representations */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="arsenal-bento-grid">
              {sortedTracks.map((track) => {
                const isLocalPlaying = playingTrackId === track.id && isPlaying;
                const versionDetails = getDynamicTag(track.title, track.genre);
                
                return (
                  <div 
                    key={track.id}
                    className="group bento-card relative overflow-hidden rounded-xl border border-slate-205 bg-white p-4 shadow-md hover:border-blue-500/30 transition-all duration-300"
                  >
                    {isLocalPlaying && (
                      <div className="absolute inset-0 bg-gradient-to-t from-blue-500/[0.02] via-transparent to-transparent pointer-events-none" />
                    )}

                    <div className="relative space-y-3">
                      
                      {/* Image Art Block */}
                      <div className="relative aspect-video rounded-lg overflow-hidden border border-slate-150 bg-slate-50">
                        <img 
                          src={track.coverUrl} 
                          className="h-full w-full object-cover group-hover:scale-101 transition-transform duration-300" 
                          alt={track.title} 
                          referrerPolicy="no-referrer"
                        />
                        
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30 flex flex-col justify-between p-3">
                          
                          <div className="flex items-center justify-between">
                            <span className={`text-[8px] font-extrabold px-2 py-0.5 rounded leading-none border uppercase tracking-wider backdrop-blur-sm ${versionDetails.color}`}>
                              {versionDetails.text}
                            </span>
                            <span className="text-[8px] font-extrabold px-2 py-0.5 bg-black/60 border border-slate-800 text-slate-200 rounded leading-none uppercase">
                              {track.contentType === "pack" ? "STEMS PACK" : "SINGLE"}
                            </span>
                          </div>

                          <button
                            onClick={() => onPlayTrack(track)}
                            className={`h-8 w-8 rounded-full flex items-center justify-center self-center transition cursor-pointer ${
                              isLocalPlaying
                                ? "bg-blue-600 text-white scale-105 shadow animate-pulse"
                                : "bg-black/60 border border-slate-700 text-blue-400 hover:scale-105 hover:bg-black/85"
                            }`}
                          >
                            {isLocalPlaying ? (
                              <Pause className="h-4 w-4 fill-current stroke-[2.5]" />
                            ) : (
                              <Play className="h-4 w-4 fill-current ml-[1px]" />
                            )}
                          </button>

                          <div className="flex justify-between items-center text-[9px] font-mono">
                            <span className="bg-blue-650 text-white font-bold px-1.5 py-0.5 rounded shadow">
                              {track.bpm} BPM
                            </span>
                            <span className="bg-purple-600 text-white font-bold px-1.5 py-0.5 rounded shadow">
                              {track.key}
                            </span>
                          </div>

                        </div>
                      </div>

                      {/* Metadata Labels */}
                      <div className="space-y-0.5">
                        <h4 className="font-bold text-slate-800 text-[13px] line-clamp-1 leading-normal tracking-wide group-hover:text-blue-650 transition">
                          {track.title}
                        </h4>
                        <p className="text-[10px] text-slate-505 truncate font-mono uppercase tracking-wider">
                          by {track.artist}
                        </p>
                      </div>

                      {/* Action Triggers */}
                      <div className="border-t border-slate-100 pt-2.5 flex items-center justify-between font-mono text-[10px]">
                        
                        <div className="flex items-center gap-1 text-emerald-600 font-bold text-[10px]">
                          <Coins className="h-4 w-4 text-emerald-505" />
                          <span>{track.contentType === "pack" ? "3 CREDITS" : "1 CREDIT"}</span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {isAdmin && onDeleteTrack && (
                            <button
                              onClick={() => onDeleteTrack(track.id)}
                              className="p-1 bg-red-50 text-red-650 border border-red-100 rounded hover:bg-red-500 hover:text-white transition cursor-pointer"
                              title="Delete pack"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          )}

                          <button
                            onClick={() => onDownloadTrack(track)}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-3 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer transform hover:scale-[1.01] text-[9px] shadow-sm"
                          >
                            <Download className="h-3 w-3 text-white" /> DOWNLOAD WAV
                          </button>
                        </div>

                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          )
        ) : (
          <div className="flex flex-col items-center justify-center py-12 px-4 border border-dashed border-slate-200 rounded-xl bg-white shadow-sm text-center space-y-3 animate-fadeIn">
            <div className="h-10 w-10 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center text-blue-600">
              <AlertCircle className="h-5 w-5" />
            </div>
            
            <div className="max-w-md space-y-0.5">
              <h4 className="font-bold text-blue-600 text-xs uppercase tracking-wider">
                No Tracks Found
              </h4>
              <p className="text-[11px] text-slate-505 leading-relaxed max-w-sm mx-auto">
                No tracks match your active search or filter settings. Reset filters to view the complete catalog.
              </p>
            </div>

            <button
              onClick={handleResetFilters}
              className="text-[10px] font-bold bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition cursor-pointer uppercase tracking-wider shadow-sm"
            >
              Reset Filters
            </button>
          </div>
        )}
      </section>

      {/* 4. Bottom Tactical Instructions Panel */}
      <section 
        className="p-5 rounded-2xl border border-slate-205 bg-white grid grid-cols-1 md:grid-cols-3 gap-5 text-slate-700 font-sans shadow-sm" 
        id="arsenal-instructions"
      >
        <div className="space-y-1">
          <div className="flex items-center gap-1 text-blue-600 text-xs font-semibold uppercase tracking-wider font-mono">
            <Radio className="h-4 w-4 text-blue-600 animate-pulse" />
            <span>Harmonic Key Coding</span>
          </div>
          <h4 className="font-bold text-slate-800 text-[12px] uppercase">Pitch Alignment</h4>
          <p className="text-[11px] text-slate-505 leading-relaxed font-sans">
            Standard Camelot scale keys (5A, 8B etc.) empower DJs to create flawless, drift-free pitch transitions that blend seamlessly.
          </p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-1 text-blue-600 text-xs font-semibold uppercase tracking-wider font-mono">
            <Flame className="h-4 w-4" />
            <span>24-Bit Studio Masters</span>
          </div>
          <h4 className="font-bold text-slate-800 text-[12px] uppercase">Uncompressed Files</h4>
          <p className="text-[11px] text-slate-505 leading-relaxed font-sans">
            Guaranteed uncompressed Lossless WAV files and multitrack stems, perfectly structured and optimized for loud club sound systems.
          </p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-1 text-emerald-600 text-xs font-semibold uppercase tracking-wider font-mono">
            <Check className="h-4 w-4 text-emerald-505" />
            <span>Lifetime Ownership</span>
          </div>
          <h4 className="font-bold text-slate-800 text-[12px] uppercase">Limitless Access</h4>
          <p className="text-[11px] text-slate-505 leading-relaxed font-sans">
            Redeeming credits grants you continuous licensing. Re-download files anytime straight from your history with zero additional fee.
          </p>
        </div>
      </section>

    </div>
  );
}
