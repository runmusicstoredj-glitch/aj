import React, { useState, useEffect } from "react";
import { 
  ThumbsUp, Plus, Sparkles, Send, Check, AlertCircle, Link2, 
  Disc, Search, Flame, Coins, Calendar, Clock 
} from "lucide-react";
import { UserAccount } from "../types";

interface VotesViewProps {
  user: UserAccount;
  onUpdateUser: (newUser: UserAccount) => void;
  onOpenAuth?: () => void;
}

interface QueuedRequest {
  id: string;
  title: string;
  artist: string;
  label: string;
  genre: string;
  url: string;
  currentVotes: number;
  targetVotes: number;
  submittedBy: string;
  createdAt: string;
  status: "voting" | "processing" | "unlocked";
}

export default function VotesView({
  user,
  onUpdateUser,
  onOpenAuth,
}: VotesViewProps) {
  // Mock preloaded requested tracks for high-fidelity Soundeo look
  const [requests, setRequests] = useState<QueuedRequest[]>(() => {
    const cached = localStorage.getItem("soundeo_request_pool_v1");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        // error
      }
    }
    return [
      {
        id: "req-1",
        title: "Be Sharp Say 3",
        artist: "Patrick Topping",
        label: "Hot Creations",
        genre: "Tech House",
        url: "https://www.beatport.com/track/be-sharp-say-3/9839958",
        currentVotes: 32,
        targetVotes: 50,
        submittedBy: "resident_dj_shawn",
        createdAt: "2026-06-06T10:00:00.000Z",
        status: "voting"
      },
      {
        id: "req-2",
        title: "Rumble",
        artist: "Skrillex, Fred again.., Flowdan",
        label: "Atlantic Records",
        genre: "Dubstep / Bass",
        url: "https://www.beatport.com/track/rumble/17228800",
        currentVotes: 48,
        targetVotes: 50,
        submittedBy: "dub_king77",
        createdAt: "2026-06-07T12:30:00.000Z",
        status: "voting"
      },
      {
        id: "req-3",
        title: "Nanana (It Goes Like)",
        artist: "Peggy Gou",
        label: "XL Recordings",
        genre: "House",
        url: "https://www.beatport.com/track/nanana-it-goes-like/17700109",
        currentVotes: 50,
        targetVotes: 50,
        submittedBy: "berlin_grooves",
        createdAt: "2026-06-05T08:15:00.000Z",
        status: "processing"
      },
      {
        id: "req-4",
        title: "Spider (Extended Mix)",
        artist: "Maddix",
        label: "Revealed Recordings",
        genre: "Techno",
        url: "https://www.beatport.com/track/spider/18029910",
        currentVotes: 12,
        targetVotes: 30,
        submittedBy: "rave_kid_trans",
        createdAt: "2026-06-08T02:00:00.000Z",
        status: "voting"
      }
    ];
  });

  // Save requests to local cache
  useEffect(() => {
    localStorage.setItem("soundeo_request_pool_v1", JSON.stringify(requests));
  }, [requests]);

  // Form states
  const [newTitle, setNewTitle] = useState("");
  const [newArtist, setNewArtist] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newGenre, setNewGenre] = useState("Tech House");
  const [newUrl, setNewUrl] = useState("");
  const [formSuccess, setFormSuccess] = useState(false);
  const [formError, setFormError] = useState("");

  const [filterSearch, setFilterSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "voting" | "processing">("all");

  // Track user voted list inside local state to avoid duplicate voting
  const [votedRequestIds, setVotedRequestIds] = useState<string[]>(() => {
    const cached = localStorage.getItem("soundeo_user_votes_v1");
    return cached ? JSON.parse(cached) : [];
  });

  useEffect(() => {
    localStorage.setItem("soundeo_user_votes_v1", JSON.stringify(votedRequestIds));
  }, [votedRequestIds]);

  // Submit Request
  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user.isLoggedIn) {
      if (onOpenAuth) onOpenAuth();
      return;
    }

    if (!newTitle || !newArtist || !newLabel || !newUrl) {
      setFormError("Please fill out all request parameters correctly.");
      return;
    }

    if (!newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
      setFormError("URL must begin with http:// or https:// (e.g. Beatport link).");
      return;
    }

    const payload: QueuedRequest = {
      id: `req-${Date.now()}`,
      title: newTitle,
      artist: newArtist,
      label: newLabel,
      genre: newGenre,
      url: newUrl,
      currentVotes: 1, // submitted track gets 1 initial vote
      targetVotes: user.subTier === "free" ? 50 : 35, // Premium requests have closer targets
      submittedBy: user.name || "Anonymous DJ",
      createdAt: new Date().toISOString(),
      status: "voting"
    };

    setRequests(prev => [payload, ...prev]);
    setVotedRequestIds(prev => [...prev, payload.id]);

    // Clear form
    setNewTitle("");
    setNewArtist("");
    setNewLabel("");
    setNewUrl("");
    setFormError("");
    setFormSuccess(true);

    setTimeout(() => {
      setFormSuccess(false);
    }, 3000);
  };

  // Perform a Vote Up interaction
  const handleVoteRequest = (reqId: string) => {
    if (!user.isLoggedIn) {
      if (onOpenAuth) onOpenAuth();
      return;
    }

    if (votedRequestIds.includes(reqId)) {
      alert("You have already voted for this track in this poll series!");
      return;
    }

    // Spend vote. Free users get a daily limit, Platinum gets unlimited.
    if (user.subTier === "free" && user.credits < 1) {
      alert("Voting requires at least 1 credit to authorize community pool additions!");
      return;
    }

    // Update requests array
    setRequests(prev => prev.map(req => {
      if (req.id === reqId) {
        const nextVotes = req.currentVotes + 1;
        const reachedTarget = nextVotes >= req.targetVotes;
        return {
          ...req,
          currentVotes: nextVotes,
          status: reachedTarget ? "processing" : req.status
        };
      }
      return req;
    }));

    // Save ID to prevent duplication
    setVotedRequestIds(prev => [...prev, reqId]);

    // Fast deduct client credit limit if they are free to prove credit sync, in Soundeo it requires budget
    if (user.subTier !== "platinum") {
      onUpdateUser({
        ...user,
        credits: Math.max(0, user.credits - 1)
      });
    }
  };

  // Filter list
  const filteredRequests = requests.filter(req => {
    const matchesKeyword = 
      req.title.toLowerCase().includes(filterSearch.toLowerCase()) ||
      req.artist.toLowerCase().includes(filterSearch.toLowerCase()) ||
      req.label.toLowerCase().includes(filterSearch.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || req.status === filterStatus;

    return matchesKeyword && matchesStatus;
  });

  return (
    <div className="space-y-6 py-4 font-sans text-slate-300 select-none" id="votes-pool-board">
      
      {/* 1. Header Information Panel */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 h-48 w-48 bg-amber-500/[0.03] rounded-full blur-[60px] pointer-events-none" />
        
        <div className="space-y-2 z-10">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-500 animate-[spin_5s_linear_infinite]" />
            <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded font-mono text-[10px] font-black text-amber-400 tracking-wider">
              SOUNDEO VOTING SYSTEM
            </span>
            <span className="text-[10px] text-slate-500 font-mono">POOL REQUISITIONS</span>
          </div>
          <h2 className="font-display text-2xl lg:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
            Community Request Queue
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed max-w-xl">
            Can't find a special track in our catalog? Submit a Beatport/Juno link. The community will cast votes on it. When a track receives enough upvotes, it automatically triggers secure GCS pooling for high-fidelity download!
          </p>
        </div>

        {/* Voting wallet status HUD */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3 font-mono shrink-0 select-none z-10 shadow-lg">
          <div className="h-9 w-9 rounded-lg bg-amber-500/10 flex items-center justify-center border border-amber-550/20 text-amber-400">
            <ThumbsUp className="h-4 w-4 animate-bounce" />
          </div>
          <div>
            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest leading-none">Your Votes Balance</p>
            <p className="text-sm font-bold text-white mt-1">
              {user.subTier === "platinum" ? "Unlimited Daily VIP" : "1 Credit = 1 Vote Core"}
            </p>
            <p className="text-[9px] text-slate-405 mt-0.5 font-sans">
              Wallet Limit: <span className="text-emerald-400 font-bold">{user.credits} Credits</span>
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: REQUESTS INDEX LISTING (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Index Search Bar & Filters */}
          <div className="p-4 rounded-xl bg-[#0f1420] border border-slate-800/80 flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-slate-500" />
              <input
                type="text"
                value={filterSearch}
                onChange={(e) => setFilterSearch(e.target.value)}
                placeholder="Search requests by artist, title, record label..."
                className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 shrink-0">
              {[
                { id: "all", label: "All Requests" },
                { id: "voting", label: "Active Voting" },
                { id: "processing", label: "Processing Release" }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilterStatus(tab.id as any)}
                  className={`px-3 py-1 rounded text-[10px] font-mono uppercase font-bold transition cursor-pointer ${
                    filterStatus === tab.id
                      ? "bg-amber-500 text-slate-955 shadow-sm text-slate-950 leading-normal"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Queued Tracks Listing */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-[#0d1017]">
            
            <div className="hidden sm:grid grid-cols-12 gap-3 px-5 py-2.5 bg-slate-900 border-b border-slate-800 text-[9px] font-mono font-bold text-slate-500 uppercase tracking-widest">
              <div className="col-span-6">Track Request details & Label</div>
              <div className="col-span-4 text-center">Community Votes progress</div>
              <div className="col-span-2 text-right pr-2">Cast Vote</div>
            </div>

            <div className="divide-y divide-slate-900">
              {filteredRequests.length > 0 ? (
                filteredRequests.map((req) => {
                  const alreadyVoted = votedRequestIds.includes(req.id);
                  const progressPct = Math.min(100, Math.round((req.currentVotes / req.targetVotes) * 100));
                  
                  return (
                    <div 
                      key={req.id}
                      className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center p-4 sm:p-5 hover:bg-slate-950/40 transition duration-150"
                    >
                      
                      {/* Name, artist, sources */}
                      <div className="col-span-6 flex items-start gap-3.5 min-w-0">
                        <div className="h-8 w-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-amber-550 shrink-0">
                          {req.status === "processing" ? (
                            <Clock className="h-4 w-4 text-emerald-400 animate-pulse" />
                          ) : (
                            <Disc className="h-4 w-4 text-amber-500 animate-[spin_6s_linear_infinite]" />
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <h4 className="font-bold text-white text-[12px] truncate leading-tight tracking-wide">
                            {req.title}
                          </h4>
                          <p className="text-[10px] text-slate-400 truncate mt-0.5">by {req.artist}</p>
                          
                          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                            <span className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[8px] font-mono text-amber-400 uppercase font-bold">
                              🏷️ {req.label}
                            </span>
                            <span className="px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[8px] font-mono text-slate-450 uppercase">
                              {req.genre}
                            </span>
                            <a 
                              href={req.url} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-[#0005] hover:bg-[#000] border border-slate-800/60 rounded text-[8px] text-blue-400 transition"
                            >
                              <Link2 className="h-2 w-2" /> Beatport Link
                            </a>
                          </div>
                        </div>
                      </div>

                      {/* Vote Progress state */}
                      <div className="col-span-4 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] font-mono leading-none">
                          <span className={`font-bold ${req.status === "processing" ? "text-emerald-400" : "text-amber-500"}`}>
                            {req.status === "processing" ? "Target Achieved!" : `${req.currentVotes} / ${req.targetVotes} Votes`}
                          </span>
                          <span className="text-slate-500">{progressPct}%</span>
                        </div>
                        
                        <div className="h-2 w-full rounded-full bg-slate-900 overflow-hidden border border-slate-800/85">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              req.status === "processing"
                                ? "bg-gradient-to-r from-emerald-500 to-teal-400"
                                : "bg-gradient-to-r from-amber-600 to-amber-400"
                            }`} 
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between text-[8px] font-mono text-slate-500 leading-none">
                          <span>Requested by: {req.submittedBy}</span>
                          <span>{req.status === "processing" ? "Unlocking Soon" : "Open Target"}</span>
                        </div>
                      </div>

                      {/* Vote trigger action button */}
                      <div className="col-span-2 flex justify-start sm:justify-end">
                        {req.status === "processing" ? (
                          <span className="px-2.5 py-1.5 rounded-lg text-[9px] font-mono uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-505/20 font-black tracking-wider shadow">
                            ✓ Processing
                          </span>
                        ) : (
                          <button
                            onClick={() => handleVoteRequest(req.id)}
                            disabled={alreadyVoted}
                            className={`w-full sm:w-auto px-4 py-1.5 rounded-lg text-[10px] font-mono font-bold uppercase transition duration-300 flex items-center justify-center gap-1 border cursor-pointer ${
                              alreadyVoted
                                ? "bg-slate-900 border-slate-950 text-slate-500 cursor-not-allowed"
                                : "bg-amber-500 border-amber-600 hover:bg-amber-400 text-slate-950 hover:scale-[1.02] shadow"
                            }`}
                          >
                            <ThumbsUp className="h-3 w-3" />
                            {alreadyVoted ? "Voted" : "Vote"}
                          </button>
                        )}
                      </div>

                    </div>
                  );
                })
              ) : (
                <div className="text-center py-16 font-mono text-xs text-slate-500">
                  <AlertCircle className="h-7 w-7 text-slate-700 mx-auto mb-2" />
                  No track requests matched the active search or filters.
                </div>
              )}
            </div>

          </div>

          {/* Info FAQ Box */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/20 text-xs leading-relaxed text-slate-450 space-y-1 select-text">
            <h4 className="font-bold text-white uppercase text-[10px] tracking-wider mb-2 font-mono flex items-center gap-1 text-amber-500">
              <Calendar className="h-3.5 w-3.5" /> How Does Soundeo voting Work?
            </h4>
            <p>
              1. **Request Submission**: Enter details derived from Beatport, Traxsource or Juno. Premium subscribers get direct lower down targets (only requires 35 votes instead of 50).
            </p>
            <p>
              2. **Dailies Limits**: Silver plans get 3 request voting coupons daily, Gold gets 10, Platinum enjoys unlimited voting and request priority queueing instantly.
            </p>
            <p>
              3. **Final Unlocks**: Unlocked files are converted into uncompressed WAV files and bundled with their 320kbps MP3 variants. The track moves permanently into our catalog directory for all registered members to retrieve offline easily.
            </p>
          </div>

        </div>

        {/* Right Column: REQUEST FORM MODULE (4 Cols) */}
        <div className="lg:col-span-4 rounded-xl bg-[#0f1420] border border-slate-800 p-5 space-y-5">
          <div className="space-y-1">
            <h3 className="font-display font-black text-sm text-white flex items-center gap-1.5 uppercase">
              <Plus className="h-4.5 w-4.5 text-amber-500" /> Request New Track
            </h3>
            <p className="text-[11px] text-slate-500">
              Paste a Beatport/Spotify URL and let the community vote to acquire it!
            </p>
          </div>

          {formSuccess && (
            <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium flex items-start gap-2 animate-fadeIn leading-relaxed">
              <Check className="h-4 w-4 shrink-0 mt-0.5 text-emerald-500" />
              <div>
                <strong>Track Request Registered!</strong> Upvote pool has successfully been generated for the community. Redirecting set details...
              </div>
            </div>
          )}

          {formError && (
            <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-450 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
              <AlertCircle className="h-4 w-4 shrink-0 text-red-500" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSubmitRequest} className="space-y-4 text-xs font-sans">
            <div className="space-y-1.5">
              <label className="block text-slate-405 font-mono uppercase text-[9px] tracking-wider font-bold">Track Title</label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g., Take It Off"
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-700 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-405 font-mono uppercase text-[9px] tracking-wider font-bold">Artist / Producer</label>
              <input
                type="text"
                value={newArtist}
                onChange={(e) => setNewArtist(e.target.value)}
                placeholder="e.g., Fisher ft. Aatig"
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-700 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="block text-slate-405 font-mono uppercase text-[9px] tracking-wider font-bold">Record Label</label>
                <input
                  type="text"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="e.g., Catch & Release"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-700 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-slate-405 font-mono uppercase text-[9px] tracking-wider font-bold">Track Genre</label>
                <select
                  value={newGenre}
                  onChange={(e) => setNewGenre(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 cursor-pointer"
                >
                  <option value="Tech House">Tech House</option>
                  <option value="Deep House">Deep House</option>
                  <option value="House">House</option>
                  <option value="Techno">Techno</option>
                  <option value="Progressive House">Progressive House</option>
                  <option value="Trance">Trance</option>
                  <option value="Dubstep">Dubstep</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-405 font-mono uppercase text-[9px] tracking-wider font-bold">Beatport / Store URL link</label>
              <input
                type="url"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                placeholder="https://www.beatport.com/track/..."
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-700 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg text-xs font-mono font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 tracking-wider shadow-lg flex items-center justify-center gap-1.5 cursor-pointer uppercase transition duration-300"
              >
                <Send className="h-3.5 w-3.5 shrink-0" />
                Submit and Vote Request
              </button>
            </div>
          </form>

          {/* Submission status limits notes */}
          <div className="flex gap-2 p-3 bg-slate-950 rounded-lg text-[10px] text-slate-500 leading-normal border border-slate-800/80">
            <Coins className="h-4 w-4 shrink-0 text-amber-500 mt-0.5" />
            <div>
              <strong>Daily limit:</strong> Standard trial profiles can declare 1 request daily, while Upgrade subs plans enjoy priority approvals.
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
