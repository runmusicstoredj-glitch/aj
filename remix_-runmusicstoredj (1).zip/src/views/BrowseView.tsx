import React, { useState, useEffect } from "react";
import { 
  Search, RotateCcw, AlertCircle, Headphones, Sliders, LayoutGrid, 
  Menu, Play, Pause, Download, Trash2, Flame, Coins, Activity, 
  Sparkles, Check, ChevronRight, Lock, HelpCircle 
} from "lucide-react";
import { Track, GENRES, UserAccount } from "../types";
import TrackCard from "../components/TrackCard";

interface BrowseViewProps {
  tracks: Track[];
  onPlayTrack: (track: Track) => void;
  onDownloadTrack: (track: Track) => void;
  playingTrackId: string | null;
  isPlaying: boolean;
  isAdmin: boolean;
  onDeleteTrack?: (id: string) => void;
  lightMode?: boolean;
}

export default function BrowseView({
  tracks,
  onPlayTrack,
  onDownloadTrack,
  playingTrackId,
  isPlaying,
  isAdmin,
  onDeleteTrack,
  lightMode = true,
}: BrowseViewProps) {
  const [search, setSearch] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("");
  const [selectedKey, setSelectedKey] = useState("");
  const [minBpm, setMinBpm] = useState(60);
  const [maxBpm, setMaxBpm] = useState(180);
  const [contentType, setContentType] = useState("");
  
  // Layout state: "list" (Arsenal List - Default matching music.bangerz-army.com/arsenal) or "grid" (Standard Bento Grid)
  const [displayLayout, setDisplayLayout] = useState<"list" | "grid">("list");
  
  // Sort state
  const [sortBy, setSortBy] = useState<"latest" | "bpm" | "key" | "title">("latest");

  // Local user cache to display HUD balance matching Arsenal
  const [localUser, setLocalUser] = useState<UserAccount | null>(null);

  useEffect(() => {
    const handleSyncUser = () => {
      const cached = localStorage.getItem("deck_user_account_v2");
      if (cached) {
        try {
          setLocalUser(JSON.parse(cached));
        } catch (e) {
          // Ignore
        }
      }
    };
    handleSyncUser();
    // Add window focus trigger to sync credits live
    window.addEventListener("focus", handleSyncUser);
    return () => window.removeEventListener("focus", handleSyncUser);
  }, [playingTrackId]); // Re-sync on track unlocks/actions

  // Extract unique keys
  const keys = Array.from(new Set(tracks.map((t) => t.key.toUpperCase()))).filter(Boolean).sort();

  // Reset Filters
  const handleResetFilters = () => {
    setSearch("");
    setSelectedGenre("");
    setSelectedKey("");
    setMinBpm(60);
    setMaxBpm(185);
    setContentType("");
  };

  // Extract terms like 'Intro', 'Bootleg', 'Mashup', 'Stems' to show as a premium tag
  const getDynamicTag = (title: string, trackGenre: string) => {
    const upper = title.toUpperCase();
    if (upper.includes("INTRO") || upper.includes("HYPE")) return { text: "INTRO EDIT", color: "bg-red-50 text-red-600 border border-red-100" };
    if (upper.includes("BOOTLEG")) return { text: "BOOTLEG", color: "bg-orange-50 text-orange-600 border border-orange-100" };
    if (upper.includes("STEMS") || upper.includes("STEM")) return { text: "STEMS KIT", color: "bg-purple-50 text-purple-600 border border-purple-100" };
    if (upper.includes("REMIX") || upper.includes("RMX")) return { text: "REMIX", color: "bg-emerald-50 text-emerald-600 border border-emerald-100" };
    if (upper.includes("MASHUP")) return { text: "MASHUP", color: "bg-pink-50 text-pink-600 border border-pink-100" };
    if (upper.includes("QUICK") || upper.includes("SHORT")) return { text: "QUICK HITTER", color: "bg-amber-50 text-amber-600 border border-amber-100" };
    if (upper.includes("REDRUM")) return { text: "REDRUM", color: "bg-rose-50 text-rose-600 border border-rose-100" };
    if (upper.includes("TRANSITION")) return { text: "TRANSITION", color: "bg-amber-50 text-amber-600 border border-amber-100" };
    
    // Default fallback base tags
    if (trackGenre.toLowerCase() === "exclusive") return { text: "EXCLUSIVE DECK", color: "bg-yellow-50 text-yellow-600 border border-yellow-105" };
    return { text: "EXTENDED", color: "bg-slate-100 text-slate-600 border border-slate-200" };
  };

  const filteredTracks = tracks.filter((track) => {
    const matchesSearch =
      track.title.toLowerCase().includes(search.toLowerCase()) ||
      track.artist.toLowerCase().includes(search.toLowerCase());
    const matchesGenre = selectedGenre === "" || track.genre.toLowerCase() === selectedGenre.toLowerCase();
    const matchesKey = selectedKey === "" || track.key.toUpperCase() === selectedKey.toUpperCase();
    const matchesBpm = track.bpm >= minBpm && track.bpm <= maxBpm;
    const matchesContentType =
      contentType === "" ||
      track.contentType === contentType ||
      (contentType === "track" && !track.contentType);

    return matchesSearch && matchesGenre && matchesKey && matchesBpm && matchesContentType;
  });

  // Sort logic
  const sortedTracks = [...filteredTracks].sort((a, b) => {
    if (sortBy === "bpm") return b.bpm - a.bpm;
    if (sortBy === "key") return a.key.localeCompare(b.key);
    if (sortBy === "title") return a.title.localeCompare(b.title);
    // default "latest"
    return new Date(b.createdAt || "").getTime() - new Date(a.createdAt || "").getTime();
  });

  return (
    <div className="space-y-6 py-4 font-sans" id="tactical-arsenal-view">
      
      {/* 1. Tactical Combat-Styled Top HUD Info bar */}
      <div className="rounded-2xl border border-slate-205 bg-white shadow-md p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        {/* Glow indicator decoration */}
        <div className="absolute top-0 right-0 h-44 w-44 bg-blue-500/[0.03] rounded-full blur-[60px] pointer-events-none" />
        
        <div className="space-y-1.5 z-10">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 rounded-full bg-blue-600 animate-ping" />
            <span className="px-2 py-0.5 bg-blue-50 border border-blue-100 rounded font-mono text-[10px] font-black text-blue-600 tracking-wider uppercase">
              SYSTEM LIVE
            </span>
            <span className="text-[10px] text-slate-450 font-mono">BANGERZ ARMY PORTAL v4.2</span>
          </div>
          <h2 className="font-display text-2xl lg:text-3xl font-black text-blue-650 tracking-tight flex items-center gap-2.5">
            <Flame className="h-7 w-7 text-blue-600 fill-blue-500/10" />
            Bangerz Arsenal Pool Directory
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed max-w-xl">
            Browse through single tracks and premium packages with <strong>Lossless WAV 24-bit / Stems Kits</strong>, fully equipped for professional DJs to ignite any dance floor.
          </p>
        </div>

        {/* Live HUD statistics */}
        <div className="flex flex-wrap items-center gap-3 md:self-center z-10">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-center font-mono shadow-sm">
            <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">ARMAMENTS LOADED</p>
            <p className="text-lg font-black text-blue-650 mt-0.5">{sortedTracks.length} Tracks</p>
          </div>
          {localUser && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-center font-mono shadow-sm">
              <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">DJ ACCOUNT BALANCE</p>
              <p className="text-lg font-black text-emerald-600 mt-0.5 flex items-center gap-1">
                <Coins className="h-4 w-4 text-emerald-650" />
                {localUser.subTier === "platinum" ? "UNLIMITED" : `${localUser.credits} CR`}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* 2. Tactical Controller Panel Deck (Filters) */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-md relative" id="arsenal-filters-deck">
        <h4 className="text-[10px] font-black tracking-widest text-blue-600 uppercase font-mono mb-4 flex items-center gap-1.5">
          <Sliders className="h-4 w-4" /> COMMAND REGULATOR (System Filters Configuration)
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Scanning Input */}
          <div className="relative">
            <label className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono mb-2">
              SECTOR SCANNER (Search Keywords)
            </label>
            <div className="relative">
              <Search className="absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                id="search-input"
                type="text"
                placeholder="Search title, artist..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 text-xs focus:outline-none focus:border-blue-600 hover:border-slate-300 transition duration-300 font-mono"
              />
            </div>
          </div>

          {/* Genre Sector Sector */}
          <div>
            <label className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono mb-2">
              GENRE CLASSIFICATION (Category Filter)
            </label>
            <select
              id="genre-select"
              value={selectedGenre}
              onChange={(e) => setSelectedGenre(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-705 text-xs focus:outline-none focus:border-blue-600 hover:border-slate-300 transition duration-350 cursor-pointer font-mono"
            >
              <option value="">ALL SECTORS (All Genres)</option>
              {GENRES.map((g) => (
                <option key={g} value={g}>
                  {g.toUpperCase()}
                </option>
              ))}
            </select>
          </div>

          {/* Key Selection */}
          <div>
            <label className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono mb-2">
              HARMONIC FREQUENCY KEY (Camelot Scale)
            </label>
            <select
              id="key-select"
              value={selectedKey}
              onChange={(e) => setSelectedKey(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-705 text-xs focus:outline-none focus:border-blue-600 hover:border-slate-300 transition duration-350 cursor-pointer font-mono"
            >
              <option value="">ALL FREQUENCY KEYS</option>
              {keys.map((k) => (
                <option key={k} value={k}>
                  ⚡ KEY {k.toUpperCase()} (CAMELOT)
                </option>
              ))}
            </select>
          </div>

          {/* Tempo Controls & Sort */}
          <div className="flex flex-col justify-between">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono">
                TEMPO / SPEED RANGE ({minBpm}-{maxBpm} BPM)
              </label>
              <button
                id="reset-filters"
                onClick={handleResetFilters}
                className="text-[9px] font-black uppercase text-blue-600 hover:text-blue-800 transition flex items-center gap-1 font-mono cursor-pointer"
              >
                <RotateCcw className="h-2.5 w-2.5" /> RE-ALIGN
              </button>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={60}
                max={185}
                value={minBpm}
                onChange={(e) => setMinBpm(parseInt(e.target.value))}
                className="w-full h-1 bg-slate-100 rounded appearance-none cursor-pointer accent-blue-600 border border-slate-200"
              />
              <input
                type="range"
                min={60}
                max={185}
                value={maxBpm}
                onChange={(e) => setMaxBpm(parseInt(e.target.value))}
                className="w-full h-1 bg-slate-100 rounded appearance-none cursor-pointer accent-blue-600 border border-slate-200"
              />
            </div>
          </div>
        </div>

        {/* 2.5 Quick filters pills (Intro Edits, Packs, Acapellas) */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-extrabold">FAST REGULATION:</span>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: "", label: "ALL BULLETS" },
                { id: "track", label: "SINGLES ONLY" },
                { id: "pack", label: "PACKS & EDITS" }
              ].map((type) => (
                <button
                  key={type.id}
                  onClick={() => setContentType(type.id)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-mono font-bold uppercase transition cursor-pointer border ${
                    contentType === type.id
                      ? "bg-blue-50 text-blue-600 border-blue-200 shadow-sm"
                      : "bg-transparent text-slate-500 border-slate-200 hover:text-slate-800 hover:bg-slate-50"
                  }`}
                >
                  {type.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sort selection drop and Layout settings */}
          <div className="flex items-center gap-3">
            {/* Sort by parameter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-mono text-slate-400 uppercase">SORT BY:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 text-[10px] font-mono text-slate-600 py-1 px-2.5 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer"
              >
                <option value="latest">LATEST BANGERZ</option>
                <option value="bpm">TEMPO (BPM)</option>
                <option value="key">HARMONIC KEY</option>
                <option value="title">ALPHABETICAL (A-Z)</option>
              </select>
            </div>

            {/* Layout Toggle Buttons - Crucial matching the professional list design */}
            <div className="flex items-center bg-slate-50 border border-slate-200 p-1 rounded-xl">
              <button
                onClick={() => setDisplayLayout("list")}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  displayLayout === "list" 
                    ? "bg-blue-50 text-blue-600 border border-blue-105" 
                    : "text-slate-450 hover:text-slate-700"
                }`}
                title="Arsenal List View (Recommended)"
              >
                <Menu className="h-4 w-4" />
              </button>
              <button
                onClick={() => setDisplayLayout("grid")}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  displayLayout === "grid" 
                    ? "bg-blue-50 text-blue-600 border border-blue-105" 
                    : "text-slate-450 hover:text-slate-700"
                }`}
                title="Large Card Deck (Grid)"
              >
                <LayoutGrid className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Main Catalog Display Space */}
      {sortedTracks.length > 0 ? (
        displayLayout === "list" ? (
          /* ========================================================
             3A. THE COMPACT LIST VIEW ("Bangerz Arsenal Pool Table")
             ======================================================== */
          <div className="border border-slate-205 rounded-2xl overflow-hidden bg-white shadow-sm" id="arsenal-table-list">
            
            {/* Table Header Row */}
            <div className="hidden lg:grid grid-cols-12 gap-3 px-6 py-1.5 bg-slate-50 border-b border-slate-200 text-[9px] font-mono font-extrabold text-slate-500 uppercase tracking-widest">
              <div className="col-span-1 text-center">PLAY</div>
              <div className="col-span-4">TRACK DETAILS & REMIX VER</div>
              <div className="col-span-1 text-center">BPM</div>
              <div className="col-span-1 text-center">KEY</div>
              <div className="col-span-1">GENRE</div>
              <div className="col-span-2 text-center">HARMONIC PREVIEW PULSE</div>
              <div className="col-span-2 text-right">DOWNLOAD</div>
            </div>

            {/* Table Content Tracks */}
            <div className="divide-y divide-slate-100 font-sans">
              {sortedTracks.map((track, index) => {
                const isLocalPlaying = playingTrackId === track.id && isPlaying;
                const releaseVersion = getDynamicTag(track.title, track.genre);
                
                return (
                  <div 
                    key={track.id}
                    className={`grid grid-cols-1 lg:grid-cols-12 gap-1 lg:gap-3 items-center px-4 lg:px-5 py-1 lg:py-[3px] transition-all duration-300 ${
                      isLocalPlaying 
                        ? "bg-blue-50/40 border-l-2 border-blue-600" 
                        : "hover:bg-slate-50"
                    }`}
                  >
                    
                    {/* Column 1: Play/Pause controls */}
                    <div className="col-span-1 flex items-center justify-center lg:block">
                      <button
                        onClick={() => onPlayTrack(track)}
                        className={`h-6.5 w-6.5 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer ${
                          isLocalPlaying
                            ? "bg-blue-600 text-white font-black shadow-md shadow-blue-500/20"
                            : "bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 hover:border-blue-300"
                        }`}
                        title={isLocalPlaying ? "Pause Sound" : "Play preview sound"}
                      >
                        {isLocalPlaying ? (
                          <Pause className="h-2.5 w-2.5 fill-current stroke-[2.5]" />
                        ) : (
                          <Play className="h-2.5 w-2.5 fill-current ml-[1px]" />
                        )}
                      </button>
                    </div>

                    {/* Column 2: Cover Art + Info Details */}
                    <div className="col-span-4 flex items-center gap-2 min-w-0">
                      {/* Dense Image Square container */}
                      <div className="h-7 w-7 rounded overflow-hidden border border-slate-200 shrink-0 select-none bg-slate-100 relative">
                        <img 
                          src={track.coverUrl} 
                          className="h-full w-full object-cover" 
                          alt={track.title} 
                          referrerPolicy="no-referrer"
                        />
                        {isLocalPlaying && (
                          <div className="absolute inset-0 bg-blue-500/10 flex items-center justify-center">
                            <Activity className="h-2.5 w-2.5 text-blue-600 animate-spin" />
                          </div>
                        )}
                      </div>

                      {/* Stacked Artist info and tag badges */}
                      <div className="min-w-0 flex-1 py-0.5">
                        <div className="flex items-center gap-1 flex-wrap">
                          <span className={`text-[6.5px] font-black uppercase px-1 py-0.2 rounded leading-none border ${releaseVersion.color}`}>
                            {releaseVersion.text}
                          </span>
                          <span className={`text-[6.5px] font-bold uppercase px-1 py-0.2 bg-slate-50 border border-slate-200 rounded leading-none text-slate-500`}>
                            {track.contentType === "pack" ? "DJ PACK" : "SINGLE"}
                          </span>
                          {track.audioUrl.startsWith("https://storage.googleapis.com/") && (
                            <span className="text-[6.5px] font-black uppercase px-1 py-0.1 bg-sky-50 border border-sky-100 rounded leading-none text-sky-600 font-mono">
                              ☁️ GCS CDN
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-slate-800 text-[11px] truncate leading-tight hover:text-blue-600 transition cursor-pointer" onClick={() => onPlayTrack(track)}>
                          {track.title}
                        </h4>
                        <p className="text-[9.5px] text-slate-505 truncate leading-none font-normal">
                          by {track.artist}
                        </p>
                      </div>
                    </div>

                    {/* Column 3: Numeric BPM */}
                    <div className="col-span-1 flex lg:justify-center items-center gap-1 font-mono text-xs">
                      <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">BPM:</span>
                      <span className="font-bold text-blue-600 uppercase bg-blue-50 px-1.5 py-0.2 rounded border border-blue-100 shrink-0 text-[10px]">
                        {track.bpm} <span className="text-[7.5px] font-normal text-slate-400 font-sans">bpm</span>
                      </span>
                    </div>

                    {/* Column 4: Harmonic Key */}
                    <div className="col-span-1 flex lg:justify-center items-center gap-1 font-mono text-xs">
                      <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">KEY:</span>
                      <span className="font-extrabold text-purple-600 uppercase bg-purple-50 px-1.5 py-0.2 rounded border border-purple-100 shrink-0 text-[10px]">
                        ⚡ {track.key}
                      </span>
                    </div>

                    {/* Column 5: Genre sector info */}
                    <div className="col-span-1 flex items-center gap-1 font-mono">
                      <span className="lg:hidden text-slate-500 text-[8px] uppercase font-bold">GENRE:</span>
                      <span className="px-1.5 py-0.2 bg-slate-55 rounded border border-slate-200 text-slate-600 font-bold tracking-tight text-[9px] uppercase">
                        {track.genre}
                      </span>
                    </div>

                    {/* Column 6: Simulated Waveform preview indicator (Highly interactive look!) */}
                    <div className="col-span-2 hidden lg:flex items-center h-6 px-2 justify-center font-mono">
                      {isLocalPlaying ? (
                        /* Vibrant live sound waves visualization */
                        <div className="flex items-center gap-[3px] h-4 w-full px-2" id="live-soundwave">
                          <span className="h-1 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.1s_alternate]" />
                          <span className="h-3 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.3s_alternate]" />
                          <span className="h-1.5 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.5s_alternate]" />
                          <span className="h-3.5 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.2s_alternate]" />
                          <span className="h-2 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.4s_alternate]" />
                          <span className="h-1 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.7s_alternate]" />
                          <span className="h-2.5 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.3s_alternate]" />
                          <span className="h-1.5 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.6s_alternate]" />
                          <span className="h-2 w-0.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-full animate-[bounce_1s_infinite_0.1s_alternate]" />
                        </div>
                      ) : (
                        /* Standard clean micro tactical soundwave map grid */
                        <div className="h-[1px] w-full bg-slate-200 relative flex items-center">
                          <div className="absolute left-1/3 h-2 w-[1px] bg-slate-100" />
                          <div className="absolute left-2/3 h-2 w-[1px] bg-slate-100" />
                          <span className="font-mono text-[5.5px] text-slate-400 uppercase absolute left-1 -top-2 tracking-widest select-none">PREVIEW SCANNER</span>
                        </div>
                      )}
                    </div>

                    {/* Column 7: Pricing, Checkout & Action triggers */}
                    <div className="col-span-2 flex items-center justify-between lg:justify-end gap-2.5 mt-1 lg:mt-0 pt-1 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                      <div className="flex items-center gap-1 font-mono text-emerald-600 text-[9px] font-bold">
                        <Coins className="h-2.5 w-2.5 text-emerald-600" />
                        {track.contentType === "pack" ? "3 CR" : "1 CR"}
                      </div>

                      <div className="flex items-center gap-1">
                        {/* Admin Delete fallback control */}
                        {isAdmin && onDeleteTrack && (
                          <button
                            onClick={() => onDeleteTrack(track.id)}
                            className="p-1 border border-red-150 bg-red-50 text-red-650 rounded-lg hover:bg-red-655 hover:text-white transition cursor-pointer"
                            title="Remove from database"
                          >
                            <Trash2 className="h-2.5 w-2.5" />
                          </button>
                        )}

                        <button
                          onClick={() => onDownloadTrack(track)}
                          className="px-2 py-0.5 rounded-lg text-[9px] font-mono font-bold bg-slate-50 border border-slate-200 text-slate-700 hover:border-blue-400 hover:text-blue-605 hover:bg-blue-50 transition duration-300 flex items-center gap-0.5 cursor-pointer"
                        >
                          <Download className="h-2.5 w-2.5 shrink-0" />
                          AERODROP
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* ========================================================
             3B. THE GRID CARD DECK VIEW (Bento Styled Cards Grid)
             ======================================================== */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="tracks-cards-grid">
            {sortedTracks.map((track) => (
              <TrackCard
                key={track.id}
                track={track}
                isPlaying={playingTrackId === track.id && isPlaying}
                onPlayClick={() => onPlayTrack(track)}
                onDownloadClick={() => onDownloadTrack(track)}
                isAdmin={isAdmin}
                onDeleteClick={onDeleteTrack ? () => onDeleteTrack(track.id) : undefined}
              />
            ))}
          </div>
        )
      ) : (
        /* Empty State Warning matching Battlefield theme */
        <div 
          className="flex flex-col items-center justify-center py-16 px-6 border border-dashed border-slate-200 rounded-2xl bg-slate-50 text-center space-y-4"
          id="tracks-empty-state"
        >
          <div className="h-14 w-14 rounded-full bg-white border border-slate-200 flex items-center justify-center text-blue-600">
            <AlertCircle className="h-7 w-7" />
          </div>
          <div className="max-w-xs space-y-1">
            <h4 className="font-extrabold text-slate-800 uppercase text-xs font-mono tracking-widest text-blue-600">SCAN SEQUENCE COMPLETE: 0 RESULTS</h4>
            <p className="text-xs text-slate-500 leading-relaxed font-sans">
              No DJ arsenal tracks matched your current scanning filters. Try clicking the RE-ALIGN button above to reset scanner.
            </p>
          </div>
          <button
            onClick={handleResetFilters}
            className="text-xs font-bold bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-500 text-slate-700 px-4 py-2 rounded-xl transition cursor-pointer font-mono shadow-sm"
          >
            RE-ALIGN SCANNER (Reset Filters)
          </button>
        </div>
      )}
      
      {/* 4. Strategic Guide/FAQ Block */}
      <section className="p-6 rounded-2xl border border-slate-200 bg-white shadow-sm grid grid-cols-1 md:grid-cols-3 gap-6" id="tactical-pool-guide">
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 font-mono text-blue-600 text-xs font-bold">
            <Sparkles className="h-4 w-4" /> BANGERZ RULES
          </div>
          <h4 className="font-extrabold text-slate-800 text-base">Download & Quality Rules</h4>
          <p className="text-xs text-slate-505 leading-relaxed">
            Standard free players download 320kbps MP3 only. Upgrading to Silver, Gold, or Platinum plans unlocks offline retrieval of Lossless 24-bit WAV files.
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-1.5 font-mono text-blue-600 text-xs font-bold">
            <HelpCircle className="h-4 w-4" /> HARMONIC MIXING
          </div>
          <h4 className="font-extrabold text-slate-800 text-base">Harmonic Key Pairing System</h4>
          <p className="text-xs text-slate-505 leading-relaxed">
            Filter by Camelot key markings (e.g. 4A, 8A) to blend tracks smoothly in your mix with perfect frequency compatibility and no key clashes.
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-1.5 font-mono text-emerald-600 text-xs font-bold">
            <Check className="h-4 w-4 text-emerald-600" /> INSTANT DOWNLOAD
          </div>
          <h4 className="font-extrabold text-slate-800 text-base">Secure Acquisition Safeguard</h4>
          <p className="text-xs text-slate-505 leading-relaxed">
            Credits spent on unlocking tracks are logged permanently. You will not lose credits when re-downloading the same pack via the AERODROP button.
          </p>
        </div>
      </section>
    </div>
  );
}
