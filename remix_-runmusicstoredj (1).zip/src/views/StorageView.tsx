import React, { useState, useEffect } from "react";
import { 
  Cloud, 
  Database, 
  Server, 
  Settings, 
  Terminal, 
  Play, 
  Cpu, 
  ArrowRight, 
  FileAudio, 
  Coins, 
  TrendingDown, 
  Info, 
  ExternalLink, 
  Copy, 
  Check, 
  RotateCw, 
  Zap, 
  FolderLock, 
  HardDrive,
  Globe
} from "lucide-react";
import { Track } from "../types";

interface StorageViewProps {
  tracks: Track[];
  onMigrateAllToGCS: (updatedTracks: Track[]) => void;
}

interface CloudFile {
  name: string;
  size: string;
  type: string;
  bucket: string;
  storageClass: "Standard" | "Nearline" | "Coldline";
  uploadedAt: string;
  publicUrl: string;
}

export default function StorageView({ tracks, onMigrateAllToGCS }: StorageViewProps) {
  // GCS Diagnostic Checker Real Integration State
  const [testProjectId, setTestProjectId] = useState("");
  const [testBucketName, setTestBucketName] = useState("");
  const [testClientEmail, setTestClientEmail] = useState("");
  const [testPrivateKey, setTestPrivateKey] = useState("");

  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    step: string;
    message: string;
    diagnostics?: {
      projectId?: { isSet: boolean; val: string };
      bucketName?: { isSet: boolean; val: string };
      clientEmail?: { isSet: boolean; val: string };
      privateKey?: { isSet: boolean; val: string };
    };
    metadata?: {
      location?: string;
      storageClass?: string;
      locationType?: string;
    };
    files?: any[];
    error?: string;
  } | null>(null);

  // Auto diagnostic trigger on load
  const triggerGcsLiveCheck = (customData?: {
    projectId?: string;
    bucketName?: string;
    clientEmail?: string;
    privateKey?: string;
  }) => {
    setTestLoading(true);
    fetch("/api/storage/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(customData || {
        projectId: testProjectId || undefined,
        bucketName: testBucketName || undefined,
        clientEmail: testClientEmail || undefined,
        privateKey: testPrivateKey || undefined
      })
    })
      .then(res => res.json())
      .then(data => {
        setTestResult(data);
        if (data.diagnostics && !customData) {
          // prefill with whatever is in environmental config on server side
          if (data.diagnostics.projectId?.isSet && !testProjectId) {
            setTestProjectId(data.diagnostics.projectId?.val || "");
          }
          if (data.diagnostics.bucketName?.isSet && !testBucketName) {
            setTestBucketName(data.diagnostics.bucketName?.val || "");
          }
          if (data.diagnostics.clientEmail?.isSet && !testClientEmail) {
            setTestClientEmail(data.diagnostics.clientEmail?.val || "");
          }
        }
        setTestLoading(false);
      })
      .catch(err => {
        console.error("GCS Diagnostic API trigger error:", err);
        setTestResult({
          success: false,
          step: "OFFLINE_API",
          message: "Could not route to local GCS diagnostics server API endpoint.",
          error: err.message || "Failed to fetch from /api/storage/check"
        });
        setTestLoading(false);
      });
  };

  useEffect(() => {
    // Run initial self diagnosis check using backend server's active .env keys
    triggerGcsLiveCheck();
  }, []);

  // Config state
  const [projectId, setProjectId] = useState("gcp-runmusicstore-production");
  const [bucketName, setBucketName] = useState("runmusicstore-audio-assets");
  const [storageClass, setStorageClass] = useState("Standard");
  const [location, setLocation] = useState("asia-southeast1 (Bangkok)");
  const [cacheControl, setCacheControl] = useState("public, max-age=31536000");

  // Interactive Calculator State
  const [tracksCount, setTracksCount] = useState<number>(Math.max(tracks.length, 120));
  const [avgSizeMB, setAvgSizeMB] = useState<number>(35); // standard WAV/stems is ~35MB
  const [monthlyDownloads, setMonthlyDownloads] = useState<number>(5000);

  // Simulation State
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);
  const [isMigrating, setIsMigrating] = useState(false);
  const [migrationLogs, setMigrationLogs] = useState<string[]>([]);
  const [migrationProgress, setMigrationProgress] = useState(0);
  const [migrationCompleted, setMigrationCompleted] = useState(false);

  // Cloud bucket files simulation state
  const [cloudFiles, setCloudFiles] = useState<CloudFile[]>([]);

  // Calculate if current tracks are already GCS migrated
  const isAllMigrated = tracks.every(t => t.audioUrl.startsWith("https://storage.googleapis.com/") || t.audioUrl.startsWith("https://www.soundhelix.com/"));
  const migratedCount = tracks.filter(t => t.audioUrl.startsWith("https://storage.googleapis.com/")).length;

  // Sync simulated cloud files list
  useEffect(() => {
    const list: CloudFile[] = [];
    tracks.forEach(t => {
      const isCloud = t.audioUrl.startsWith("https://storage.googleapis.com/");
      const sanitizedName = t.title.toLowerCase().replace(/[^a-z0-9]/g, "_");
      
      list.push({
        name: `tracks/${sanitizedName}.wav`,
        size: isCloud ? `${avgSizeMB} MB` : "N/A (Pending Sync)",
        type: "audio/wav",
        bucket: bucketName,
        storageClass: "Standard",
        uploadedAt: isCloud ? t.createdAt.substring(0, 10) : "Not Uploaded",
        publicUrl: isCloud ? t.audioUrl : `Local path: ${t.audioUrl}`
      });
    });
    setCloudFiles(list);
  }, [tracks, bucketName, avgSizeMB]);

  // Estimate costs:
  // Traditional local VPS: Storage limit risks (Need high tier disks which are expensive)
  // GCS Standard Storage: $0.023 per GB/mo. Network egress: $0.12 per GB (Southeast Asia). Class A (writes): $0.005 / 1000. Class B (reads): $0.004 / 10000.
  const totalStorageGB = (tracksCount * avgSizeMB) / 1024;
  const totalEgressGB = (monthlyDownloads * avgSizeMB) / 1024;
  
  const gcsStorageCost = totalStorageGB * 0.023;
  const gcsEgressCost = totalEgressGB * 0.12;
  const gcsOpsCost = ((monthlyDownloads / 10000) * 0.004) + ((tracksCount / 1000) * 0.005);
  const totalGcsCost = gcsStorageCost + gcsEgressCost + gcsOpsCost;

  // Traditional VPS / Dedicated storage where resizing is static and expensive (often requires a $40-$120 /mo server with 500GB SSD and massive risk of disk exhaustion or network congestion)
  const traditionalVpsCost = Math.max(35, Math.ceil(totalStorageGB / 10) * 1.5 + 20);

  const handleCopyCode = (id: string, codeText: string) => {
    navigator.clipboard.writeText(codeText);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  // Run Simulated Migration Process
  const runMigration = () => {
    if (isMigrating) return;
    setIsMigrating(true);
    setMigrationCompleted(false);
    setMigrationProgress(0);
    setMigrationLogs([]);

    const localTracks = tracks.filter(t => t.audioUrl.startsWith("/uploads/"));
    
    if (localTracks.length === 0) {
      setMigrationLogs([
        "⚠️ No local tracks detected on Server container file system.",
        "💡 Check 'Browse Tracks' to upload new local tracks first, or select force rebuild.",
        "✨ Initializing simulation database sync..."
      ]);
    }

    const logSequence = [
      { prg: 5, log: `🚀 [SYSTEM_DIAG] Initiating Asset Migration Pipeline...` },
      { prg: 10, log: `📡 [CREDENTIALS] Validating HMAC security keys & Storage Client authentication token...` },
      { prg: 15, log: `🔒 [AUTH] HMAC handshake established with project ID: ${projectId}` },
      { prg: 22, log: `🏢 [BUCKET] Target Google Cloud Storage Bucket located: gs://${bucketName}/` },
      { prg: 30, log: `📦 [SCAN] Scanning local server disk storage. Identified ${localTracks.length} tracks waiting for Cloud transfer.` },
      ...localTracks.flatMap((t, idx) => {
        const sanitized = t.title.toLowerCase().replace(/[^a-z0-9]/g, "_");
        const basePrg = 30 + Math.round((idx / localTracks.length) * 55);
        
        return [
          { 
            prg: basePrg, 
            log: `⬆️ [STREAM] Copying [${t.title}] audio binary (WAV Lossless) to gs://${bucketName}/tracks/${sanitized}.wav` 
          },
          { 
            prg: basePrg + 2, 
            log: `⚡ [STREAM] Upload verified at edge. Size: ${avgSizeMB} MB. Content-Type: audio/wav. Cache-Control: ${cacheControl}` 
          },
          { 
            prg: basePrg + 4, 
            log: `📝 [REGISTRY] Updating SQL registry database ID [${t.id}] with public CDN path...` 
          }
        ];
      }),
      { prg: 90, log: `🧹 [CLEANUP] purging temporary uploaded files from server containers local SSD to release disk space...` },
      { prg: 95, log: `💿 [DISK] Purged local audio buffers. Reclaimed ${localTracks.length * avgSizeMB}MB disk storage space!` },
      { prg: 100, log: `✅ [COMPLETE] All DJ Tracks migrated successfully to Cloud Storage CDN. RunMusicStoreDj live.` }
    ];

    let logIndex = 0;
    const interval = setInterval(() => {
      if (logIndex < logSequence.length) {
        const step = logSequence[logIndex];
        setMigrationProgress(step.prg);
        setMigrationLogs(prev => [...prev, step.log]);
        logIndex++;
      } else {
        clearInterval(interval);
        
        // Actually modify application core tracks URL state!!
        const updatedTracks = tracks.map(t => {
          if (t.audioUrl.startsWith("/uploads/")) {
            const sanitized = t.title.toLowerCase().replace(/[^a-z0-9]/g, "_");
            return {
              ...t,
              // Transform to real look-alike Google Cloud Storage public URLs
              audioUrl: `https://storage.googleapis.com/${bucketName}/tracks/${sanitized}.wav`
            };
          }
          return t;
        });

        onMigrateAllToGCS(updatedTracks);
        setIsMigrating(false);
        setMigrationCompleted(true);
      }
    }, 280);
  };

  // Boilerplate texts
  const gcsNodeCode = `// server/gcs-storage.ts
import { Storage } from "@google-cloud/storage";
import path from "path";

// Initialize Cloud Storage client with service account credentials
const storage = new Storage({
  projectId: process.env.GCP_PROJECT_ID, // Loaded from environment secrets
  credentials: {
    client_email: process.env.GCP_CLIENT_EMAIL,
    private_key: process.env.GCP_PRIVATE_KEY?.replace(/\\\\n/g, '\\\\n'),
  }
});

const BUCKET_NAME = process.env.GCP_BUCKET_NAME || "runmusicstore-audio-assets";
export const gcsBucket = storage.bucket(BUCKET_NAME);

/**
 * Uploads a file buffer directly to Google Cloud Storage
 * @param fileBuffer - Raw Buffer from Multer memory storage
 * @param destination - Cloud path/key (e.g. "tracks/tech_house_banger.wav")
 * @param mimeType - audio/wav, audio/mpeg
 */
export async function uploadToGCS(
  fileBuffer: Buffer,
  destination: string,
  mimeType: string
): Promise<string> {
  const file = gcsBucket.file(destination);
  
  await file.save(fileBuffer, {
    metadata: {
      contentType: mimeType,
      cacheControl: "public, max-age=31536000", // Long-term cache CDN
    },
    resumable: true,
  });

  // Return GCS public access URL
  return \`https://storage.googleapis.com/\${BUCKET_NAME}/\${destination}\`;
}`;

  const expressGcsRoute = `// server.ts (Express endpoint serving Cloud Storage uploads)
import express from "express";
import multer from "multer";
import { uploadToGCS } from "./server/gcs-storage";

const app = express();

// Use Multer MemoryStorage instead of writing temporary files to local container disk
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // Allow high-res WAV up to 50MB
});

app.post("/api/tracks", upload.fields([
  { name: "audioFile", maxCount: 1 },
  { name: "coverImage", maxCount: 1 }
]), async (req, res) => {
  try {
    const files = req.files as { [fieldname: string]: Express.Multer.File[] };
    if (!files || !files.audioFile) {
      return res.status(400).json({ error: "Audio File is required!" });
    }

    const audioFile = files.audioFile[0];
    const keyPath = \`tracks/\${Date.now()}-\${audioFile.originalname}\`;

    // 🚀 Stream raw buffer directly to Google Cloud Storage (GCS)
    const audioGcsUrl = await uploadToGCS(
      audioFile.buffer, 
      keyPath, 
      audioFile.mimetype
    );

    // Cover art upload
    let coverGcsUrl = "https://images.unsplash.com/..."; // Default fallback
    if (files.coverImage) {
      const coverFile = files.coverImage[0];
      const coverPath = \`covers/\${Date.now()}-\${coverFile.originalname}\`;
      coverGcsUrl = await uploadToGCS(coverFile.buffer, coverPath, coverFile.mimetype);
    }

    // Save record with GCS links into PostgreSQL database / json registry
    const newRecord = {
      id: \`track-\${Date.now()}\`,
      title: req.body.title,
      artist: req.body.artist,
      genre: req.body.genre,
      bpm: parseInt(req.body.bpm) || 120,
      key: req.body.key || "8A",
      price: parseFloat(req.body.price) || 4.99,
      audioUrl: audioGcsUrl, // Google Cloud served!
      coverUrl: coverGcsUrl,
      createdAt: new Date().toISOString()
    };

    tracks.unshift(newRecord);
    saveTracks();

    res.status(201).json(newRecord);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});`;

  return (
    <div className="space-y-12 py-4" id="gcs-console-wrapper">
      {/* 1. Header Hero Panel */}
      <section className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 rounded-md bg-sky-500/10 px-2 py-0.5 text-xs font-mono font-bold text-sky-400 border border-sky-500/20">
            <Cloud className="h-3.5 w-3.5" /> ARCHITECTURE ADVISORY DECK
          </div>
          <h2 className="font-display text-2xl font-bold text-white tracking-tight mt-2 flex items-center gap-2">
            Google Cloud Storage (GCS) Integration
          </h2>
          <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
            Scalable storage system for massive DJ audio catalogs (Lossless WAVs, individual stems, and master cuts). Migrating your media files to Google Cloud Storage offloads web server disk overhead and optimizes download speeds globally.
          </p>
        </div>
      </section>

      {/* --- REAL-TIME GOOGLE CLOUD STORAGE INSTANT HANDSHAKE TESTING CONSOLE --- */}
      <section className="bento-card p-6 rounded-2xl bg-slate-900 border border-slate-800/80" id="live-gcs-credential-validator">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-850 pb-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-mono font-black text-emerald-400 border border-emerald-500/20">
              <Zap className="h-3 w-3 animate-pulse" /> LIVE HANDSHAKE INSTRUMENTS
            </div>
            <h3 className="font-display font-bold text-white text-base mt-1.5 flex items-center gap-2">
              <FolderLock className="h-4.5 w-4.5 text-emerald-400" /> GCS Bucket Access Handshake (Live Diagnostics Checker)
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Test end-to-end connectivity with your Google Cloud Storage bucket in real-time, validating JSON Service Account client signatures and listing active files.
            </p>
          </div>
          <button
            onClick={() => triggerGcsLiveCheck()}
            disabled={testLoading}
            className="px-4 py-2 bg-slate-950 hover:bg-slate-900 border border-slate-800 rounded-xl text-xs font-mono font-bold text-sky-450 hover:text-sky-300 transition duration-200 flex items-center gap-2 cursor-pointer disabled:opacity-40"
          >
            <RotateCw className={`h-3 w-3 ${testLoading ? "animate-spin" : ""}`} />
            RE-RUN DIAGNOSTICS
          </button>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          {/* Inputs Panel (Left) */}
          <div className="xl:col-span-5 space-y-4 bg-slate-950/40 p-5 rounded-2xl border border-slate-850">
            <h4 className="text-[11px] font-mono font-extrabold text-slate-400 flex items-center gap-1.5 uppercase tracking-wider">
              <Settings className="h-4 w-4 text-slate-500" /> credentials payload tester
            </h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
              Access permissions apply system-wide. To test customized parameters or override credentials temporarily, input the fields below and run the explicit handshake check.
            </p>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1">GCP Project ID</label>
                <input
                  type="text"
                  placeholder="e.g. runmusicstore-prod-123"
                  value={testProjectId}
                  onChange={(e) => setTestProjectId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 hover:border-slate-750 focus:border-sky-500 rounded-xl text-slate-300 font-mono transition outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1">GCS Bucket Name</label>
                <input
                  type="text"
                  placeholder="e.g. runmusicstore-audio-assets"
                  value={testBucketName}
                  onChange={(e) => setTestBucketName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 hover:border-slate-750 focus:border-sky-500 rounded-xl text-slate-300 font-mono transition outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-slate-500 uppercase mb-1">Service Account Client Email</label>
                <input
                  type="email"
                  placeholder="e.g. my-app@gcp-project.iam.gserviceaccount.com"
                  value={testClientEmail}
                  onChange={(e) => setTestClientEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 hover:border-slate-750 focus:border-sky-500 rounded-xl text-slate-300 font-mono transition outline-none"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-[10px] font-mono text-slate-500 uppercase">Service Account Private Key (JSON)</label>
                  <span className="text-[9px] text-slate-600 font-mono">Format: -----BEGIN PRIVATE KEY----- ...</span>
                </div>
                <textarea
                  placeholder="Paste your JSON private key content directly here to test"
                  value={testPrivateKey}
                  onChange={(e) => setTestPrivateKey(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 hover:border-slate-750 focus:border-sky-500 rounded-xl text-slate-300 font-mono text-[10px] transition outline-none resize-none"
                />
              </div>
            </div>

            <button
              onClick={() => triggerGcsLiveCheck({
                projectId: testProjectId,
                bucketName: testBucketName,
                clientEmail: testClientEmail,
                privateKey: testPrivateKey
              })}
              disabled={testLoading}
              className="w-full mt-2 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono text-xs rounded-xl transition duration-200 disabled:opacity-40 cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/10 animate-pulse hover:animate-none"
            >
              <Zap className="h-4 w-4 fill-current" />
              RUN EXPLICIT TEST HANDSHAKE
            </button>
          </div>

          {/* Diagnostics Report Terminal (Right) */}
          <div className="xl:col-span-7 space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <h4 className="text-[11px] font-mono font-extrabold text-slate-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Terminal className="h-4 w-4 text-emerald-400" /> live diagnostic verification ledger
              </h4>

              {/* Status banner */}
              {testLoading ? (
                <div className="p-12 rounded-2xl bg-slate-950 border border-slate-850 text-center space-y-3">
                  <RotateCw className="h-8 w-8 text-sky-400 animate-spin mx-auto" />
                  <p className="text-xs font-mono text-slate-450 uppercase animate-pulse">
                    🚀 Contacting GCS Handshake API endpoint & resolving credentials signature...
                  </p>
                </div>
              ) : testResult ? (
                <div className="space-y-4">
                  {/* Real test outcome result banner */}
                  {testResult.success ? (
                    <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 flex items-start gap-3">
                      <div className="rounded-full bg-emerald-400 text-slate-950 p-1 mt-0.5">
                        <Check className="h-4.5 w-4.5 stroke-[3]" />
                      </div>
                      <div>
                        <h5 className="font-extrabold text-white text-xs font-mono uppercase tracking-tight flex items-center gap-2">
                          SUCCESSFULLY VERIFIED GCS CONNECTION!
                        </h5>
                        <p className="text-[11px] text-slate-400 font-sans mt-0.5 leading-relaxed">
                          Your Service Account keys and API workspace permissions are valid. Direct object access to the bucket <b>gs://{testBucketName || testResult.diagnostics?.bucketName?.val}</b> is successfully authorized at 100% capacity!
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/25 flex items-start gap-3">
                      <div className="rounded-full bg-red-500 text-white p-1 mt-0.5 leading-none font-bold">
                        ⚠️
                      </div>
                      <div className="space-y-1">
                        <h5 className="font-extrabold text-white text-xs font-mono uppercase tracking-tight">
                          DIAGNOSTICS RESOLVE: INCOMPLETE ❌
                        </h5>
                        <p className="text-[11.5px] text-red-400 font-mono leading-relaxed max-w-full overflow-x-auto whitespace-pre-wrap">
                          {testResult.message}
                        </p>
                        {testResult.error && (
                          <div className="bg-slate-950 text-red-500 p-2.5 rounded-lg border border-red-500/15 font-mono text-[10px] mt-1.5 leading-normal max-w-full overflow-x-auto">
                            <b>GCP Response:</b> {testResult.error}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Environment Config Health Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-900 font-mono">
                      <span className="text-[8px] text-slate-500 uppercase block">GCP Project ID</span>
                      <span className="text-[10px] mt-1 font-bold flex items-center gap-1">
                        <span className={`h-1.5 w-1.5 rounded-full ${testResult.diagnostics?.projectId?.isSet ? "bg-emerald-400" : "bg-red-500"}`} />
                        {testResult.diagnostics?.projectId?.isSet ? testResult.diagnostics.projectId.val : "MISSING"}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-900 font-mono">
                      <span className="text-[8px] text-slate-500 uppercase block">GCS Bucket Name</span>
                      <span className="text-[10px] mt-1 font-bold flex items-center gap-1">
                        <span className={`h-1.5 w-1.5 rounded-full ${testResult.diagnostics?.bucketName?.isSet ? "bg-emerald-400" : "bg-red-500"}`} />
                        {testResult.diagnostics?.bucketName?.isSet ? testResult.diagnostics.bucketName.val : "MISSING"}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-900 font-mono">
                      <span className="text-[8px] text-slate-500 uppercase block">Service Account Email</span>
                      <span className="text-[10px] mt-1 font-bold flex items-center gap-1 truncate max-w-full">
                        <span className={`h-1.5 w-1.5 rounded-full ${testResult.diagnostics?.clientEmail?.isSet ? "bg-emerald-400" : "bg-red-500"}`} />
                        {testResult.diagnostics?.clientEmail?.isSet ? testResult.diagnostics.clientEmail.val : "MISSING"}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-900 font-mono">
                      <span className="text-[8px] text-slate-500 uppercase block">Private Key status</span>
                      <span className="text-[10px] mt-1 font-bold flex items-center gap-1">
                        <span className={`h-1.5 w-1.5 rounded-full ${testResult.diagnostics?.privateKey?.isSet ? "bg-emerald-400" : "bg-red-500"}`} />
                        {testResult.diagnostics?.privateKey?.isSet ? "CONFIGURED" : "MISSING"}
                      </span>
                    </div>
                  </div>

                  {/* If successful, show remote metadata block */}
                  {testResult.success && testResult.metadata && (
                    <div className="p-4 bg-emerald-950/20 border border-emerald-900/30 rounded-xl text-xs space-y-2">
                      <h6 className="font-bold text-white font-mono uppercase tracking-wider text-[10px] flex items-center gap-1.5 text-emerald-400">
                        <Database className="h-3.5 w-3.5" /> GCS Bucket Metadata Report (Verified)
                      </h6>
                      <div className="grid grid-cols-3 gap-4 font-mono text-[10.5px] text-slate-450">
                        <div>
                          <span className="block text-slate-550 text-[9px] uppercase">Bucket Region:</span>
                          <span className="text-white font-bold">{testResult.metadata.location}</span>
                        </div>
                        <div>
                          <span className="block text-slate-550 text-[9px] uppercase">Default Class:</span>
                          <span className="text-white font-bold">{testResult.metadata.storageClass}</span>
                        </div>
                        <div>
                          <span className="block text-slate-550 text-[9px] uppercase">Location Type:</span>
                          <span className="text-white font-bold">{testResult.metadata.locationType}</span>
                        </div>
                      </div>

                      {/* Let's show existing files found in bucket if any */}
                      {testResult.files && testResult.files.length > 0 && (
                        <div className="mt-3 pt-2.5 border-t border-slate-850">
                          <span className="block text-[9.5px] uppercase font-mono text-slate-400 mb-1 font-extrabold text-sky-400">
                            📂 Objects Found inside GCS (Live CDN Assets):
                          </span>
                          <div className="space-y-1 max-h-[80px] overflow-y-auto">
                            {testResult.files.map((file: any, idx: number) => (
                              <div key={idx} className="flex justify-between text-[10px] font-mono text-slate-400 hover:text-white border-b border-slate-900 pb-0.5">
                                <span className="truncate max-w-[260px]">gs://{testBucketName || "assets"}/{file.name}</span>
                                <span className="text-slate-550">{file.size} ({file.storageClass})</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Troubleshooter Guidance Action Box */}
                  {!testResult.success && (
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-850/80 space-y-2.5 text-xs text-slate-400 font-sans">
                      <h6 className="font-bold text-white uppercase font-mono text-[10px] text-amber-400 flex items-center gap-1">
                        🛎️ GCS Permission Troubleshooter & Configuration Guide:
                      </h6>
                      <ul className="list-decimal pl-4.5 space-y-1 text-slate-400 leading-relaxed text-[11px]">
                        <li>
                          <b>Configure Environment Secrets in AI Studio:</b> Navigate to the <b>Settings &rarr; Secrets</b> panel on the top-right of your Workspace and save these values:
                          <div className="mt-1.5 px-2.5 py-1.5 bg-slate-900 rounded font-mono text-[9px] text-sky-400 select-all space-y-0.5">
                            <p><b>GCP_PROJECT_ID</b> = "your-gcp-project-id-here"</p>
                            <p><b>GCP_BUCKET_NAME</b> = "your-gcs-bucket-name"</p>
                            <p><b>GCP_CLIENT_EMAIL</b> = "your-service-account-email@gcp-project.iam.gserviceaccount.com"</p>
                            <p><b>GCP_PRIVATE_KEY</b> = "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----"</p>
                          </div>
                        </li>
                        <li>
                          <b>Grant IAM Role Roles:</b> Ensure the Service Account email is granted the <b>Storage Object Admin</b> role or at least <b>Storage Object Creator</b> and <b>Storage Object Viewer</b> in the Google Cloud Console.
                        </li>
                        <li>
                          <b>Enable Public Read Access (Optional for instant streaming):</b> Grant the <b>allUsers</b> group the <b>Storage Object Viewer</b> role on the bucket, allowing direct playback streams from the web player.
                        </li>
                      </ul>
                    </div>
                  )}

                </div>
              ) : (
                <div className="p-8 bg-slate-950 rounded-xl text-center text-xs text-slate-500 font-mono italic">
                  No diagnostic data found. Trigger connection check above.
                </div>
              )}
            </div>
            
            <div className="text-[10.5px] text-slate-500 bg-slate-950/20 p-3 rounded-xl border border-slate-900 font-sans leading-relaxed">
              💡 <b>Real-time Handshake:</b> This utility connects directly to our server-side API proxy route. Executing the test handshake sends a secured query to real GCS environments to retrieve precise bucket metadata.
            </div>
          </div>

        </div>
      </section>

      {/* 2. Key Architecture Comparison Blueprint */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="gcs-advantages-deck">
        <div className="bento-card bento-glow-sky p-6 rounded-2xl bg-slate-900 border border-slate-800/80 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl w-fit text-red-400">
              <Server className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
              1. Local Server Disk (Legacy - Not Recommended ❌)
            </h3>
            <p className="text-xs text-slate-405 leading-relaxed font-sans">
              Storing large audio files directly on your web host SSD poses severe scalability and reliability bottlenecks:
            </p>
            <ul className="text-xs text-slate-500 list-disc pl-4 space-y-1 font-sans">
              <li>Disks eventually run out of space, risking full system crashes.</li>
              <li>High-resolution downloads (WAV/Stems) draw severe bandwidth to freeze CPU threads.</li>
              <li>Scaling to multiple server instances creates state conflicts.</li>
            </ul>
          </div>
          <div className="text-[10px] bg-red-950/10 border border-red-900/30 text-red-400 p-2.5 rounded-lg font-mono">
            ⚠️ Space: Bound to sever disk quotas with single-point failure risks.
          </div>
        </div>

        <div className="bento-card bento-glow-sky p-6 rounded-2xl bg-slate-900 border border-slate-800/80 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="p-3 bg-sky-500/10 border border-sky-500/20 rounded-xl w-fit text-sky-450">
              <Cloud className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
              2. Google Cloud Storage (Highly Recommended ✨)
            </h3>
            <p className="text-xs text-slate-405 leading-relaxed font-sans">
              Decouple media storage using high-res object tables, guaranteeing durability and isolated networks:
            </p>
            <ul className="text-xs text-slate-400 list-disc pl-4 space-y-1 font-sans">
              <li className="text-sky-305">Infinite storage capacity scales smoothly from gigabytes to petabytes.</li>
              <li>Enterprise security access models paired with Google global low-latency edges.</li>
              <li>Support for restricted <strong>Signed URLs</strong> prevents unauthorized asset leeching.</li>
            </ul>
          </div>
          <div className="text-[10px] bg-sky-950/10 border border-sky-900/30 text-sky-400 p-2.5 rounded-lg font-mono">
            💎 Best For: WAV Masters, stem multitracks, and archive packs.
          </div>
        </div>

        <div className="bento-card bento-glow-sky p-6 rounded-2xl bg-slate-900 border border-slate-800/80 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl w-fit text-indigo-400">
              <Globe className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
              3. Cloud Storage + Edge CDN (Ultimate Performance ⚡)
            </h3>
            <p className="text-xs text-slate-405 leading-relaxed font-sans">
              Mount CDN edge layers (Cloud CDN or Cloudflare) to deliver files at absolute record-breaking performance:
            </p>
            <ul className="text-xs text-slate-500 list-disc pl-4 space-y-1 font-sans">
              <li>Users download packages instantly through localized cache edges (latencies &lt; 10ms).</li>
              <li>Drastically slash egress bandwidth invoices by up to 50% or more.</li>
              <li>Defend your core server container against severe resource exhausting DDoS queries.</li>
            </ul>
          </div>
          <div className="text-[10px] bg-indigo-950/10 border border-indigo-900/30 text-indigo-400 p-2.5 rounded-lg font-mono">
            🚀 Deliveries: High speed streaming with zero buffering overhead.
          </div>
        </div>
      </section>

      {/* 3. Dynamic Migration Panel Simulator */}
      <section className="grid grid-cols-1 lg:grid-cols-5 gap-8" id="gcs-migration-wizard-deck">
        {/* Left Side: interactive credentials simulator & sync configuration */}
        <div className="lg:col-span-2 bento-card p-6 rounded-2xl bg-slate-900 border border-slate-850 space-y-5">
          <div>
            <h3 className="font-display font-extrabold text-sm text-white flex items-center gap-2">
              <Settings className="h-4.5 w-4.5 text-sky-400" /> Bucket Configuration Status
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 font-sans">
              จำลองข้อมูลเชื่อมโยงไปยัง Bucket ของคุณใน Google Cloud Console
            </p>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-[10px] uppercase font-mono text-slate-450 mb-1">GCP Project ID</label>
              <input 
                type="text" 
                value={projectId} 
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-350 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-mono text-slate-450 mb-1">Target GCS Bucket Name</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 font-mono">gs://</span>
                <input 
                  type="text" 
                  value={bucketName} 
                  onChange={(e) => setBucketName(e.target.value)}
                  className="w-full pl-11 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-350 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] uppercase font-mono text-slate-450 mb-1">Storage Class</label>
                <select 
                  value={storageClass}
                  onChange={(e) => setStorageClass(e.target.value)}
                  className="w-full px-2 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-350 focus:outline-none focus:border-sky-500 font-mono cursor-pointer"
                >
                  <option value="Standard">Standard (แนะนำ)</option>
                  <option value="Nearline">Nearline (สำรอง)</option>
                  <option value="Coldline">Coldline (เก็บถาวร)</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] uppercase font-mono text-slate-450 mb-1">Region Location</label>
                <select 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-2 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-350 focus:outline-none focus:border-sky-500 font-mono cursor-pointer"
                >
                  <option value="asia-southeast1 (Bangkok)">asia-southeast1</option>
                  <option value="asia-east1 (Taiwan)">asia-east1</option>
                  <option value="us-central1 (N. America)">us-central1</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-mono text-slate-405 mb-1">Cache-Control CDN Policy</label>
              <input 
                type="text" 
                value={cacheControl}
                onChange={(e) => setCacheControl(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-350 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800/80 space-y-3">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-slate-500">Live DB Track records:</span>
              <span className="font-extrabold text-white">{tracks.length} Items</span>
            </div>
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-slate-500 font-sans">Active files stored in GCS now:</span>
              <span className={`font-extrabold flex items-center gap-1.5 ${isAllMigrated ? "text-emerald-400" : "text-amber-400"}`}>
                <span className="h-2 w-2 rounded-full bg-current animate-pulse" />
                {isAllMigrated ? "100% (Serving GCS)" : `${migratedCount}/${tracks.length} Files Served`}
              </span>
            </div>
            
            {isAllMigrated ? (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-center text-emerald-400 font-mono">
                🎉 Congratulations! All DJ Tracks are served on GCS CDN networks. Maximum server load reduction.
              </div>
            ) : (
              <button
                onClick={runMigration}
                disabled={isMigrating}
                className="w-full bg-sky-500 text-slate-950 hover:bg-sky-450 font-bold p-3 rounded-xl disabled:opacity-50 flex items-center justify-center gap-2 text-xs transition duration-300 shadow shadow-sky-500/20 font-mono cursor-pointer"
                id="migrate-db-files-btn"
              >
                {isMigrating ? (
                  <>
                    <RotateCw className="h-4 w-4 animate-spin" />
                    MIGRATING ASSETS: {migrationProgress}%
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4 fill-current" />
                    MIGRATE DB FILES TO GCS BUCKET
                  </>
                )}
              </button>
            )}
            <p className="text-[10px] text-center text-slate-550 italic leading-snug">
              * Triggering the migration above simulates transferring local WAV/MP3 buffers from the host container to GCS bucket paths to switch active audio URLs in real-time.
            </p>
          </div>
        </div>

        {/* Right Side: Log terminal output simulator */}
        <div className="lg:col-span-3 bento-card p-6 rounded-2xl bg-slate-950 border border-slate-850 flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <span className="text-xs font-mono font-bold text-slate-400 flex items-center gap-1.5 uppercase">
              <Terminal className="h-4 w-4 text-sky-400" /> Storage Migration Core Terminal
            </span>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono">
              <span className={`inline-block h-2 w-2 rounded-full ${isMigrating ? "bg-amber-450 animate-ping" : "bg-emerald-400"}`} />
              <span>{isMigrating ? "MIGRATING" : "READY_REGISTRY_LINK"}</span>
            </div>
          </div>

          <div 
            className="flex-1 min-h-[220px] max-h-[300px] overflow-y-auto bg-slate-950 p-4 rounded-xl border border-slate-900 border-dashed font-mono text-[10.5px] text-sky-400/90 space-y-1.5 leading-snug"
            id="migration-logs-terminal"
          >
            {migrationLogs.length === 0 ? (
              <p className="text-slate-600 italic">
                {`// Storage pipeline idle. Wait for trigger key sync.
// Click "MIGRATE DB FILES TO GCS BUCKET" on the left panel to simulate live conversion.
// System will transfer /uploads/* to GCS client structure.`}
              </p>
            ) : (
              migrationLogs.map((log, idx) => (
                <p key={idx} className="animate-in slide-in-from-bottom-1 duration-150">
                  {log}
                </p>
              ))
            )}
          </div>

          <div className="grid grid-cols-3 gap-4 border-t border-slate-900 pt-4 font-mono text-center">
            <div className="p-2.5 rounded-xl bg-slate-900/40 border border-slate-850">
              <p className="text-[8px] text-slate-500 uppercase tracking-wider font-bold">Files Transferred</p>
              <p className="font-extrabold text-sm text-sky-400 mt-1">
                {migrationCompleted ? `${tracks.length} / ${tracks.length}` : (isMigrating ? `${Math.round(tracks.length * (migrationProgress/100))} / ${tracks.length}` : "0 Files")}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/40 border border-slate-850">
              <p className="text-[8px] text-slate-500 uppercase tracking-wider font-bold">Disk Reclaimed</p>
              <p className="font-extrabold text-sm text-emerald-400 mt-1">
                {migrationCompleted ? `${tracks.length * avgSizeMB} MB` : (isMigrating ? `${Math.round((tracks.length * avgSizeMB) * (migrationProgress/100))} MB` : "0 MB")}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/40 border border-slate-850">
              <p className="text-[8px] text-slate-500 uppercase tracking-wider font-bold">Server Load Relief</p>
              <p className="font-extrabold text-sm text-sky-450 mt-1">
                {migrationCompleted ? "100.0% RELIEVED" : "0.0% Idle"}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Interactive GCS vs Private Server hosting cost estimator */}
      <section className="bento-card bento-glow-purple p-6 rounded-2xl bg-slate-900 border border-slate-800" id="storage-cost-calculator">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-6">
          <div>
            <h3 className="font-display font-medium text-white flex items-center gap-2">
              <Coins className="h-5 w-5 text-yellow-500" /> Interactive Hosting Cost Estimator
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Calculate and compare operational costs for hosting professional-grade high-resolution DJ audio tracks.
            </p>
          </div>
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-indigo-400 font-mono bg-indigo-500/10 px-2.5 py-1 rounded border border-indigo-500/20">
            Storage ROI Calculator
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sliders Input Deck */}
          <div className="space-y-4 lg:border-r lg:border-slate-800 lg:pr-6">
            <h4 className="text-[10px] font-black tracking-wider text-slate-500 font-mono uppercase">Calculator Inputs</h4>
            
            <div className="space-y-1">
              <div className="flex justify-between items-center text-xs text-slate-350">
                <span>Total DJ Packs / Tracks:</span>
                <span className="font-bold text-white font-mono">{tracksCount} Packs</span>
              </div>
              <input 
                type="range" 
                min={10} 
                max={1000} 
                step={10}
                value={tracksCount} 
                onChange={(e) => setTracksCount(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg appearance-none"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-center text-xs text-slate-350">
                <span>Average Track Size (WAV/Stems):</span>
                <span className="font-bold text-white font-mono">{avgSizeMB} MB</span>
              </div>
              <input 
                type="range" 
                min={5} 
                max={100} 
                step={5}
                value={avgSizeMB} 
                onChange={(e) => setAvgSizeMB(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg appearance-none"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-center text-xs text-slate-350">
                <span>Estimated Downloads / Month:</span>
                <span className="font-bold text-white font-mono">{monthlyDownloads} Dls</span>
              </div>
              <input 
                type="range" 
                min={100} 
                max={50000} 
                step={100}
                value={monthlyDownloads} 
                onChange={(e) => setMonthlyDownloads(Number(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg appearance-none"
              />
            </div>
            
            <div className="p-3 bg-slate-950 rounded-xl text-[10.5px] font-mono leading-relaxed text-slate-500">
              ⚡ <b>GCS Storage Classes:</b> GCS provides tiered storage classes like Nearline, which can reduce storage costs by 50% for infrequently downloaded files such as old stems.
            </div>
          </div>

          {/* Results comparison blocks (3 cols) */}
          <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            
            {/* Visual graph stack */}
            <div className="space-y-4">
              <h4 className="text-[10px] font-black tracking-wider text-slate-500 font-mono uppercase">Cost comparison (Monthly)</h4>
              
              <div className="space-y-3 font-mono text-xs">
                {/* Traditional Server Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-red-400">🚨 Standard Server (HDD/SSD Expansion)</span>
                    <span className="font-bold text-white">${traditionalVpsCost.toFixed(2)}/mo</span>
                  </div>
                  <div className="w-full h-4 bg-slate-950 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500/60" style={{ width: "100%" }} />
                  </div>
                </div>

                {/* Google Cloud Storage Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-sky-400">☁️ Google Cloud Storage (Pay-as-you-go)</span>
                    <span className="font-bold text-sky-400">${totalGcsCost.toFixed(2)}/mo</span>
                  </div>
                  <div className="w-full h-4 bg-slate-950 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-sky-500" 
                      style={{ width: `${Math.max(8, Math.min(100, (totalGcsCost / traditionalVpsCost) * 100))}%` }} 
                    />
                  </div>
                </div>
              </div>

              {/* Savings callout banner */}
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-3">
                <TrendingDown className="h-6 w-6 text-emerald-400 flex-shrink-0 animate-bounce" />
                <div>
                  <h5 className="font-bold text-white text-xs">ROI Summary: Saves up to {Math.max(0, Math.round((1 - (totalGcsCost/traditionalVpsCost)) * 100))}%</h5>
                  <p className="text-[10px] text-slate-400 font-sans leading-snug">
                    Cloud Storage leverages pay-as-you-go pricing, completely eliminating upfront capital expenditures on oversized dedicated servers.
                  </p>
                </div>
              </div>
            </div>

            {/* Billing Breakdowns lists */}
            <div className="rounded-xl border border-slate-850 p-4 bg-slate-950/40 space-y-3">
              <h4 className="text-[10px] font-black tracking-wider text-slate-500 font-mono uppercase border-b border-slate-800 pb-2">Estimated GCS Invoice details</h4>
              
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-450 border-b border-slate-900 pb-1.5">
                  <span>Total Storage Volume (Active Disk):</span>
                  <span className="text-white">{totalStorageGB.toFixed(1)} GB</span>
                </div>
                <div className="flex justify-between text-slate-453 border-b border-slate-900 pb-1.5">
                  <span>Estimated Monthly Egress (Bandwidth):</span>
                  <span className="text-white">{totalEgressGB.toFixed(1)} GB</span>
                </div>
                <div className="flex justify-between text-slate-455 border-b border-slate-905 pb-1.5">
                  <span>GCS Active storage fee:</span>
                  <span className="text-white">${gcsStorageCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-455 border-b border-slate-905 pb-1.5">
                  <span>Cloud egress download bandwidth:</span>
                  <span className="text-white">${gcsEgressCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-455 border-b border-slate-905 pb-1.5">
                  <span>GCS operations & handshakes:</span>
                  <span className="text-white">${gcsOpsCost.toFixed(4)}</span>
                </div>
                <div className="flex justify-between font-bold text-sky-400 text-sm pt-1 border-t border-slate-800">
                  <span>Total Calculated Cost:</span>
                  <span>${totalGcsCost.toFixed(2)} / mo</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. Cloud Bucket Objects Browser */}
      <section className="bento-card p-6 rounded-2xl bg-slate-900 border border-slate-800" id="gcs-bucket-files-list">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-display font-medium text-white text-sm flex items-center gap-1.5">
              <HardDrive className="h-4.5 w-4.5 text-sky-400" /> Cloud Bucket File Explorer (Simulation)
            </h3>
            <p className="text-xs text-slate-400">
              List of high-fidelity Lossless tracks protected inside your Google Cloud Storage bucket (gs://{bucketName})
            </p>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            LIVE LINK SYNC WITH DATABASE
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-850 bg-slate-950/20">
          <table className="min-w-full text-xs text-left text-slate-350 border-collapse font-sans">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/40 text-[9.5px] font-mono text-slate-500 uppercase tracking-wider">
                <th scope="col" className="px-4 py-2.5">GCS Object Key</th>
                <th scope="col" className="px-4 py-2.5">File Size</th>
                <th scope="col" className="px-4 py-2.5">Mime Path</th>
                <th scope="col" className="px-4 py-2.5">Storage Class</th>
                <th scope="col" className="px-4 py-2.5">Upload Date</th>
                <th scope="col" className="px-4 py-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850/40 font-mono text-[11px]">
              {cloudFiles.map((file, idx) => {
                const isUploaded = file.size !== "N/A (Pending Sync)";
                return (
                  <tr key={idx} className="hover:bg-slate-900/10 transition-colors">
                    <td className="px-4 py-3 text-white font-semibold truncate max-w-[200px]">
                      {file.name}
                    </td>
                    <td className="px-4 py-3 text-slate-400">
                      {file.size}
                    </td>
                    <td className="px-4 py-3 text-slate-500">
                      {file.type}
                    </td>
                    <td className="px-4 py-3">
                      <span className="bg-sky-500/15 border border-sky-500/25 px-1.5 py-0.5 rounded text-[9px] text-sky-400 uppercase font-black">
                        {file.storageClass}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-400">
                      {file.uploadedAt}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-[10px] uppercase font-bold ${
                        isUploaded ? "text-emerald-400" : "text-amber-500"
                      }`}>
                        <span className={`h-1.5 w-1.5 rounded-full bg-current ${isUploaded ? "" : "animate-pulse"}`} />
                        {isUploaded ? "Served from CDN" : "Server SSD Local"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* 6. Professional Boilerplate Code templates */}
      <section className="space-y-6" id="gcs-source-code-deck">
        <div className="space-y-1">
          <h3 className="font-display font-medium text-white flex items-center gap-2">
            <Terminal className="h-5 w-5 text-sky-400" /> Production-Ready Code Integration Boilerplates
          </h3>
          <p className="text-xs text-slate-400">
            Your engineering team can integrate GCS by copying these certified boilerplates. These templates leverage Express and Multer to pipe files directly as in-memory buffers without storing files locally.
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Boilerplate Block 1 */}
          <div className="bento-card p-5 rounded-2xl bg-slate-900 border border-slate-850 flex flex-col justify-between space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-mono text-xs font-extrabold text-slate-300">File 1: server/gcs-storage.ts</span>
              <button 
                onClick={() => handleCopyCode("gcsNodeCode", gcsNodeCode)}
                className="text-xs font-mono font-bold text-slate-450 hover:text-white transition duration-200 flex items-center gap-1"
              >
                {copiedCodeId === "gcsNodeCode" ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-450" /> Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" /> Copy Node code
                  </>
                )}
              </button>
            </div>
            <pre className="p-3 bg-slate-950 font-mono text-[9px] text-slate-400 rounded-xl overflow-x-auto max-h-[380px] leading-relaxed border border-slate-900">
              {gcsNodeCode}
            </pre>
          </div>

          {/* Boilerplate Block 2 */}
          <div className="bento-card p-5 rounded-2xl bg-slate-900 border border-slate-850 flex flex-col justify-between space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-mono text-xs font-extrabold text-slate-300">File 2: Express upload endpoint</span>
              <button 
                onClick={() => handleCopyCode("expressGcsRoute", expressGcsRoute)}
                className="text-xs font-mono font-bold text-slate-450 hover:text-white transition duration-200 flex items-center gap-1"
              >
                {copiedCodeId === "expressGcsRoute" ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-450" /> Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" /> Copy upload route code
                  </>
                )}
              </button>
            </div>
            <pre className="p-3 bg-slate-950 font-mono text-[9px] text-slate-400 rounded-xl overflow-x-auto max-h-[380px] leading-relaxed border border-slate-900">
              {expressGcsRoute}
            </pre>
          </div>
        </div>
      </section>

      {/* 7. Integration steps quick-tips */}
      <section className="bg-sky-500/5 border border-sky-500/20 p-6 rounded-2xl space-y-3">
        <h4 className="font-bold text-white text-base flex items-center gap-2">
          <Info className="h-5 w-5 text-sky-400" /> Active Google Cloud Platform Integration Checklist
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-slate-400 font-sans leading-relaxed">
          <div className="space-y-1">
            <h5 className="font-extrabold text-white font-mono">1. Provision GCS Bucket</h5>
            <p>
              Open Google Cloud Console, navigate to Cloud Storage, and click "Create Bucket". Assign a unique global name and choose a location key close to your main target audience.
            </p>
          </div>
          <div className="space-y-1">
            <h5 className="font-extrabold text-white font-mono">2. IAM Setup & service keys</h5>
            <p>
              Create a Service Account, authorize roles for <strong>Storage Object Admin</strong>, then create a JSON key format. Configure your env file with these values securely.
            </p>
          </div>
          <div className="space-y-1">
            <h5 className="font-extrabold text-white font-mono">3. Install SDK dependency</h5>
            <p>
              Run <code>npm install @google-cloud/storage</code> inside your express runtime environment to utilize standard google client classes.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
