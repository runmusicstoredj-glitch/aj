import React, { useState, useRef, useEffect } from "react";
import { UploadCloud, Music, Image as ImageIcon, ShieldCheck, Lock, Trash2, Key, AlertCircle, Sparkles, Edit, X, Search, TrendingUp, Coins, Activity, Settings, Users, Flame, RotateCw, Play, CheckCircle2, Sliders } from "lucide-react";
import { Track, GENRES } from "../types";

interface AdminViewProps {
  tracks: Track[];
  onUploadTrack: (formData: FormData) => Promise<void>;
  onEditTrack: (id: string, updatedData: Partial<Track>) => Promise<void>;
  onDeleteTrack: (id: string) => Promise<void>;
  isAuthenticated: boolean;
  onAuthenticate: (code: string) => boolean;
}

export default function AdminView({
  tracks,
  onUploadTrack,
  onEditTrack,
  onDeleteTrack,
  isAuthenticated,
  onAuthenticate,
}: AdminViewProps) {
  // Authentication states
  const [passcode, setPasscode] = useState("");
  const [authError, setAuthError] = useState(false);

  // Form states
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [bpm, setBpm] = useState("124");
  const [key, setKey] = useState("8A");
  const [genre, setGenre] = useState("House");
  const [price, setPrice] = useState("4.99");
  const [contentType, setContentType] = useState<"track" | "pack">("track");

  // Track modification slot
  const [editingTrack, setEditingTrack] = useState<Track | null>(null);

  // Search and filter state inside Admin Dashboard
  const [adminSearch, setAdminSearch] = useState("");
  const [adminGenreFilter, setAdminGenreFilter] = useState("");
  const [adminTypeFilter, setAdminTypeFilter] = useState("");
  
  // File states
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [coverImage, setCoverImage] = useState<File | null>(null);
  const [isDragOverAudio, setIsDragOverAudio] = useState(false);
  const [isDragOverCover, setIsDragOverCover] = useState(false);

  // Statuses
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<"idle" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  // Refs
  const audioInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  // --- PREMIUM ADMIN SIMULATED LANDSCAPE STATES & CONTROL ACTION LOGS ---
  const [revenue, setRevenue] = useState<number>(() => {
    const saved = localStorage.getItem("admin_sim_revenue_gold");
    return saved ? parseFloat(saved) : 2465.35;
  });
  const [downloadsCount, setDownloadsCount] = useState<number>(() => {
    const saved = localStorage.getItem("admin_sim_downloads_gold");
    return saved ? parseInt(saved, 10) : 419;
  });
  const [subscribersCount, setSubscribersCount] = useState<number>(() => {
    const saved = localStorage.getItem("admin_sim_subs_gold");
    return saved ? parseInt(saved, 10) : 34;
  });

  const [logs, setLogs] = useState<Array<{ id: string; user: string; action: string; meta: string; time: string; type: "download" | "upload" | "upgrade" | "sys" }>>(() => {
    const saved = localStorage.getItem("admin_sim_logs_gold");
    if (saved) return JSON.parse(saved);
    return [
      { id: "log-1", user: "DJ PeakMaster", action: "Downloaded Stem Pack", meta: "High Tech Minimal Stems", time: "Just now", type: "download" },
      { id: "log-2", user: "System Monitor", action: "Active GCS Live Handshake Verified", meta: "Bucket Connection: OK", time: "12 mins ago", type: "sys" },
      { id: "log-3", user: "BeatMaker_Pro", action: "Upgraded Subscription Tier", meta: "Subscribed to Gold VIP Producer", time: "1 hour ago", type: "upgrade" },
      { id: "log-4", user: "DJ Sensation", action: "Downloaded Single Stem", meta: "Funky Disco Groove (WAV)", time: "2 hours ago", type: "download" },
      { id: "log-5", user: "Store Indexer", action: "Rebuilt catalog cache", meta: "Re-indexed active tracks successfully", time: "5 hours ago", type: "sys" },
    ];
  });

  // Sync simulated data with localStorage
  useEffect(() => {
    localStorage.setItem("admin_sim_revenue_gold", revenue.toString());
  }, [revenue]);

  useEffect(() => {
    localStorage.setItem("admin_sim_downloads_gold", downloadsCount.toString());
  }, [downloadsCount]);

  useEffect(() => {
    localStorage.setItem("admin_sim_subs_gold", subscribersCount.toString());
  }, [subscribersCount]);

  useEffect(() => {
    localStorage.setItem("admin_sim_logs_gold", JSON.stringify(logs));
  }, [logs]);

  // Actions
  const simulateDownload = () => {
    if (tracks.length === 0) return;
    const randomTrack = tracks[Math.floor(Math.random() * tracks.length)];
    const djs = ["DJ ElectroShock", "BasslineCrafter", "TechnoTitan", "ProgressiveDreamer", "DJ GoldenGate", "BeatChemist", "SonicWizard"];
    const randomDj = djs[Math.floor(Math.random() * djs.length)];
    
    setDownloadsCount(prev => prev + 1);
    setLogs(prev => [
      {
        id: `sim-log-${Date.now()}`,
        user: randomDj,
        action: "Simulated Download Flow",
        meta: `${randomTrack.title} (${randomTrack.genre}) - Credit Checked`,
        time: "Just now",
        type: "download"
      },
      ...prev.slice(0, 19) // keep top 20 logs
    ]);
  };

  const simulateUpgrade = () => {
    const djs = ["DJ AuraFlow", "SyncMaster", "DeepHouseThailand", "PsyTranceRider", "DJ GoldMidas", "VIP_Acoustics"];
    const randomDj = djs[Math.floor(Math.random() * djs.length)];
    const tiers = [
      { name: "Silver DJ Pro Suite", price: 14.99 },
      { name: "Gold VIP Producer", price: 29.99 },
      { name: "Platinum Elite Legend", price: 49.99 }
    ];
    const pickedTier = tiers[Math.floor(Math.random() * tiers.length)];

    setSubscribersCount(prev => prev + 1);
    setRevenue(prev => prev + pickedTier.price);
    setLogs(prev => [
      {
        id: `sim-log-${Date.now()}`,
        user: randomDj,
        action: "Simulated Subscription Upgrade",
        meta: `Subscribed to: ${pickedTier.name} (+$${pickedTier.price})`,
        time: "Just now",
        type: "upgrade"
      },
      ...prev.slice(0, 19)
    ]);
  };

  const clearLogs = () => {
    setLogs([
      { id: `sys-${Date.now()}`, user: "System Console", action: "Cleared Live Action Ledger Logs", meta: "History purged by Administrator", time: "Just now", type: "sys" }
    ]);
  };

  // Handle Authentication submit
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = onAuthenticate(passcode);
    if (success) {
      setAuthError(false);
    } else {
      setAuthError(true);
    }
  };

  // Drag and Drop hooks for audio
  const handleAudioDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOverAudio(true);
  };
  const handleAudioDragLeave = () => {
    setIsDragOverAudio(false);
  };
  const handleAudioDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOverAudio(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith("audio/")) {
        setAudioFile(file);
      } else {
        alert("Please drop an audio file.");
      }
    }
  };

  // Drag and drop info for cover image
  const handleCoverDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOverCover(true);
  };
  const handleCoverDragLeave = () => {
    setIsDragOverCover(false);
  };
  const handleCoverDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOverCover(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith("image/")) {
        setCoverImage(file);
      } else {
        alert("Please drop an image file.");
      }
    }
  };

  const handleStartEdit = (track: Track) => {
    setEditingTrack(track);
    setTitle(track.title);
    setArtist(track.artist);
    setBpm(track.bpm.toString());
    setKey(track.key);
    setGenre(track.genre);
    setPrice(track.price.toString());
    setContentType(track.contentType || "track");
    setUploadStatus("idle");
    setErrorMessage("");
  };

  const handleCancelEdit = () => {
    setEditingTrack(null);
    setTitle("");
    setArtist("");
    setBpm("124");
    setKey("8A");
    setGenre("House");
    setPrice("4.99");
    setContentType("track");
    setUploadStatus("idle");
    setErrorMessage("");
  };

  // Submit Upload or Edit Form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    setUploadStatus("idle");
    setErrorMessage("");

    try {
      if (editingTrack) {
        // Edit mode (PUT)
        await onEditTrack(editingTrack.id, {
          title,
          artist,
          bpm: parseInt(bpm) || 120,
          key,
          genre,
          price: parseFloat(price) || 0,
          contentType
        });

        // Reset Form
        setEditingTrack(null);
        setTitle("");
        setArtist("");
        setBpm("124");
        setKey("8A");
        setGenre("House");
        setPrice("4.99");
        setContentType("track");
        setUploadStatus("success");
      } else {
        // Upload mode (POST)
        if (!audioFile) {
          setUploadStatus("error");
          setErrorMessage("No audio file selected. Please select or drag an .mp3 or .wav.");
          setIsUploading(false);
          return;
        }

        const data = new FormData();
        data.append("title", title);
        data.append("artist", artist);
        data.append("bpm", bpm);
        data.append("key", key);
        data.append("genre", genre);
        data.append("price", price);
        data.append("contentType", contentType);
        
        // Append files
        data.append("audioFile", audioFile);
        if (coverImage) {
          data.append("coverImage", coverImage);
        }

        await onUploadTrack(data);
        
        // Clear form on success
        setTitle("");
        setArtist("");
        setBpm("124");
        setKey("8A");
        setGenre("House");
        setPrice("4.99");
        setContentType("track");
        setAudioFile(null);
        setCoverImage(null);
        setUploadStatus("success");
      }
    } catch (err: any) {
      console.error(err);
      setUploadStatus("error");
      setErrorMessage(err?.message || "Failed to complete operation. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  // 1. Return Lock Screen if is NOT authenticated
  if (!isAuthenticated) {
    return (
      <div 
        className="mx-auto max-w-md my-12 border border-slate-200 bg-white shadow-lg p-8 rounded-2xl flex flex-col items-center justify-center space-y-6"
        id="admin-auth-screen"
      >
        <div className="relative h-16 w-16 rounded-full border border-blue-100 bg-blue-50 flex items-center justify-center">
          <Lock className="h-6 w-6 text-blue-600 animate-pulse" />
        </div>

        <div className="text-center space-y-2">
          <h2 className="font-display text-xl font-bold text-blue-600 tracking-tight">
            Admin Auth Keypad
          </h2>
          <p className="text-xs text-slate-500 font-sans">
            This dashboard is restricted to store administrators. Please input physical security token patterns to sign in.
          </p>
        </div>

        <form onSubmit={handleAuthSubmit} className="w-full space-y-4">
          <div className="relative">
            <Key className="absolute top-1/2 left-3 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              id="admin-passcode-input"
              type="password"
              placeholder="Enter passcode (Hint: 1234)"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 text-sm focus:outline-none focus:border-blue-600 hover:border-slate-300 transition duration-300 font-mono"
              required
            />
          </div>

          {authError && (
            <div className="flex items-center gap-2 text-xs text-red-650 bg-red-50 border border-red-200 px-3 py-2 rounded-lg font-mono">
              <AlertCircle className="h-4 w-4 text-red-550" />
              <span>Passcode Invalid. Check the hint.</span>
            </div>
          )}

          <button
            id="admin-auth-submit"
            type="submit"
            className="w-full bg-blue-600 text-white hover:bg-blue-700 font-bold p-3 rounded-xl shadow-md transition duration-300 leading-tight active:scale-95 cursor-pointer text-sm"
          >
            Authenticate Token
          </button>
        </form>
      </div>
    );
  }

  // 2. Return Admin Dashboard Panel if Authenticated
  const filteredTracks = tracks.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(adminSearch.toLowerCase()) ||
      t.artist.toLowerCase().includes(adminSearch.toLowerCase()) ||
      t.genre.toLowerCase().includes(adminSearch.toLowerCase());
    const matchesGenre = adminGenreFilter === "" || t.genre.toLowerCase() === adminGenreFilter.toLowerCase();
    const matchesType =
      adminTypeFilter === "" ||
      t.contentType === adminTypeFilter ||
      (adminTypeFilter === "track" && !t.contentType);
    return matchesSearch && matchesGenre && matchesType;
  });

  return (
    <div className="space-y-12 py-4" id="admin-dashboard-container">
      {/* Top Banner Header */}
      <section className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 rounded-md bg-blue-50 px-2 py-0.5 text-xs font-mono font-bold text-blue-600 border border-blue-105">
            <ShieldCheck className="h-3.5 w-3.5" /> SECURE ROOT PORTAL ACTIVE
          </div>
          <h2 className="font-display text-2xl font-bold text-blue-600 tracking-tight mt-2">
            Deck Owner Console
          </h2>
          <p className="text-sm text-slate-500 font-sans">
            Upload custom DJ packs, manage stem multitracks, and monitor live streaming distribution.
          </p>
        </div>
      </section>

      {/* --- EXECUTIVE ANALYTICS COCKPIT DECK --- */}
      <section className="space-y-6" id="executive-analytics-cockpit">
        {/* Dynamic Metrics Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1: Revenue Platform Tracker */}
          <div className="bento-card p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between h-[155px]">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-widest text-slate-500 font-bold">Estimated Revenue</p>
                <p className="font-display text-2xl font-black text-blue-600 mt-1">${revenue.toLocaleString("en-US", { minimumFractionDigits: 2 })}</p>
              </div>
              <div className="rounded-xl bg-blue-50 p-2 border border-blue-100 text-blue-600">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <span className="text-[10px] text-slate-400 font-mono">Live Demo Simulation:</span>
              <button
                onClick={simulateUpgrade}
                className="px-2.5 py-1 rounded bg-blue-50 hover:bg-blue-600 text-[10px] font-mono font-bold text-blue-600 hover:text-white transition cursor-pointer flex items-center gap-1 leading-none border border-blue-100"
              >
                <Sparkles className="h-2.5 w-2.5 animate-pulse" /> Buy Sub
              </button>
            </div>
          </div>

          {/* Card 2: Catalog Downloads simulated count */}
          <div className="bento-card p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between h-[155px]">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-widest text-slate-500 font-bold">Catalog Downloads</p>
                <p className="font-display text-2xl font-black text-slate-800 mt-1">{downloadsCount} <span className="text-xs font-mono font-normal text-slate-500 font-sans">tracks</span></p>
              </div>
              <div className="rounded-xl bg-slate-50 p-2 text-slate-500 border border-slate-200">
                <Music className="h-4 w-4 text-blue-500" />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <span className="text-[10px] text-slate-400 font-mono">Trigger Action test:</span>
              <button
                onClick={simulateDownload}
                className="px-2.5 py-1 rounded bg-slate-50 hover:bg-slate-100 text-[10px] font-mono font-bold text-slate-700 transition cursor-pointer flex items-center gap-1 leading-none border border-slate-200"
              >
                <Play className="h-2.5 w-2.5 fill-current text-slate-500" /> Mix Down
              </button>
            </div>
          </div>

          {/* Card 3: Active Subscriptions */}
          <div className="bento-card p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between h-[155px]">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-widest text-slate-500 font-bold">Active Subscriptions</p>
                <p className="font-display text-xl sm:text-2xl font-black text-slate-800 mt-1">{subscribersCount} <span className="text-[10px] text-slate-400 font-normal font-sans">Registered DJs</span></p>
              </div>
              <div className="rounded-xl bg-slate-50 p-2 text-slate-500 border border-slate-200">
                <Users className="h-4 w-4 text-blue-500" />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <span className="text-[10px] text-slate-400 font-mono">Simulate user base growth:</span>
              <span className="text-[10px] font-mono font-bold text-emerald-600 flex items-center gap-0.5">
                <span className="h-1 text-emerald-500 animate-ping">●</span> ACTIVE
              </span>
            </div>
          </div>

          {/* Card 4: Catalog Composition Valuation */}
          <div className="bento-card p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between h-[155px]">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-mono text-[9px] uppercase tracking-widest text-slate-500 font-bold">Catalog Assets Value</p>
                <p className="font-display text-2xl font-black text-slate-800 mt-1">${((tracks.reduce((sum, t) => sum + t.price, 0)) * 12.5).toFixed(2)}</p>
              </div>
              <div className="rounded-xl bg-emerald-50 p-2 border border-emerald-100 text-emerald-600">
                <Coins className="h-4 w-4" />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <span className="text-[10px] text-slate-400 font-mono">Tracks count:</span>
              <span className="text-[10px] font-mono font-bold text-slate-600">
                {tracks.filter(t => !t.contentType || t.contentType === "track").length} Sing. | {tracks.filter(t => t.contentType === "pack").length} Packs
              </span>
            </div>
          </div>

        </div>

        {/* Analytics Distribution section - Bento layout splits */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          
          {/* Left partition: Dynamic stock chart by Genres (Vibrant indicator lists) */}
          <div className="xl:col-span-6 bento-card p-6 rounded-2xl bg-white border border-slate-200 shadow-sm font-sans space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-display text-xs font-black text-blue-600 tracking-wider flex items-center gap-1.5 uppercase">
                <Flame className="h-4 w-4 text-blue-600" /> GENRE DISTRIBUTION (LIVE CATALOG MIX)
              </h4>
              <span className="text-[9px] font-mono text-slate-500 bg-slate-50 px-2 py-0.5 rounded border border-slate-200 uppercase font-black">
                REACTS LIVE ON CRUD
              </span>
            </div>

            <p className="text-xs text-slate-500 leading-normal">
              Active store genre proportions updated in real-time on catalog uploads or metadata changes.
            </p>

            <div className="space-y-3.5 pt-2">
              {GENRES.map((g) => {
                const genreCount = tracks.filter((t) => t.genre.toLowerCase() === g.toLowerCase()).length;
                const total = tracks.length || 1;
                const percentage = Math.round((genreCount / total) * 100);
                
                return (
                  <div key={g} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-semibold text-slate-700 flex items-center gap-1 font-sans">
                        <span className="h-1.5 w-1.5 rounded-full bg-blue-600" /> {g}
                      </span>
                      <span className="text-slate-500">
                        {genreCount} item{genreCount !== 1 ? 's' : ''} ({percentage}%)
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all duration-1000"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right partition: Live Action Ledger Logs list & Simulated dials */}
          <div className="xl:col-span-6 bento-card p-6 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-display text-xs font-black text-blue-600 tracking-wider flex items-center gap-1.5 uppercase">
                  <Activity className="h-4 w-4 text-emerald-600 animate-pulse" /> LIVE LANDSCAPE ACTION LEDGER
                </h4>
                <button
                  onClick={clearLogs}
                  className="px-2 py-0.5 rounded bg-slate-50 hover:bg-slate-150 border border-slate-200 text-[9px] font-mono font-bold text-red-605 uppercase tracking-widest cursor-pointer transition duration-150"
                >
                  PURGE LEDGER
                </button>
              </div>
              
              <p className="text-xs text-slate-500 leading-normal">
                High-fidelity simulation ledger tracking download events, catalog updates, and subscriber upgrades.
              </p>

              <div className="space-y-2 max-h-[190px] overflow-y-auto pr-1">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 font-mono text-[10px] flex items-start justify-between gap-3 hover:bg-slate-100/50 transition duration-150"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-slate-800 font-black whitespace-nowrap overflow-hidden text-ellipsis">{log.user}</span>
                        <span className={`px-1.5 py-0.5 text-[8px] font-bold rounded-md leading-none ${
                          log.type === "download" ? "bg-blue-50 text-blue-600" :
                          log.type === "upgrade" ? "bg-amber-50 text-amber-600" :
                          log.type === "sys" ? "bg-slate-200 text-slate-600" : "bg-emerald-50 text-emerald-600"
                        }`}>
                          {log.action}
                        </span>
                      </div>
                      <p className="text-slate-500 truncate text-[9.5px]">{log.meta}</p>
                    </div>
                    <span className="text-[9px] text-slate-400 font-medium shrink-0 whitespace-nowrap">{log.time}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-[10px] font-sans text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200 leading-relaxed">
              👉 <b>Sandbox Environment:</b> Trigger simulated activities such as mock user upgrades and download handshakes without sending actual payment requests.
            </div>
          </div>

        </div>
      </section>

      {/* Grid: Form Left (2 cols), Tracks Table Right (3 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Form: upload / edit tracks */}
        <section className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-md">
            <h3 className="font-display text-base font-bold text-blue-600 mb-4 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-blue-605" /> {editingTrack ? `Edit Track metadata` : "Upload New DJ Pack / Stem"}
            </h3>

            {editingTrack && (
              <div className="mb-4 text-xs font-mono text-center p-2 rounded bg-orange-50 text-orange-600 border border-orange-100">
                ✏️ Editing: <strong className="text-orange-700">{editingTrack.title}</strong>
              </div>
            )}

            {/* Response Banner alerts */}
            {uploadStatus === "success" && (
              <div id="upload-success-toast" className="mb-6 rounded-lg bg-emerald-50 border border-emerald-100 p-4 text-sm text-emerald-600 flex gap-2 animate-in fade-in">
                <ShieldCheck className="h-5 w-5 flex-shrink-0 text-emerald-500" />
                <div>
                  <strong className="block font-bold text-slate-800">Save Successful!</strong>
                  Your DJ track configuration is synchronized and live on the store database.
                </div>
              </div>
            )}

            {uploadStatus === "error" && (
              <div id="upload-error-toast" className="mb-6 rounded-lg bg-red-50 border border-red-100 p-4 text-sm text-red-600 flex gap-2 animate-in fade-in">
                <AlertCircle className="h-5 w-5 flex-shrink-0 text-red-500" />
                <div>
                  <strong className="block font-bold text-slate-800">Operation Interrupted!</strong>
                  {errorMessage}
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Track Title</label>
                <input
                  id="track-title-input"
                  type="text"
                  required
                  placeholder="e.g. Acid Bass Techno"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-850 placeholder-slate-400 text-xs focus:outline-none focus:border-blue-600 transition"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Artist / Producer</label>
                <input
                  id="track-artist-input"
                  type="text"
                  required
                  placeholder="e.g. DJ Shifter"
                  value={artist}
                  onChange={(e) => setArtist(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-850 placeholder-slate-400 text-xs focus:outline-none focus:border-blue-600 transition"
                />
              </div>

              {/* Row 2 */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">BPM</label>
                  <input
                    id="track-bpm-input"
                    type="number"
                    min={40}
                    max={240}
                    placeholder="126"
                    value={bpm}
                    onChange={(e) => setBpm(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-850 text-xs focus:outline-none focus:border-blue-600 transition font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Harmonic Key</label>
                  <input
                    id="track-key-input"
                    type="text"
                    placeholder="8A"
                    value={key}
                    onChange={(e) => setKey(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-850 text-xs focus:outline-none focus:border-blue-600 transition font-mono uppercase"
                  />
                </div>
              </div>

              {/* Row 3 */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Genre</label>
                  <select
                    id="track-genre-input"
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 text-xs focus:outline-none focus:border-blue-600 transition cursor-pointer"
                  >
                    {GENRES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Content Type</label>
                  <select
                    id="track-content-type-input"
                    value={contentType}
                    onChange={(e) => setContentType(e.target.value as "track" | "pack")}
                    className="w-full px-2 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 text-xs focus:outline-none focus:border-blue-600 transition cursor-pointer"
                  >
                    <option value="track">Single item (Tracks)</option>
                    <option value="pack">Pack bundle (Packs)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Price ($USD)</label>
                  <input
                    id="track-price-input"
                    type="number"
                    step="0.01"
                    placeholder="4.99"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-850 text-xs focus:outline-none focus:border-blue-650 transition font-mono"
                  />
                </div>
              </div>

              {!editingTrack ? (
                <>
                  {/* Upload 1: Drag & Drop Audio Files */}
                  <div className="space-y-1">
                    <span className="block text-[11px] font-semibold text-slate-700">Audio Preview File <span className="text-red-500">*</span></span>
                    <div
                      onDragOver={handleAudioDragOver}
                      onDragLeave={handleAudioDragLeave}
                      onDrop={handleAudioDrop}
                      onClick={() => audioInputRef.current?.click()}
                      className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition duration-300 ${
                        isDragOverAudio ? "border-blue-600 bg-blue-50/50" : "border-slate-200 hover:border-slate-350 bg-slate-50/40"
                      }`}
                      id="drag-audio-box"
                    >
                      <input
                        ref={audioInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={(e) => e.target.files && setAudioFile(e.target.files[0])}
                        className="hidden"
                      />
                      <UploadCloud className="h-6 w-6 text-slate-400 mx-auto mb-1" />
                      {audioFile ? (
                        <div className="flex items-center justify-center gap-1.5 text-blue-600 text-xs font-medium font-mono">
                          <Music className="h-3.5 w-3.5 text-blue-550" />
                          <span className="truncate max-w-[150px]">{audioFile.name}</span>
                        </div>
                      ) : (
                        <div className="text-slate-500 text-[10px] text-center space-y-0.5">
                          <p className="font-semibold text-slate-705">Drag & Drop audio file here, or <span className="text-blue-600 font-bold">browse</span></p>
                          <p className="text-slate-400">WAV, MP3 up to 40MB</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Upload 2: Cover Art Visual image */}
                  <div className="space-y-1">
                    <span className="block text-[11px] font-semibold text-slate-700">Artwork Cover Image (Optional)</span>
                    <div
                      onDragOver={handleCoverDragOver}
                      onDragLeave={handleCoverDragLeave}
                      onDrop={handleCoverDrop}
                      onClick={() => coverInputRef.current?.click()}
                      className={`border-2 border-dashed rounded-xl p-3 text-center cursor-pointer transition duration-300 ${
                        isDragOverCover ? "border-blue-600 bg-blue-50/50" : "border-slate-200 hover:border-slate-350 bg-slate-50/40"
                      }`}
                      id="drag-cover-box"
                    >
                      <input
                        ref={coverInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => e.target.files && setCoverImage(e.target.files[0])}
                        className="hidden"
                      />
                      <ImageIcon className="h-5 w-5 text-slate-400 mx-auto mb-1" />
                      {coverImage ? (
                        <div className="flex items-center justify-center gap-1.5 text-blue-600 text-xs font-medium font-mono">
                          <ImageIcon className="h-3.5 w-3.5 text-blue-550" />
                          <span className="truncate max-w-[150px]">{coverImage.name}</span>
                        </div>
                      ) : (
                        <div className="text-slate-505 text-[10px] text-center">
                          <p className="font-semibold text-slate-700">Drag & Drop album artwork, or <span className="text-blue-650 font-bold">browse</span></p>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[10.5px] text-slate-600 space-y-1">
                  <span className="text-slate-800 font-bold block">✨ Files Preserved</span>
                  <span>Audio files and covers are preserved during metadata editing. Reset or upload new packs to change underlying music files.</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  id="admin-form-submit"
                  disabled={isUploading}
                  type="submit"
                  className={`flex-1 rounded-xl p-2.5 font-bold text-xs transition leading-none text-white bg-blue-600 hover:bg-blue-700 cursor-pointer shadow-sm ${
                    isUploading ? "opacity-50 cursor-not-allowed bg-blue-700 text-white" : ""
                  }`}
                >
                  {isUploading 
                    ? (editingTrack ? "Saving details..." : "Uploading assets...") 
                    : (editingTrack ? "Save Changes" : "Publish to DJ Catalog")
                  }
                </button>
                
                {editingTrack && (
                  <button
                    id="admin-form-cancel"
                    type="button"
                    onClick={handleCancelEdit}
                    className="px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 hover:text-slate-800 text-xs text-slate-700 font-bold cursor-pointer transition duration-300"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
        </section>

        {/* Right Panel: Tracks Manager (Search, genre filter, full table of store catalog) */}
        <section className="lg:col-span-3 space-y-4">
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-md">
            <h3 className="font-display text-sm uppercase tracking-wider font-bold text-blue-600 mb-4 flex items-center justify-between">
              <span>Manage Store catalog ({tracks.length})</span>
            </h3>

            {/* Quick search and select bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-5 p-3 rounded-xl bg-slate-50 border border-slate-200/80 font-sans">
              {/* Keyword text search */}
              <div className="relative">
                <label className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono mb-1">Search Tracks</label>
                <div className="relative">
                  <Search className="absolute top-1/2 left-2.5 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                  <input
                    id="admin-search-input"
                    type="text"
                    placeholder="Search title, artist..."
                    value={adminSearch}
                    onChange={(e) => setAdminSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-800 placeholder-slate-400 text-xs focus:outline-none focus:border-blue-605 hover:border-slate-300 transition duration-300 font-sans"
                  />
                </div>
              </div>

              {/* Genre filter selector */}
              <div>
                <label className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono mb-1">Filter Genre</label>
                <select
                  id="admin-genre-select"
                  value={adminGenreFilter}
                  onChange={(e) => setAdminGenreFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs focus:outline-none focus:border-blue-605 hover:border-slate-300 transition duration-300 cursor-pointer"
                >
                  <option value="">All Genres</option>
                  {GENRES.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>

              {/* Type filter selector */}
              <div>
                <label className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-500 font-mono mb-1">Filter Content Type</label>
                <select
                  id="admin-type-select"
                  value={adminTypeFilter}
                  onChange={(e) => setAdminTypeFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs focus:outline-none focus:border-blue-610 hover:border-slate-300 transition duration-300 cursor-pointer"
                >
                  <option value="">All Formats</option>
                  <option value="track">Single item (Tracks)</option>
                  <option value="pack">Pack bundle (Packs)</option>
                </select>
              </div>
            </div>

            {/* Catalog Table with edit / delete */}
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm" id="admin-tracks-table-container">
              <table className="min-w-full text-xs text-left text-slate-700 border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[10px] font-mono text-slate-505 uppercase tracking-wider">
                    <th scope="col" className="px-3 py-2.5">Track</th>
                    <th scope="col" className="px-3 py-2.5">Genre</th>
                    <th scope="col" className="px-3 py-2.5">BPM/Key</th>
                    <th scope="col" className="px-3 py-2.5">Price</th>
                    <th scope="col" className="px-3 py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {filteredTracks.map((t) => (
                    <tr 
                      key={t.id} 
                      className={`hover:bg-slate-50 transition-colors duration-200 ${
                        editingTrack?.id === t.id ? "bg-blue-50/40 hover:bg-blue-50/60" : ""
                      }`}
                      id={`admin-track-item-${t.id}`}
                    >
                      {/* Track Title and cover art */}
                      <td className="px-3 py-2.5 flex items-center gap-2 max-w-[160px] sm:max-w-none">
                        <img src={t.coverUrl} className="h-8 w-8 rounded-md object-cover flex-shrink-0 border border-slate-200" />
                        <div className="min-w-0 flex-1">
                          <h4 className="font-bold text-slate-800 truncate text-xs">{t.title}</h4>
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500 text-[10px] truncate">{t.artist}</span>
                            <span className={`px-1 rounded text-[8px] font-bold uppercase ${
                              t.contentType === "pack" ? "bg-amber-50 text-amber-705 border border-amber-100" : "bg-slate-100 text-slate-600 border border-slate-200"
                            }`}>
                              {t.contentType === "pack" ? "Pack" : "Single"}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Genre block */}
                      <td className="px-3 py-2.5 whitespace-nowrap">
                        <span className="px-1.5 py-0.5 rounded font-mono text-[9px] text-blue-600 bg-blue-50 border border-blue-105 uppercase font-extrabold">
                          {t.genre}
                        </span>
                      </td>

                      {/* BPM tempo and harmonic Key */}
                      <td className="px-3 py-2.5 whitespace-nowrap font-mono text-[10px] text-slate-500">
                        <span>{t.bpm} BPM | {t.key}</span>
                      </td>

                      {/* Store pricing */}
                      <td className="px-3 py-2.5 whitespace-nowrap font-mono font-bold text-emerald-600">
                        ${t.price.toFixed(2)}
                      </td>

                      {/* Edit or Delete Action triggers */}
                      <td className="px-3 py-2.5 whitespace-nowrap text-right">
                        <div className="inline-flex items-center gap-1.5 justify-end">
                          <button
                            id={`edit-btn-${t.id}`}
                            onClick={() => handleStartEdit(t)}
                            className="p-1 px-2.5 text-blue-600 hover:text-white rounded-md border border-blue-150 bg-blue-50 hover:bg-blue-600 transition duration-300 flex items-center gap-1 cursor-pointer font-bold text-[9px]"
                            title="Edit metadata details"
                          >
                            <Edit className="h-3 w-3" /> Edit
                          </button>
                          <button
                            id={`delete-btn-${t.id}`}
                            onClick={() => onDeleteTrack(t.id)}
                            className="p-1 px-1.5 text-red-600 hover:text-white rounded-md border border-red-150 bg-red-50 hover:bg-red-650 transition duration-300 cursor-pointer"
                            title="Remove catalog product"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}

                  {filteredTracks.length === 0 && (
                    <tr>
                      <td colSpan={5} className="text-center text-slate-400 font-mono py-12 text-xs">
                        No tracks match search details.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
