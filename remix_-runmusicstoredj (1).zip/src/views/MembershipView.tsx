import React, { useState } from "react";
import { 
  Coins, Check, Zap, User, Calendar, ArrowUpRight, 
  Lock, Unlock, History, Sparkles, Music, Download, Play, Pause, 
  CreditCard, ShieldCheck, Ticket, AlertCircle
} from "lucide-react";
import { Track, UserAccount } from "../types";

interface MembershipViewProps {
  user: UserAccount;
  onUpdateUser: (newUser: UserAccount) => void;
  tracks: Track[];
  onPlayTrack: (track: Track) => void;
  playingTrackId: string | null;
  isPlaying: boolean;
  onOpenAuth?: () => void;
}

export default function MembershipView({
  user,
  onUpdateUser,
  tracks,
  onPlayTrack,
  playingTrackId,
  isPlaying,
  onOpenAuth,
}: MembershipViewProps) {
  // Modal state for checkout simulation
  const [purchaseModal, setPurchaseModal] = useState<{
    type: "subscription" | "credits";
    id: string; // plan or bundle ID
    name: string;
    price: string;
    creditsGranted: number;
    subTier?: "free" | "silver" | "gold" | "platinum";
  } | null>(null);

  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardName, setCardName] = useState("");
  const [paymentError, setPaymentError] = useState("");

  // Subscriptions configuration
  const PLANS = [
    {
      id: "free",
      name: "Guest Explorer",
      price: "$0",
      credits: 0,
      textColor: "text-slate-400",
      borderColor: "border-slate-800",
      bgColor: "bg-slate-950/40",
      bulletGlow: "text-slate-500",
      perks: [
        "15 Starter Credits (upon registration)",
        "Restricted to standard MP3 loop quality",
        "No Lossless WAV format support",
        "No multi-track or Stems kit downloads",
      ]
    },
    {
      id: "silver",
      name: "Silver DJ Pro Suite",
      price: "$14.99/mo",
      credits: 50,
      textColor: "text-slate-200 font-extrabold",
      borderColor: "border-slate-700 hover:border-slate-500",
      bgColor: "bg-slate-900/60",
      bulletGlow: "text-slate-400",
      tag: "STANDARD PRO",
      perks: [
        "50 credits per month",
        "Unlock Lossless 24-bit WAV quality",
        "Adjust pitch key and BPM variations",
        "Offline download history logs support",
      ]
    },
    {
      id: "gold",
      name: "Gold VIP Producer",
      price: "$29.99/mo",
      credits: 150,
      textColor: "text-gold font-black",
      borderColor: "border-gold-faint hover:border-gold-active",
      bgColor: "bg-[#111827]/80",
      bulletGlow: "text-gold",
      tag: "PREMIUM DELUXE",
      perks: [
        "150 credits per month",
        "Full access to individual Stems audio splits",
        "Exclusive DJ promo tracks, pre-release",
        "Priority DJ requests and suggestions response",
      ]
    },
    {
      id: "platinum",
      name: "Platinum Elite Legend",
      price: "$49.99/mo",
      credits: 9999,
      textColor: "text-gold-gradient font-black",
      borderColor: "border-gold-active",
      bgColor: "bg-gradient-to-b from-[#1c1917] to-[#0c0a09]",
      bulletGlow: "text-gold",
      tag: "ROYAL LUXURY VIP",
      perks: [
        "Unlimited banger catalog downloads*",
        "Zero credit deduction for Single Tracks",
        "Download all Stems / Extended edits instantly",
        "Studio-grade Key & BPM analyser compatibility",
      ]
    }
  ];

  // Extra credit packages bundles
  const BUNDLES = [
    { id: "small", name: "Small Beats Bundle", desc: "Perfect for overnight DJ practices", credits: 10, price: "$2.99" },
    { id: "medium", name: "Club Starter Pack", desc: "Top up your regular pub set designs", credits: 50, price: "$9.99", popular: true },
    { id: "large", name: "Stadium Ultimate Bundle", desc: "Equip yourself for major concert events", credits: 120, price: "$19.99" }
  ];

  // Initiate purchase modal
  const handleInitiateSubscription = (plan: typeof PLANS[0]) => {
    if (!user.isLoggedIn) {
      if (onOpenAuth) {
        onOpenAuth();
      } else {
        alert("Please sign in with Google or Facebook to upgrade your membership.");
      }
      return;
    }
    if (plan.id === user.subTier) {
      alert("You are already subscribed to this membership level!");
      return;
    }
    setPaymentSuccess(false);
    setPaymentError("");
    setPurchaseModal({
      type: "subscription",
      id: plan.id,
      name: plan.name,
      price: plan.price,
      creditsGranted: plan.credits,
      subTier: plan.id as any
    });
  };

  const handleInitiateCredits = (bundle: typeof BUNDLES[0]) => {
    if (!user.isLoggedIn) {
      if (onOpenAuth) {
        onOpenAuth();
      } else {
        alert("Please sign in with Google or Facebook to purchase credits.");
      }
      return;
    }
    setPaymentSuccess(false);
    setPaymentError("");
    setPurchaseModal({
      type: "credits",
      id: bundle.id,
      name: bundle.name,
      price: bundle.price,
      creditsGranted: bundle.credits
    });
  };

  // Perform purchase update state
  const handleCompletePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardNumber || !expiry || !cvv || !cardName) {
      setPaymentError("Please fill out all credit card credentials before confirming.");
      return;
    }

    if (purchaseModal) {
      if (purchaseModal.type === "subscription") {
        const updatedUser: UserAccount = {
          ...user,
          subTier: purchaseModal.subTier || "free",
          // Adding credits appropriately
          credits: user.credits + purchaseModal.creditsGranted,
          subStartDate: new Date().toISOString()
        };
        onUpdateUser(updatedUser);
      } else {
        // Buy extra credits package
        const updatedUser: UserAccount = {
          ...user,
          credits: user.credits + purchaseModal.creditsGranted
        };
        onUpdateUser(updatedUser);
      }
      setPaymentSuccess(true);
      // Close after delay
      setTimeout(() => {
        setPurchaseModal(null);
        setCardNumber("");
        setExpiry("");
        setCvv("");
        setCardName("");
        setPaymentSuccess(false);
      }, 1500);
    }
  };

  // Find all unlocked track objects from catalog
  const unlockedTracksList = tracks.filter(t => user.unlockedTracks.includes(t.id));

  // Downloader action helper for previously purchased tracks
  const handleForceDownload = (track: Track) => {
    const downloadUrl = track.audioUrl.startsWith("/uploads/") 
      ? window.location.origin + track.audioUrl 
      : track.audioUrl;
      
    const anchor = document.createElement("a");
    anchor.href = downloadUrl;
    anchor.download = `re_${track.title.toLowerCase().replace(/[^a-z0-9]/g, "_")}.mp3`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
  };

  return (
    <div className="space-y-8 py-4 font-sans" id="membership-view-container">
      
      {/* 1. Header Information Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Zap className="h-6 w-6 text-yellow-500 fill-yellow-500 animate-pulse" />
            Membership Control & Perks Center
          </h2>
          <p className="text-sm text-slate-400">
            Upgrade your active tier to receive maximum monthly credits and unlock pristine Lossless WAV / Stem Kit resources.
          </p>
        </div>
      </div>

      {/* 2. User Dashboard Status Block (Bento Style) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="membership-dashboard-metrics">
        {/* Profile Stats Card */}
        <div className="col-span-1 md:col-span-2 bento-card bento-glow-orange p-6 rounded-2xl flex flex-col justify-between relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-950 to-slate-950 border border-slate-800/80">
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
            <User className="h-32 w-32 text-orange-400" />
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              {user.isLoggedIn ? (
                <div className="relative shrink-0">
                  <img 
                    src={user.avatarUrl} 
                    alt={user.name} 
                    className="h-12 w-12 rounded-full border-2 border-orange-500 object-cover shadow"
                  />
                  <span className="absolute -bottom-1 -right-1 px-1 py-0.5 rounded-full text-[7px] font-black uppercase bg-orange-500 text-slate-950 font-mono tracking-tighter leading-none">
                    {user.provider}
                  </span>
                </div>
              ) : (
                <div className="h-12 w-12 rounded-full border border-orange-500/30 bg-orange-500/10 flex items-center justify-center text-orange-400 shadow-md shrink-0">
                  <User className="h-6 w-6" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <h3 className="font-bold text-white text-base truncate">
                  {user.isLoggedIn ? user.name : "Guest DJ Profile"}
                </h3>
                <p className="text-xs text-slate-400 font-mono tracking-wider truncate">
                  {user.isLoggedIn ? `${user.email} (CONNECTED)` : "REGISTRY USER ACCOUNT ACTIVATED (LOCAL)"}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-slate-800/70 pt-4">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Current Membership Tier</span>
                <p className={`font-display font-extrabold text-lg mt-1 flex items-center gap-1.5 uppercase ${
                  user.subTier === "platinum" ? "text-amber-400" :
                  user.subTier === "gold" ? "text-purple-400" :
                  user.subTier === "silver" ? "text-orange-400" : "text-slate-400"
                }`}>
                  <ShieldCheck className="h-4 w-4 shrink-0" />
                  {user.subTier === "platinum" ? "Platinum Elite VIP" :
                   user.subTier === "gold" ? "Gold VIP Creator" :
                   user.subTier === "silver" ? "Silver DJ Pro" : "Guest Sandbox (Free)"}
                </p>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Available Balance Credits</span>
                <p className="font-display font-black text-2xl text-emerald-400 mt-0.5 flex items-center gap-1">
                  <Coins className="h-5 w-5 animate-spin-slow" />
                  {user.subTier === "platinum" ? "Unlimited" : `${user.credits} CR`}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-800/50 pt-4 text-xs font-mono text-slate-400">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5 text-slate-500" />
              <span>Start Date: {user.subStartDate ? new Date(user.subStartDate).toLocaleDateString("en-US") : "Automatic trial initiated"}</span>
            </div>
            <div className="px-2 py-0.5 bg-orange-500/10 border border-orange-500/20 rounded font-bold text-orange-400 text-[10px] uppercase tracking-wider">
              AUTO-RENEW ACTIVE
            </div>
          </div>
        </div>

        {/* Feature limits list in bento shape */}
        <div className="bento-card bento-glow-purple p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3 flex items-center gap-1.5 font-mono text-indigo-400">
              <Sparkles className="h-4 w-4" /> ACTIVE TIER PERKS SUMMARY
            </h4>
            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
                <span className="text-slate-500">Audio Preview Resolution:</span>
                <span className="font-bold text-white font-mono">{user.subTier === "free" ? "320kbps MP3 (Only)" : "WAV Complete HD + MP3"}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
                <span className="text-slate-500">Multi-Channel Stems Split:</span>
                <span className={`font-bold font-mono ${user.subTier === "gold" || user.subTier === "platinum" ? "text-emerald-400" : "text-slate-500 text-strikethrough"}`}>
                  {user.subTier === "gold" || user.subTier === "platinum" ? "Fully Unlocked" : "Locked (Gold plan required)"}
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-500">History Re-downloads:</span>
                <span className="font-bold text-white font-mono text-emerald-400">Unlimited Free (No extra cost)</span>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 rounded-xl bg-slate-950 border border-slate-800 text-[10px] font-mono leading-relaxed text-slate-500">
            💡 <strong className="text-orange-400 font-bold">Pro-tip:</strong> Single Tracks cost <strong>1 Credit</strong> while DJ Packs/Stems cost <strong>3 Credits</strong>
          </div>
        </div>
      </div>

      {/* 3. Monthly Subscription Plans Grid */}
      <div className="space-y-5" id="membership-plans-deck">
        <h3 className="font-display text-lg font-bold text-white tracking-tight flex items-center gap-2">
          <Ticket className="h-5 w-5 text-gold" /> Monthly DJ Subscriptions
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {PLANS.map((plan) => {
            const isCurrent = user.subTier === plan.id;
            return (
              <div 
                key={plan.id}
                className={`bento-card relative flex flex-col justify-between p-6 rounded-2xl border transition-all duration-300 ${plan.borderColor} ${plan.bgColor} ${
                  isCurrent ? "ring-2 ring-gold shadow-xl shadow-gold/5 scale-[1.02]" : ""
                }`}
              >
                {/* Popularity or special tags */}
                {plan.tag && (
                  <span className={`absolute top-4 right-4 px-2 py-0.5 rounded text-[8px] font-extrabold font-mono tracking-wider ${
                    plan.id === "platinum" ? "bg-gold text-slate-950 animate-pulse" :
                    plan.id === "silver" ? "bg-slate-800 text-white" : "bg-gold-light text-slate-950"
                  }`}>
                    {plan.tag}
                  </span>
                )}

                <div className="space-y-4">
                  <div>
                    <h4 className={`font-bold font-display text-sm ${plan.textColor}`}>{plan.name}</h4>
                    <div className="flex items-baseline mt-2">
                      <span className="text-3xl font-extrabold tracking-tight text-white">{plan.price}</span>
                      {plan.id !== "free" && <span className="text-[10px] text-slate-550 font-mono ml-1">/mo</span>}
                    </div>
                  </div>

                  {/* Dynamic credits display */}
                  <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/40 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400">Instant Monthly Credits:</span>
                    <span className="text-xs font-bold font-mono text-gold flex items-center gap-1">
                      <Coins className="h-3 w-3 shrink-0" />
                      {plan.id === "platinum" ? "Unlimited" : `+${plan.credits} Credits`}
                    </span>
                  </div>

                  {/* Bullet perks */}
                  <ul className="space-y-2 pt-2 border-t border-slate-800/50">
                    {plan.perks.map((perk, idx) => (
                      <li key={idx} className="flex gap-2 text-xs text-slate-300 leading-normal">
                        <Check className={`h-4 w-4 shrink-0 mt-0.5 ${plan.bulletGlow}`} />
                        <span>{perk}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8 pt-4 border-t border-slate-800/50">
                  <button
                    disabled={isCurrent}
                    onClick={() => handleInitiateSubscription(plan)}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                      isCurrent 
                        ? "bg-slate-800 border border-slate-700 text-slate-400 cursor-not-allowed"
                        : plan.id === "free"
                          ? "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
                          : plan.id === "platinum" || plan.id === "gold"
                            ? "bg-gold hover:bg-gold-light text-slate-950 font-black shadow-lg shadow-gold/10 hover:scale-[1.01]"
                            : "bg-slate-100 hover:bg-white text-slate-950 shadow-lg"
                    }`}
                  >
                    {isCurrent ? (
                      <>
                        <ShieldCheck className="h-3.5 w-3.5 text-gold" /> Active Current Plan
                      </>
                    ) : (
                      <>
                        Join {plan.name.split(" ")[0]} Plan
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Extra Top-Up Credits Pack Bundles */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="credit-topups-container">
        {/* Banner callout column */}
        <div className="lg:col-span-1 p-6 rounded-2xl bg-gradient-to-br from-indigo-950/20 via-slate-950 to-slate-950 border border-slate-800/90 flex flex-col justify-between bento-card bento-glow-blue">
          <div className="space-y-3">
            <div className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <Coins className="h-5 w-5" />
            </div>
            <h3 className="font-display text-base font-bold text-white">Purchase Extra Credits</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Need a quick top-up? For DJs who used up their subscription bonus or prefer non-recurring packs, purchase top-up credits instantly to download files on the go.
            </p>
          </div>
          <div className="mt-6 border-t border-slate-800/50 pt-4 text-[10px] font-mono text-slate-500 leading-snug">
            * Purchased credits never expire and are usable anytime for any DJ tool in the system.
          </div>
        </div>

        {/* Triple bundle cards content space */}
        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-6">
          {BUNDLES.map((bundle) => (
            <div 
              key={bundle.id}
              className={`bento-card p-5 rounded-2xl border bg-slate-950/40 hover:scale-[1.01] transition-all duration-300 flex flex-col justify-between ${
                bundle.popular ? "border-orange-500/30 ring-1 ring-orange-500/10" : "border-slate-800/80"
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  {bundle.popular && (
                    <span className="px-1.5 py-0.5 bg-orange-500 text-slate-950 text-[8px] font-black font-mono tracking-wider rounded">
                      HOT SALE
                    </span>
                  )}
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
                    {bundle.id === "small" ? "Starter Beats" : bundle.id === "medium" ? "Club Standard" : "Stadium Pro"}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-white text-sm">{bundle.name}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">{bundle.desc}</p>
                </div>

                <div className="flex items-baseline gap-2 pt-2">
                  <span className="text-2xl font-black text-orange-400 mt-1 font-mono">{bundle.price}</span>
                  <p className="text-xs font-semibold text-slate-300 font-mono flex items-center gap-1 pl-2 border-l border-slate-800/80">
                    <Coins className="h-3.5 w-3.5 text-emerald-400" />
                    +{bundle.credits} Credits
                  </p>
                </div>
              </div>

              <div className="mt-6 border-t border-slate-850 pt-3">
                <button
                  onClick={() => handleInitiateCredits(bundle)}
                  className="w-full bg-slate-900 border border-slate-800 hover:bg-orange-500 hover:text-slate-950 hover:border-orange-500/10 transition duration-300 font-mono font-bold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 cursor-pointer text-slate-300"
                >
                  <CreditCard className="h-3 w-3 shrink-0" />
                  Buy {bundle.credits} Credits
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. User Unlocked Tracks & Downloads History */}
      <section className="bento-card bento-glow-orange p-6 rounded-2xl bg-slate-900 border border-slate-850" id="membership-download-vault">
        <div className="flex items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-800">
          <h3 className="font-display font-bold text-white text-sm flex items-center gap-2">
            <History className="h-4 w-4 text-orange-400" /> Unlocked Tracks Vault ({unlockedTracksList.length} Tracks)
          </h3>
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-400 font-mono bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
            SECURE DECK VAULT
          </span>
        </div>

        {unlockedTracksList.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {unlockedTracksList.map((track) => {
              const isLocalPlaying = playingTrackId === track.id && isPlaying;
              return (
                <div 
                  key={track.id} 
                  className={`flex items-center gap-3 p-3 rounded-xl border bg-slate-950/20 hover:bg-slate-950/50 transition-all duration-300 ${
                    isLocalPlaying ? "border-orange-500/40 shadow-md ring-1 ring-orange-500/20" : "border-slate-800/60"
                  }`}
                >
                  {/* Small Playable Cover Artwork */}
                  <div className="relative group h-12 w-12 rounded-lg overflow-hidden border border-slate-800/80 shrink-0 cursor-pointer">
                    <img src={track.coverUrl} className="h-full w-full object-cover group-hover:opacity-40 transition duration-300" />
                    <button 
                      onClick={() => onPlayTrack(track)}
                      className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition duration-300"
                    >
                      {isLocalPlaying ? (
                        <Pause className="h-5 w-5 text-orange-400 animate-pulse fill-orange-400" />
                      ) : (
                        <Play className="h-5 w-5 text-white fill-white scale-90" />
                      )}
                    </button>
                  </div>

                  {/* Metadata */}
                  <div className="min-w-0 flex-1">
                    <h4 className="font-bold text-white text-xs truncate leading-normal">{track.title}</h4>
                    <p className="text-slate-400 text-[10px] truncate">by {track.artist}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="px-1 py-0.5 bg-orange-500/10 text-orange-400 border border-orange-500/20 text-[8px] font-bold uppercase rounded">
                        {track.genre}
                      </span>
                      <span className="text-[8px] text-slate-500 font-mono uppercase">
                        {track.contentType === "pack" ? "Pack" : "Track"}
                      </span>
                    </div>
                  </div>

                  {/* Re-download directly for free without spending credits */}
                  <button
                    onClick={() => handleForceDownload(track)}
                    className="p-2 border border-slate-800 bg-slate-900 rounded-lg hover:bg-slate-800 hover:text-emerald-400 text-slate-400 transition"
                    title="Re-download track for free"
                  >
                    <Download className="h-3.5 w-3.5 animate-pulse" />
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-10 font-mono text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl bg-slate-950/20">
            <Music className="h-7 w-7 text-slate-700 mx-auto mb-2.5 animate-bounce" />
            No custom unlocked track history logged for this account.
            <p className="text-[10px] text-slate-500 mt-1 max-w-xs mx-auto leading-relaxed">
              Visit the Browse view and click 'AERODROP' to unlock. Your active history will be displayed safely right here!
            </p>
          </div>
        )}
      </section>

      {/* 6. Checkout Payment Modal (Subscription / Credits purchase) */}
      {purchaseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-5 flex flex-col justify-between">
            {/* Direct Close Panel Trigger */}
            <button
              onClick={() => setPurchaseModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white transition rounded p-1 hover:bg-slate-800"
            >
              <XCloseIcon className="h-5 w-5" />
            </button>

            {!paymentSuccess ? (
              <form onSubmit={handleCompletePayment} className="space-y-4">
                <div className="flex items-center gap-2 text-blue-400 font-mono text-xs uppercase">
                  <CreditCard className="h-4 w-4 text-emerald-400" /> Secure DJ Registry Checkout
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-2 text-slate-900 font-mono font-black text-2xl -rotate-12 select-none pointer-events-none">
                    SECUREPAY
                  </div>
                  <span className="text-[9px] uppercase tracking-widest font-black text-slate-500 font-mono">PURCHASE ITEM</span>
                  <h4 className="font-extrabold text-white text-base mt-0.5">{purchaseModal.name}</h4>
                  <div className="flex items-baseline mt-2 justify-between">
                    <span className="text-xl font-mono text-emerald-400 font-black">{purchaseModal.price}</span>
                    <span className="text-xs text-slate-450 font-mono">
                      {purchaseModal.type === "subscription" 
                        ? `Granted: ${purchaseModal.creditsGranted === 9999 ? "Unlimited" : `${purchaseModal.creditsGranted} Credits`}` 
                        : `Top-up: +${purchaseModal.creditsGranted} Credits`}
                    </span>
                  </div>
                </div>

                {paymentError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg text-xs flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    <span>{paymentError}</span>
                  </div>
                )}

                {/* Simulated Payment Credentials Block */}
                <div className="space-y-2.5 text-xs text-slate-300">
                  <div>
                    <label className="block mb-1 text-slate-400 font-mono">Name on Card</label>
                    <input 
                      type="text" 
                      placeholder="DJ ALAN WALKER"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-700 text-xs focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block mb-1 text-slate-400 font-mono">Credit Card Number (Simulated)</label>
                    <input 
                      type="text" 
                      placeholder="4000 1234 5678 9010"
                      maxLength={19}
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-700 text-xs focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block mb-1 text-slate-400 font-mono">Expiry Date</label>
                      <input 
                        type="text" 
                        placeholder="12/28"
                        maxLength={5}
                        value={expiry}
                        onChange={(e) => setExpiry(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-700 text-xs focus:outline-none focus:border-blue-500 text-center"
                      />
                    </div>
                    <div>
                      <label className="block mb-1 text-slate-400 font-mono">CVV Security Code</label>
                      <input 
                        type="password" 
                        placeholder="•••"
                        maxLength={3}
                        value={cvv}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9]/g, "");
                          setCvv(val);
                        }}
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-700 text-xs focus:outline-none focus:border-blue-500 text-center"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold p-3 text-xs rounded-xl shadow-lg transition duration-200 cursor-pointer uppercase flex items-center justify-center gap-1.5"
                  >
                    <ShieldCheck className="h-4 w-4 shrink-0" /> Authorization Payment Confirm
                  </button>
                </div>
              </form>
            ) : (
              <div className="text-center py-8 space-y-4">
                <div className="h-12 w-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
                  <Check className="h-6 w-6 animate-ping" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-display font-bold text-lg text-white">Payment Successful!</h3>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto font-mono">
                    Your membership privileges and credits have been successfully assigned to your DJ profile!
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// Minimalistic matching XClose vector icon due to scope
function XCloseIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
}
