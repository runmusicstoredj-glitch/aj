import React from "react";
import { Play, Pause, Trash2, Download, Music, Coins } from "lucide-react";
import { Track } from "../types";
import AudioPlayer from "./AudioPlayer";

interface TrackCardProps {
  key?: string | number;
  track: Track;
  isPlaying: boolean;
  onPlayClick: () => void;
  onDownloadClick: () => void;
  isAdmin: boolean;
  onDeleteClick?: () => void;
}

export default function TrackCard({
  track,
  isPlaying,
  onPlayClick,
  onDownloadClick,
  isAdmin,
  onDeleteClick,
}: TrackCardProps) {
  // Compute color based on genre
  const getGenreColor = (genre: string) => {
    switch (genre.toLowerCase()) {
      case "house":
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
      case "hiphop":
        return "bg-indigo-500/10 text-indigo-400 border-indigo-500/20";
      case "techno":
        return "bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/20";
      case "drum & bass":
      case "dnb":
        return "bg-rose-500/10 text-rose-400 border-rose-500/20";
      default:
        return "bg-blue-500/10 text-blue-400 border-blue-500/20";
    }
  };

  return (
    <div 
      className={`bento-card bento-glow-blue relative flex flex-col sm:flex-row items-center gap-5 rounded-2xl p-5 transition-all duration-300 ${
        isPlaying ? "border-blue-500/50 bg-slate-950/90 ring-1 ring-blue-500/30 shadow-[0_0_25px_rgba(59,130,246,0.15)]" : "border-slate-800/80"
      }`}
      id={`track-card-${track.id}`}
    >
      {/* Absolute Badge for price */}
      <span className="absolute top-4 right-4 flex items-center gap-1 rounded-full bg-slate-950/90 px-3 py-1 text-xs font-mono font-bold text-emerald-400 border border-emerald-500/30 shadow-md">
        <Coins className="h-3 w-3 text-emerald-400" />
        ${track.price.toFixed(2)}
      </span>

      {/* Album Cover Block */}
      <div className="relative group h-24 w-24 flex-shrink-0 cursor-pointer overflow-hidden rounded-xl bg-slate-950 shadow-inner border border-slate-800/60">
        <img
          src={track.coverUrl}
          referrerPolicy="no-referrer"
          alt={track.title}
          className="h-full w-full object-cover transition duration-300 group-hover:scale-110 group-hover:opacity-40"
        />
        {/* Play Overlay Button */}
        <button
          onClick={onPlayClick}
          className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition duration-300"
        >
          {isPlaying ? (
            <Pause className="h-8 w-8 text-blue-400 fill-blue-400 animate-pulse" />
          ) : (
            <Play className="h-8 w-8 text-white fill-white scale-90 group-hover:scale-100 transition duration-300" />
          )}
        </button>

        {/* Small Active Soundwave Indicator */}
        {isPlaying && (
          <div className="absolute bottom-2 right-2 flex items-end gap-1 h-3.5 bg-black/40 px-1.5 py-0.5 rounded">
            <span className="glow-soundwave w-[2px] h-2 bg-blue-400" style={{ animationDelay: "0.1s" }} />
            <span className="glow-soundwave w-[2px] h-3 bg-blue-400" style={{ animationDelay: "0.3s" }} />
            <span className="glow-soundwave w-[2px] h-1.5 bg-blue-400" style={{ animationDelay: "0.5s" }} />
          </div>
        )}
      </div>

      {/* Text Info Column */}
      <div className="flex-1 w-full mt-3 sm:mt-0 min-w-0">
        <div className="flex flex-wrap items-center gap-2 mb-1.5">
          <span className={`rounded-lg border px-2.5 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider ${getGenreColor(track.genre)}`}>
            {track.genre}
          </span>
          <span className={`rounded-lg border px-2.5 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider ${
            track.contentType === "pack"
              ? "bg-amber-500/10 text-amber-300 border-amber-500/20"
              : "bg-blue-500/10 text-blue-300 border-blue-500/20"
          }`}>
            {track.contentType === "pack" ? "DJ Pack / DJ Edit" : "Tracks"}
          </span>
          {track.createdAt && (
            <span className="text-[10px] text-slate-500 font-mono">
              {new Date(track.createdAt).toLocaleDateString()}
            </span>
          )}
        </div>

        <h3 className="truncate font-display font-bold text-white text-base lg:text-lg tracking-tight">
          {track.title}
        </h3>
        <p className="truncate text-sm text-slate-400 font-medium">by {track.artist}</p>

        {/* BPM & Key metrics */}
        <div className="mt-2.5 flex items-center gap-3 text-xs text-slate-500 font-mono">
          <div className="flex items-center gap-1 bg-slate-950/40 px-2 py-0.5 rounded border border-slate-800/40">
            <span className="text-slate-500 font-medium">BPM:</span>
            <span className="text-blue-400 font-bold">{track.bpm}</span>
          </div>
          <div className="flex items-center gap-1 bg-slate-950/40 px-2 py-0.5 rounded border border-slate-800/40">
            <span className="text-slate-500 font-medium">Key:</span>
            <span className="text-purple-400 font-bold">{track.key}</span>
          </div>
        </div>

        {/* Action controls below metadata */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/40 pt-3">
          <button
            onClick={onPlayClick}
            className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold transition duration-300 ${
              isPlaying
                ? "bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/20"
                : "bg-blue-600 text-white hover:bg-blue-500 shadow-md shadow-blue-500/10 hover:shadow-blue-500/20"
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="h-3.5 w-3.5" /> Pause Sample
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5 fill-current" /> Play Sample
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            {isAdmin && onDeleteClick && (
              <button
                onClick={onDeleteClick}
                className="flex items-center justify-center rounded-xl border border-red-500/20 bg-red-950/10 p-2 text-red-400 hover:bg-red-500 hover:text-white transition-all duration-300"
                title="Delete pack"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
            <button
              onClick={onDownloadClick}
              className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/60 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700 hover:text-white transition-all duration-300"
            >
              <Download className="h-3.5 w-3.5" /> Grab Pack
            </button>
          </div>
        </div>

        {/* Integrated Inline Audio Player */}
        {isPlaying && (
          <AudioPlayer
            currentTrack={track}
            isPlaying={isPlaying}
            onPlayPauseToggle={onPlayClick}
            isInline={true}
          />
        )}
      </div>
    </div>
  );
}
