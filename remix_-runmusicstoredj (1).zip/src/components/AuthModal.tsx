import React, { useState } from "react";
import { X, Mail, Chrome, Facebook, LogOut, Check, ArrowRight, Loader2, Sparkles, User, ShieldAlert } from "lucide-react";
import { UserAccount } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserAccount;
  onUpdateUser: (updated: Partial<UserAccount>) => void;
}

export default function AuthModal({ isOpen, onClose, user, onUpdateUser }: AuthModalProps) {
  const [authStep, setAuthStep] = useState<"choice" | "google-flow" | "facebook-flow" | "custom-gmail" | "authenticating">("choice");
  const [customEmail, setCustomEmail] = useState("");
  const [customName, setCustomName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [confirmingLogout, setConfirmingLogout] = useState(false);

  if (!isOpen) return null;

  // Simulate Gmail Quick Accounts List
  const googleAccounts = [
    { name: "John Doe", email: "john.doe.dj@gmail.com", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80" },
    { name: "DJ Nexa Beats", email: "nexa.beats.official@gmail.com", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80" },
    { name: "Sarah Mixmaster", email: "sarah.mix.reverbs@gmail.com", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80" }
  ];

  // Simulated FB accounts
  const facebookProfile = {
    name: "Alex Beatmaker",
    email: "alex.beats.fb@facebook.com",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
  };

  const handleSelectQuickGoogleAccount = (acc: typeof googleAccounts[0]) => {
    setIsLoading(true);
    setAuthStep("authenticating");
    setTimeout(() => {
      onUpdateUser({
        isLoggedIn: true,
        provider: "google",
        name: acc.name,
        email: acc.email,
        avatarUrl: acc.avatar,
      });
      setIsLoading(false);
      onClose();
    }, 1200);
  };

  const handleCustomGmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail.endsWith("@gmail.com")) {
      setErrorMessage("Please enter a valid address ending with @gmail.com");
      return;
    }
    if (!customName.trim()) {
      setErrorMessage("Please specify your DJ Name");
      return;
    }

    setErrorMessage("");
    setIsLoading(true);
    setAuthStep("authenticating");
    
    // Simulate API delay
    setTimeout(() => {
      // Pick a random cool DJ avatar based on user initial
      const initial = customName.trim().charAt(0).toLowerCase();
      const randId = Math.floor(Math.random() * 80) + 10;
      const avatar = `https://picsum.photos/id/${randId}/150/150`;

      onUpdateUser({
        isLoggedIn: true,
        provider: "google",
        name: customName,
        email: customEmail,
        avatarUrl: avatar,
      });
      setIsLoading(false);
      onClose();
    }, 1500);
  };

  const handleFacebookConnect = () => {
    setIsLoading(true);
    setAuthStep("authenticating");
    setTimeout(() => {
      onUpdateUser({
        isLoggedIn: true,
        provider: "facebook",
        name: facebookProfile.name,
        email: facebookProfile.email,
        avatarUrl: facebookProfile.avatar,
      });
      setIsLoading(false);
      onClose();
    }, 1300);
  };

  const handleLogout = () => {
    setConfirmingLogout(true);
  };

  const handleLogoutComplete = () => {
    onUpdateUser({
      isLoggedIn: false,
      name: undefined,
      email: undefined,
      avatarUrl: undefined,
      provider: undefined,
    });
    setConfirmingLogout(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      
      {/* Container Box */}
      <div className="w-full max-w-md bg-slate-900 border border-slate-800/80 rounded-2xl shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Glow Header Accent Line */}
        <div className="h-1 w-full bg-gradient-to-r from-orange-600 via-amber-500 to-orange-400" />

        {/* Modal Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-950 border border-slate-800 text-slate-400 hover:text-white hover:border-orange-500/40 transition duration-200 cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Header Section */}
        <div className="p-6 pb-4 border-b border-slate-850 bg-slate-950/40">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="p-1.5 rounded-md bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <Sparkles className="h-4 w-4" />
            </span>
            <span className="text-[10px] uppercase font-mono font-black tracking-widest text-slate-400">
              RunMusicStore Accounts
            </span>
          </div>
          <h2 className="font-display font-black text-white text-xl">
            {user.isLoggedIn ? "Your DJ Workspace" : "Access Global DJ Stems & Packs"}
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            {user.isLoggedIn 
              ? "Manage your connected credential tokens and licenses."
              : "Register or sign in with your social provider to get instant credits."}
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">

          {/* ACTIVE STATE: LOGGED IN USER */}
          {user.isLoggedIn && (
            <div className="space-y-5" id="auth-state-loggedin">
              
              {/* Profile Card */}
              <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-800 flex items-center gap-4">
                <div className="relative">
                  <img 
                    src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80"} 
                    alt="DJ Member Avatar" 
                    className="h-14 w-14 rounded-full border-2 border-orange-500 object-cover"
                  />
                  <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase text-slate-950 bg-orange-500 font-mono tracking-tighter shadow-sm">
                    {user.provider}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[9px] uppercase tracking-wider font-mono font-extrabold text-orange-400 flex items-center gap-1">
                    <span>Active Member Account</span>
                    <span>•</span>
                    <span className="text-emerald-400">{user.subTier.toUpperCase()}</span>
                  </div>
                  <h4 className="font-bold text-white text-base truncate">{user.name || "Pro DJ"}</h4>
                  <p className="text-slate-400 text-xs truncate">{user.email || "dj@runmusicstore.com"}</p>
                </div>
              </div>

              {/* Status Points List */}
              <div className="space-y-2.5 bg-slate-950/20 p-4 rounded-xl border border-slate-850 text-xs text-slate-300">
                <div className="flex justify-between items-center pb-2 border-b border-slate-850">
                  <span className="text-slate-400">Subscription Tier</span>
                  <span className="font-mono font-bold text-amber-400 uppercase">{user.subTier} Tier</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-850">
                  <span className="text-slate-400">Available Marketplace Credits</span>
                  <span className="font-mono font-bold text-emerald-400">{user.credits} CR</span>
                </div>
                <div className="flex justify-between items-center text-slate-400">
                  <span>Connected Identity Token</span>
                  <span className="font-mono text-[10px] text-slate-500">
                    {user.provider === "google" ? "Google JWT (Active)" : "Facebook Graph API (Active)"}
                  </span>
                </div>
              </div>

              {/* Actions Grid */}
              <div className="flex gap-3">
                <button
                  onClick={onClose}
                  className="flex-1 px-4 py-2 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-orange-500/30 text-white rounded-xl text-xs font-bold transition duration-200 cursor-pointer"
                >
                  Return to Store
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 bg-red-950/20 hover:bg-red-900/40 text-red-400 border border-red-500/20 hover:border-red-400/40 rounded-xl text-xs font-bold transition duration-200 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="h-3.5 w-3.5" /> Sign Out
                </button>
              </div>

            </div>
          )}

          {/* STATE: FIRST CHOICE SIGN-IN OPTION DIALOG */}
          {!user.isLoggedIn && authStep === "choice" && (
            <div className="space-y-4" id="auth-state-choices">
              
              {/* Special Welcome Badge */}
              <div className="p-3 bg-gradient-to-r from-orange-950/20 to-transparent border-l-2 border-orange-500 rounded-r-xl">
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Join inside <strong>RunMusicStoreDj</strong> to access cloud backup catalogs, unlock special member licensing, and sync remaining credits between workspace environments instantly!
                </p>
              </div>

              {/* Google Button */}
              <button
                onClick={() => setAuthStep("google-flow")}
                className="w-full h-12 rounded-xl bg-white hover:bg-slate-50 text-slate-900 font-bold px-4 flex items-center justify-between transition duration-200 shadow-md transform active:scale-[0.98] cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="h-6 w-6 rounded-lg bg-orange-500/5 flex items-center justify-center shrink-0">
                    <Chrome className="h-5 w-5 text-red-500 fill-current" />
                  </div>
                  <span className="text-sm font-sans">Continue with Google / Gmail</span>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 shrink-0" />
              </button>

              {/* Facebook Button */}
              <button
                onClick={() => setAuthStep("facebook-flow")}
                className="w-full h-12 rounded-xl bg-[#1877F2] hover:bg-[#166FE5] text-white font-bold px-4 flex items-center justify-between transition duration-200 shadow-md transform active:scale-[0.98] cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="h-6 w-6 shrink-0 flex items-center justify-center">
                    <Facebook className="h-5 w-5 fill-current border-none" />
                  </div>
                  <span className="text-sm font-sans">Continue with Facebook</span>
                </div>
                <ArrowRight className="h-4 w-4 text-white/80 shrink-0" />
              </button>

              <div className="text-center pt-2">
                <p className="text-[10px] text-slate-500 uppercase tracking-wider font-mono">
                  🔒 Secure Multi-Platform Auth • No Credit Card Required
                </p>
              </div>

            </div>
          )}

          {/* STATE: GOOGLE AUTHENTICATION DECK FLOW */}
          {authStep === "google-flow" && (
            <div className="space-y-4 font-sans" id="google-accounts-picker">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400">Google Accounts Selector</span>
                <button 
                  onClick={() => setAuthStep("choice")}
                  className="text-[11px] text-orange-400 hover:underline"
                >
                  Back to options
                </button>
              </div>

              {/* List of sample google accounts */}
              <div className="space-y-2">
                <p className="text-[11.5px] text-slate-400 mb-2">
                  Choose an active Google Session to continue to RunMusicStoreDj:
                </p>
                
                {googleAccounts.map((acc) => (
                  <button
                    key={acc.email}
                    onClick={() => handleSelectQuickGoogleAccount(acc)}
                    className="w-full p-3 rounded-xl bg-slate-950 border border-slate-850 hover:border-orange-500/40 hover:bg-slate-900/50 flex items-center gap-3 text-left transition duration-200 cursor-pointer"
                  >
                    <img 
                      src={acc.avatar} 
                      alt={acc.name} 
                      className="h-9 w-9 rounded-full object-cover border border-slate-700" 
                    />
                    <div className="min-w-0 flex-1">
                      <h5 className="font-bold text-white text-xs truncate">{acc.name}</h5>
                      <p className="text-slate-500 text-[10.5px] truncate">{acc.email}</p>
                    </div>
                    <span className="text-[9px] uppercase font-mono font-bold bg-slate-900 border border-slate-800 text-slate-400 px-2 py-0.5 rounded">
                      Use Account
                    </span>
                  </button>
                ))}
              </div>

              {/* Enter individual customized gmail address */}
              <div className="pt-2 border-t border-slate-850/60">
                <button
                  type="button"
                  onClick={() => setAuthStep("custom-gmail")}
                  className="w-full py-2.5 text-center text-xs font-bold text-slate-350 hover:text-white bg-slate-950 hover:bg-slate-900 border border-slate-850 rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Mail className="h-3.5 w-3.5 text-orange-400" /> Use another Gmail Account
                </button>
              </div>
            </div>
          )}

          {/* STATE: CUSTOM GMAIL ADDRESS REGISTER FORM */}
          {authStep === "custom-gmail" && (
            <form onSubmit={handleCustomGmailSubmit} className="space-y-4" id="custom-gmail-register">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400">Register Custom Gmail Account</span>
                <button 
                  type="button"
                  onClick={() => setAuthStep("google-flow")}
                  className="text-[11px] text-orange-400 hover:underline"
                >
                  Back to selection
                </button>
              </div>

              {errorMessage && (
                <div className="p-3 bg-red-950/20 border border-red-500/20 text-red-400 text-xs rounded-xl flex items-start gap-2 animate-shake">
                  <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="space-y-3.5">
                <div>
                  <label className="block text-slate-400 text-[10.5px] uppercase font-bold tracking-wider mb-1 font-mono">
                    YOUR GMAIL ADDRESS
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="name@gmail.com"
                    value={customEmail}
                    onChange={(e) => setCustomEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-650 text-xs focus:outline-none focus:border-orange-500 transition font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 text-[10.5px] uppercase font-bold tracking-wider mb-1 font-mono">
                    DJ STAGE NAME
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Master Shfiter"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-650 text-xs focus:outline-none focus:border-orange-500 transition"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl text-xs shadow-lg transition duration-200 cursor-pointer flex items-center justify-center gap-1.5"
              >
                Sign In & Grant Credentials
              </button>
            </form>
          )}

          {/* STATE: FACEBOOK HANDSHAKE REQUEST */}
          {authStep === "facebook-flow" && (
            <div className="space-y-4" id="fb-auth-request">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400">Facebook Identity Security</span>
                <button 
                  onClick={() => setAuthStep("choice")}
                  className="text-[11px] text-orange-400 hover:underline"
                >
                  Back to options
                </button>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-850/60 space-y-4">
                {/* FB Blue App Identifier */}
                <div className="flex gap-3 pb-3 border-b border-slate-900">
                  <div className="h-10 w-10 bg-[#1877F2] rounded-lg flex items-center justify-center text-white shrink-0">
                    <Facebook className="h-6 w-6 stroke-[3px]" />
                  </div>
                  <div>
                    <h5 className="font-bold text-white text-xs">RunMusicStore API Handler</h5>
                    <p className="text-[10px] text-slate-500">App ID: 837636610211847</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-[11.5px] text-slate-350 leading-relaxed">
                    <strong>RunMusicStore</strong> will receive your name, email, and public profile photo details. This request complies with security data tokens and stores zero password credentials.
                  </p>
                </div>

                <div className="flex items-center gap-2.5 p-2 bg-slate-900 border border-slate-800 rounded-xl">
                  <img src={facebookProfile.avatar} alt="Alex FB avatar" className="h-8 w-8 rounded-full object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] text-slate-400 leading-none">Logged in on Facebook as</p>
                    <p className="font-bold text-white text-xs mt-0.5">{facebookProfile.name}</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setAuthStep("choice")}
                  className="flex-1 py-2 text-center text-xs font-bold text-slate-400 bg-slate-950 border border-slate-850 rounded-xl hover:bg-slate-900 hover:text-white transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleFacebookConnect}
                  className="flex-1 py-2 bg-[#1877F2] hover:bg-[#166FE5] text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-md"
                >
                  Continue as Alex
                </button>
              </div>
            </div>
          )}

          {/* STATE: AUTHENTICATING DECK spinner/loader */}
          {authStep === "authenticating" && (
            <div className="py-10 flex flex-col items-center justify-center space-y-4" id="auth-loading-spinner">
              <Loader2 className="h-10 w-10 text-orange-500 animate-spin" />
              <div className="text-center">
                <h5 className="font-bold text-white text-xs uppercase tracking-wider">Syncing Identity Token</h5>
                <p className="text-slate-500 text-[10.5px] mt-1">Establishing handshake security connection. Please wait...</p>
              </div>
            </div>
          )}

        </div>

        {/* Informative Security Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-850/60 text-center text-[10px] text-slate-500 flex items-center justify-center gap-1">
          <span>We protect your licensing credentials under strict SSL encryption.</span>
        </div>

      </div>
    </div>
  );
}
