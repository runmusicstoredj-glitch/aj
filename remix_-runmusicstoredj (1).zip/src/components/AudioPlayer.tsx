import React, { useRef, useState, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX, Repeat, SkipBack, Share2, Disc } from "lucide-react";
import { Track } from "../types";

interface AudioPlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayPauseToggle: () => void;
  onNextTrack?: () => void;
  onPrevTrack?: () => void;
  isInline?: boolean;
}

export default function AudioPlayer({
  currentTrack,
  isPlaying,
  onPlayPauseToggle,
  isInline = false,
}: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  // Audio playback statuses
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [playbackError, setPlaybackError] = useState<string | null>(null);

  // Sync actual HTML element playback when isPlaying changes
  useEffect(() => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.play().catch((err) => {
        console.warn("Audio playback error. Might require user gesture first:", err);
        setPlaybackError("Autoplay blocked. Press play.");
      });
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying, currentTrack]);

  // Sync volume is changed
  useEffect(() => {
    if (!audioRef.current) return;
    audioRef.current.volume = isMuted ? 0 : volume;
  }, [volume, isMuted]);

  // Sync loop change
  useEffect(() => {
    if (!audioRef.current) return;
    audioRef.current.loop = isLooping;
  }, [isLooping]);

  // Reset counters when track changes
  useEffect(() => {
    setCurrentTime(0);
    setDuration(0);
    setPlaybackError(null);
  }, [currentTrack]);

  if (!currentTrack) return null;

  const handleTimeUpdate = () => {
    if (!audioRef.current) return;
    setCurrentTime(audioRef.current.currentTime);
  };

  const handleLoadedMetadata = () => {
    if (!audioRef.current) return;
    setDuration(audioRef.current.duration);
  };

  const handleAudioEnded = () => {
    if (!isLooping) {
      onPlayPauseToggle(); // trigger pause style
    }
  };

  const handleScrubChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolume(vol);
    setIsMuted(vol === 0);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return "0:00";
    const minutes = Math.floor(secs / 60);
    const seconds = Math.floor(secs % 60);
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  if (isInline) {
    return (
      <div 
        className="w-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 shadow-inner mt-4 animate-in fade-in slide-in-from-top-2 duration-300"
        id={`inline-audio-player-${currentTrack.id}`}
      >
        <audio
          ref={audioRef}
          src={currentTrack.audioUrl}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onEnded={handleAudioEnded}
          onError={() => setPlaybackError("Format unsupported or file missing.")}
        />

        <div className="flex flex-col gap-3">
          {/* Controls row */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Play/Pause & Loop Button */}
            <div className="flex items-center gap-2">
              <button
                id={`inline-play-pause-${currentTrack.id}`}
                onClick={onPlayPauseToggle}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white hover:bg-blue-500 hover:scale-105 active:scale-95 transition-all duration-300 shadow-md shadow-blue-500/10 cursor-pointer"
              >
                {isPlaying ? (
                  <Pause className="h-4 w-4 fill-current" />
                ) : (
                  <Play className="h-4 w-4 fill-current ml-0.5" />
                )}
              </button>

              <button
                id={`inline-loop-${currentTrack.id}`}
                onClick={() => setIsLooping(!isLooping)}
                className={`rounded-full p-1.5 transition duration-300 cursor-pointer ${
                  isLooping ? "text-blue-400 bg-blue-500/15" : "text-slate-500 hover:text-white"
                }`}
                title="Toggle Loop"
              >
                <Repeat className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Error or BPM info */}
            <div className="flex items-center gap-1.5 text-[10px] font-mono">
              {playbackError ? (
                <span className="text-red-400 font-bold bg-red-950/10 border border-red-500/20 px-2 py-0.5 rounded">
                  {playbackError}
                </span>
              ) : (
                <span className="text-blue-400 font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/10 px-2 py-0.5 rounded">
                  {currentTrack.bpm} BPM | {currentTrack.key}
                </span>
              )}
            </div>

            {/* Mute and Volume slider */}
            <div className="flex items-center gap-1">
              <button
                id={`inline-mute-${currentTrack.id}`}
                onClick={() => setIsMuted(!isMuted)}
                className="text-slate-500 hover:text-slate-300 transition duration-300 cursor-pointer"
              >
                {isMuted ? (
                  <VolumeX className="h-3.5 w-3.5 text-red-400" />
                ) : (
                  <Volume2 className="h-3.5 w-3.5" />
                )}
              </button>
              <input
                id={`inline-volume-${currentTrack.id}`}
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-14 sm:w-16 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Time Scrubber Row */}
          <div className="flex items-center gap-2.5 text-[10px] font-mono text-slate-500">
            <span className="w-8 text-right select-none">{formatTime(currentTime)}</span>
            <input
              id={`inline-scrubber-${currentTrack.id}`}
              type="range"
              min={0}
              max={duration || 100}
              value={currentTime}
              onChange={handleScrubChange}
              className="flex-1 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none hover:bg-slate-705 transition"
            />
            <span className="w-8 text-left select-none">{formatTime(duration)}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="fixed bottom-0 left-0 right-0 z-50 border-t border-blue-500/30 bg-slate-950/95 py-3 px-4 shadow-[0_-10px_30px_rgba(2,6,17,0.7)] backdrop-blur-lg animate-in slide-in-from-bottom"
      id="global-audio-player"
    >
      {/* Hidden Native Audio Element */}
      <audio
        ref={audioRef}
        src={currentTrack.audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleAudioEnded}
        onError={() => setPlaybackError("Format unsupported or file missing.")}
      />

      <div className="mx-auto max-w-7xl flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Track Metadata Left */}
        <div className="flex items-center gap-3 w-full md:w-1/4 min-w-0" id="player-track-info">
          <div className="relative h-12 w-12 flex-shrink-0 cursor-pointer overflow-hidden rounded-md border border-slate-800 bg-slate-900">
            <img
              src={currentTrack.coverUrl}
              referrerPolicy="no-referrer"
              alt={currentTrack.title}
              className={`h-full w-full object-cover ${isPlaying ? "animate-[spin_20s_linear_infinite]" : ""}`}
            />
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition">
              <Disc className="h-5 w-5 text-blue-400" />
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="truncate font-display font-medium text-white text-sm">
              {currentTrack.title}
            </h4>
            <p className="truncate text-xs text-slate-400 font-medium">
              {currentTrack.artist}
            </p>
          </div>
        </div>

        {/* Player Controls & Scrubber Center */}
        <div className="flex flex-col items-center w-full md:w-2/4 gap-1.5" id="player-central-controls">
          <div className="flex items-center gap-4">
            {/* Loop Controls */}
            <button
              id="player-btn-loop"
              onClick={() => setIsLooping(!isLooping)}
              className={`rounded-full p-1 transition ${
                isLooping ? "text-blue-400 bg-blue-500/15" : "text-slate-400 hover:text-white"
              }`}
              title="Toggle Loop Pack"
            >
              <Repeat className="h-4 w-4" />
            </button>

            {/* Play/Pause Button */}
            <button
              id="player-btn-play-pause"
              onClick={onPlayPauseToggle}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg shadow-blue-500/20 hover:bg-blue-500 hover:scale-105 active:scale-95 transition"
            >
              {isPlaying ? (
                <Pause className="h-5 w-5 fill-current" />
              ) : (
                <Play className="h-5 w-5 fill-current ml-0.5" />
              )}
            </button>

            {/* Error badge */}
            {playbackError && (
              <span className="text-[10px] bg-red-500/10 border border-red-500/30 text-red-400 font-mono px-2 py-0.5 rounded">
                {playbackError}
              </span>
            )}
          </div>

          {/* Time Scrubber */}
          <div className="flex items-center gap-3 w-full text-xs font-mono text-slate-400">
            <span>{formatTime(currentTime)}</span>
            <input
              id="player-time-scrubber"
              type="range"
              min={0}
              max={duration || 100}
              value={currentTime}
              onChange={handleScrubChange}
              className="flex-1 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none"
            />
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Volume & Aux Panel Right */}
        <div className="flex items-center justify-end gap-3 w-full md:w-1/4" id="player-utilities">
          <span className="hidden lg:inline-flex rounded-md border border-slate-800 bg-slate-900/60 px-2 py-0.5 text-[10px] font-mono text-blue-400">
            {currentTrack.bpm} BPM | {currentTrack.key}
          </span>

          <div className="flex items-center gap-2">
            <button
              id="player-btn-mute"
              onClick={() => setIsMuted(!isMuted)}
              className="text-slate-400 hover:text-white transition"
            >
              {isMuted ? (
                <VolumeX className="h-4.5 w-4.5 text-red-400" />
              ) : (
                <Volume2 className="h-4.5 w-4.5" />
              )}
            </button>
            <input
              id="player-volume-slider"
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-16 sm:w-24 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
