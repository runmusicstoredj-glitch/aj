import React from "react";
import { Disc, Music, Shield, Home, Coins, Cloud, ThumbsUp, Sun, Moon } from "lucide-react";
import { Tab, UserAccount } from "../types";

interface NavbarProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  isAdminAuthenticated: boolean;
  onLogoutAdmin: () => void;
  user: UserAccount;
  onOpenAuth: () => void;
  lightMode: boolean;
  onToggleLightMode: () => void;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  isAdminAuthenticated,
  onLogoutAdmin,
  user,
  onOpenAuth,
  lightMode,
  onToggleLightMode,
}: NavbarProps) {
  return (
    <header className={`sticky top-0 z-50 border-b backdrop-blur-md shadow-lg transition-colors duration-300 ${
      lightMode 
        ? "border-slate-200 bg-white/90 text-slate-800" 
        : "border-slate-800 bg-slate-950/80 text-slate-100"
    }`}>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand Logo - Soundeo Inspired Sleek Layout */}
        <div 
          onClick={() => setActiveTab("home")} 
          className="flex cursor-pointer items-center gap-3 transition hover:opacity-90 select-none animate-fadeIn"
          id="nav-logo"
        >
          <div className="relative">
            <Disc className={`h-8 w-8 animate-[spin_10s_linear_infinite] ${
              lightMode ? "text-blue-600" : "text-blue-550"
            }`} />
            <div className={`absolute inset-0 h-8 w-8 blur rounded-full animate-pulse ${
              lightMode ? "bg-blue-600/10" : "bg-blue-500/20"
            }`} />
          </div>
          <div>
            <h1 className={`font-display text-sm font-black tracking-[0.2em] leading-none ${
              lightMode ? "text-slate-900" : "text-white"
            }`}>
              SOUND<span className="text-blue-650 font-extrabold pb-0.5">DECK</span>
            </h1>
            <p className="font-mono text-[7px] uppercase tracking-[0.16em] text-slate-500 mt-1">
              ★ Premium DJ Pool & Requests ★
            </p>
          </div>
        </div>

        {/* Dense Desktop/Mobile Navigation */}
        <nav className="flex items-center gap-1 sm:gap-2">
          
          {/* Tab 1: Home (Latest) */}
          <button
            id="tab-home"
            onClick={() => setActiveTab("home")}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider transition ${
              activeTab === "home"
                ? lightMode
                  ? "bg-blue-550/10 text-blue-750 border border-blue-200 shadow-sm"
                  : "bg-blue-500/10 text-blue-400 border border-blue-500/30 shadow"
                : lightMode
                  ? "text-slate-600 hover:bg-slate-100 hover:text-blue-600 border border-transparent"
                  : "text-slate-400 hover:bg-slate-900 hover:text-white border border-transparent"
            }`}
          >
            <Home className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Latest</span>
          </button>

          {/* Tab 2: Browse Tracks */}
          <button
            id="tab-browse"
            onClick={() => setActiveTab("browse")}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider transition ${
              activeTab === "browse"
                ? lightMode
                  ? "bg-blue-550/10 text-blue-750 border border-blue-200 shadow-sm"
                  : "bg-blue-500/10 text-blue-400 border border-blue-500/30 shadow"
                : lightMode
                  ? "text-slate-600 hover:bg-slate-100 hover:text-blue-600 border border-transparent"
                  : "text-slate-400 hover:bg-slate-900 hover:text-white border border-transparent"
            }`}
          >
            <Music className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Directory</span>
          </button>

          {/* Tab 3: VOTING (Request Pool) - SOUNDEO CORE UNIQUE FEATURE */}
          <button
            id="tab-votes"
            onClick={() => setActiveTab("votes")}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider transition relative ${
              activeTab === "votes"
                ? "bg-amber-500/10 text-amber-500 border border-amber-550/30 shadow"
                : lightMode
                  ? "text-slate-600 hover:bg-slate-100 hover:text-amber-600 border border-transparent"
                  : "text-slate-400 hover:bg-slate-900 hover:text-amber-400 border border-transparent"
            }`}
          >
            <ThumbsUp className="h-3.5 w-3.5 text-amber-500 shrink-0" />
            <span className="hidden sm:inline">Votes Pool</span>
            <span className="absolute -top-1 -right-0.5 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75 animate-bounce"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
          </button>

          {/* Tab 4: Subscriptions / Credits Panel */}
          <button
            id="tab-membership"
            onClick={() => setActiveTab("membership")}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider transition ${
              activeTab === "membership"
                ? "bg-violet-500/10 text-violet-600 border border-violet-500/20 shadow"
                : lightMode
                  ? "text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-transparent"
                  : "text-slate-400 hover:bg-slate-900 hover:text-purple-400 border border-transparent"
            }`}
          >
            <Coins className="h-3.5 w-3.5 text-amber-500 shrink-0 animate-pulse" />
            <span className="font-bold">
              {user.subTier === "platinum" ? "VIP" : `${user.credits} CR`}
            </span>
          </button>

          {/* Tab 5: Cloud Storage */}
          <button
            id="tab-storage"
            onClick={() => setActiveTab("storage")}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider transition ${
              activeTab === "storage"
                ? "bg-sky-500/10 text-sky-600 border border-sky-500/30 shadow"
                : lightMode
                  ? "text-slate-600 hover:bg-slate-100 hover:text-sky-600 border border-transparent"
                  : "text-slate-400 hover:bg-slate-900 hover:text-sky-400 border border-transparent"
            }`}
          >
            <Cloud className="h-3.5 w-3.5 text-sky-500" />
            <span className="hidden lg:inline">Cloud Sync</span>
          </button>

          {/* Tab 6: Admin Portal */}
          <button
            id="tab-admin"
            onClick={() => setActiveTab("admin")}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider transition ${
              activeTab === "admin"
                ? "bg-rose-500/10 text-rose-600 border border-rose-500/30 shadow"
                : lightMode
                  ? "text-slate-600 hover:bg-slate-100 hover:text-rose-600 border border-transparent"
                  : "text-slate-400 hover:bg-slate-900 hover:text-rose-450 border border-transparent"
            }`}
          >
            <Shield className="h-3.5 w-3.5" />
            <span className="hidden xl:inline">Admin</span>
          </button>

          {/* Sun / Moon Theme Mode Switcher (Saves both Requests 2 & 3 beautifully!) */}
          <button
            onClick={onToggleLightMode}
            className={`p-2 rounded-xl transition-all duration-300 relative group overflow-hidden border border-slate-700/10 ${
              lightMode 
                ? "bg-amber-100/50 hover:bg-amber-100 text-amber-650" 
                : "bg-slate-900 hover:bg-slate-800 text-blue-400 hover:text-yellow-400"
            }`}
            title={lightMode ? "Shift to Soundeo Dark Theme" : "Shift to White Studio Theme"}
          >
            {lightMode ? (
              <Moon className="h-3.5 w-3.5 text-slate-800 shrink-0" />
            ) : (
              <Sun className="h-3.5 w-3.5 text-amber-400 shrink-0 animate-spin-slow" />
            )}
          </button>

          {/* Logout if authenticated */}
          {isAdminAuthenticated && activeTab === "admin" && (
            <button
              id="admin-logout-btn"
              onClick={onLogoutAdmin}
              className="ml-1 font-mono text-[9px] uppercase tracking-wider text-red-500 hover:text-red-400 px-2 py-1 rounded-lg border border-red-200 bg-red-50/50"
            >
              Lock
            </button>
          )}

          {/* User Profile / sign in button */}
          {user.isLoggedIn ? (
            <button
              id="nav-user-profile-btn"
              onClick={onOpenAuth}
              className={`flex items-center gap-1.5 rounded-xl px-2 py-1 text-[10px] font-mono border transition ${
                lightMode
                  ? "border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800"
                  : "border-slate-800 bg-slate-905 hover:bg-slate-900 text-slate-200"
              } cursor-pointer ml-1`}
              title={`Logged in with ${user.provider}`}
            >
              <img 
                src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80"} 
                alt="DJ Profile"
                className="h-5 w-5 rounded-full border border-blue-500 object-cover"
              />
              <span className="hidden md:inline truncate max-w-[70px] uppercase font-bold text-[10px]">{user.name || "DJ"}</span>
            </button>
          ) : (
            <button
              id="nav-sign-in-btn"
              onClick={onOpenAuth}
              className={`flex items-center gap-1 rounded-xl px-2.5 py-1 text-[10px] font-bold border cursor-pointer ml-1 uppercase font-mono transition ${
                lightMode
                  ? "border-slate-350 bg-slate-100 text-slate-700 hover:bg-slate-200"
                  : "border-slate-800 bg-slate-900 hover:border-slate-700 hover:bg-slate-800 text-slate-300"
              }`}
            >
              <span className="h-1 w-1 rounded-full bg-blue-500 animate-pulse shrink-0" />
              <span>Login</span>
            </button>
          )}

        </nav>
      </div>
    </header>
  );
}
